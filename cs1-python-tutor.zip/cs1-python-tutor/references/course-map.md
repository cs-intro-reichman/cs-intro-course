# Course map: Introduction to Computer Science (Python)

Skill version 2026-10-11. Lectures marked *not available yet* are not in this version of the skill.

## Lectures

| Week | Lecture | Topic | File |
|---|---|---|---|
| 1 | 1-1 | Intro and basics | `lectures/lecture-1-1-intro-and-basics.md` |
| 1 | 1-2 | Types and I/O | `lectures/lecture-1-2-types-and-i-o.md` |
| 1 | code | Code files from the week 1 lectures | `lectures/week-01-code.md` |
| 2 | 2-1 | Conditionals and while loops | `lectures/lecture-2-1-conditionals-and-while-loops.md` |
| 2 | 2-2 | The for loop and numeral systems | `lectures/lecture-2-2-the-for-loop-and-numeral-systems.md` |
| 2 | 2-x | Gambler's ruin (simulation) | `lectures/lecture-2-x-gambler-s-ruin-simulation.md` |
| 3 | 3-1 | Strings | `lectures/lecture-3-1-strings.md` |
| 3 | 3-2 | Approximation algorithms | `lectures/lecture-3-2-approximation-algorithms.md` |
| 3 | code | Code files from the week 3 lectures | `lectures/week-03-code.md` |
| 4 | 4-1 | Functions | `lectures/lecture-4-1-functions.md` |
| 4 | 4-2 | Lists and tuples | `lectures/lecture-4-2-lists-and-tuples.md` |
| 4 | code | Code files from the week 4 lectures | `lectures/week-04-code.md` |
| 5 | 5-1 | Two-dimensional lists | `lectures/lecture-5-1-two-dimensional-lists.md` |
| 5 | 5-2 | Dictionaries and sets | `lectures/lecture-5-2-dictionaries-and-sets.md` |
| 5 | code | Code files from the week 5 lectures | `lectures/week-05-code.md` |
| 6 | 6-1 | Files | `lectures/lecture-6-1-files.md` |
| 6 | 6-2 | PageRank | `lectures/lecture-6-2-pagerank.md` |
| 6 | code | Code files from the week 6 lectures | `lectures/week-06-code.md` |
| 7 | 7-1 | Recursion | *not available yet* |
| 8 | 8-1 | Computer fundamentals: the Vic computer | `lectures/lecture-8-1-computer-fundamentals-the-vic-computer.md` |
| 8 | 8-2 | AI agents for coding | *not available yet* |
| 8 | code | Code files from the week 8 lectures | `lectures/week-08-code.md` |
| 9 | 9-1 | Software engineering | *not available yet* |
| 9 | 9-2 | Complexity | *not available yet* |
| 10 | 10-1 | Searching and sorting | *not available yet* |
| 10 | 10-2 | Objects and classes (using classes) | `lectures/lecture-10-2-objects-and-classes-using-classes.md` |
| 10 | code | Code files from the week 10 lectures | `lectures/week-10-code.md` |
| 11 | 11-1 | Writing classes | `lectures/lecture-11-1-writing-classes.md` |
| 11 | 11-2 | Image processing | *not available yet* |
| 11 | code | Code files from the week 11 lectures | `lectures/week-11-code.md` |
| 12 | 12-1 | Advanced data structures 1 | *not available yet* |
| 12 | 12-2 | Advanced data structures 2 | *not available yet* |

## Recitations

*No recitations in this version.*

## Homework assignments

These are graded. Use the hint ladder, never write solutions.

- HW1: Errors, input and arithmetic, after week 1 (`homework/hw1-errors-input-and-arithmetic.md`)
