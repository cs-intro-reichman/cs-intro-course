# Lecture 5-1: Two-dimensional lists (week 5)

## Slide 1: Two-Dimensional Lists
[i][j]
PYTHON COURSE · WEEK 5 · LECTURE 1
Two-Dimensional Lists
Data in rows and columns
Reichman University

## Slide 2: Data in rows and columns
Data in rows and columns
A lot of data comes as tables.
Ratings: reviewers down the side, movies across the top
Images: rows and columns of pixels
Sales: models down the side, quarters across
Game boards: a 3 × 3 tic-tac-toe grid

## Slide 3: A table of ratings
A table of ratings
Each value is found by two numbers: a row and a column.
4
5
4
5
4
5
3
4
4
4
3
4
3
5
3
0
1
2
3
4
0
1
2
movie (column)
reviewer (row)
row 1, column 2  →  reviewer 1 gave movie 2 a 4

## Slide 4: An image is a table
An image is a table
Each number is one pixel: 1 is dark, 0 is light.
0
0
0
0
0
0
0
0
0
0
1
1
1
1
0
0
0
0
0
1
1
1
1
0
0
0
0
0
1
1
1
1
0
0
0
0
0
0
0
0
what the list stores
what the screen shows

## Slide 5: A list of lists
A list of lists
A row: an ordinary list, like [4, 5, 4, 5, 4]
The table: a list whose items are the rows
One value: ratings[row][col], row first, then column
Its size: len(ratings) rows, len(ratings[0]) columns

## Slide 6: Writing a table in Python
Writing a table in Python
```python
python ratings.py
4
[5, 3, 4, 4, 4]
3
5
```
`ratings.py`
```python
# rows are reviewers, columns are movies
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

print(ratings[1][2])     # reviewer 1, movie 2
print(ratings[1])        # all of row 1
print(len(ratings))      # number of rows
print(len(ratings[0]))   # number of columns
```
[LIVE] the file is in “week 5 code / ratings.py”.

## Slide 7: A list of lists in memory
A list of lists in memory
The outer list holds three references, one to each row.
```python
ratings
```
0
1
2
4
5
4
5
4
```python
ratings[0]
```
5
3
4
4
4
```python
ratings[1]
```
3
4
3
5
3
```python
ratings[2]
```

## Slide 8: Reading ratings[1][2]
Reading ratings[1][2]
Two indexes, two steps: first pick a row, then pick a cell.
```python
ratings
```
the table
5
3
4
4
4
ratings[1] picks a row
4
…[2] picks a cell in it

## Slide 9: Two-dimensional lists: the plan
Two-dimensional lists: the plan
Four things to do with a table.
Lists of lists
Visiting every cell
Building grids
Matrix operations

## Slide 10: Printing every cell
Printing every cell
```python
python print_table.py
   4   5   4   5   4
   5   3   4   4   4
   3   4   3   5   3
```
`print_table.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

for row in range(len(ratings)):
    for col in range(len(ratings[row])):
        print(f"{ratings[row][col]:4}", end="")
    print()
```
[LIVE] the file is in “week 5 code / print_table.py”.

## Slide 11: Reading the nested loop
Reading the nested loop
`print_table.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

for row in range(len(ratings)):
    for col in range(len(ratings[row])):
        print(f"{ratings[row][col]:4}", end="")
    print()
```
Outer loop
One pass for each row.
Inner loop
One pass for each column of that row.
end="" and print()
Stay on the line; then end the row.

## Slide 12: Format specs in f-strings
Format specs in f-strings
`format_specs.py`
```python
# [ ] mark the edges of each value
x = 7
r = 2 / 3
n = 1234567
name = "Dana"
print(f"[{x}]")         # [7]
print(f"[{x:4}]")       # [   7]
print(f"[{r:.3f}]")     # [0.667]
print(f"[{r:7.3f}]")    # [  0.667]
print(f"[{n:,}]")       # [1,234,567]
print(f"[{n:>12,}]")    # [   1,234,567]
print(f"[{name:6}]")    # [Dana  ]
```
[LIVE] the file is in “week 5 code / format_specs.py”.
```python
Width
{x:4} uses at least 4 characters.
```
```python
Decimal places
{r:.3f} keeps 3 decimal places.
```
```python
Thousands
{n:,} adds a comma every 3 digits.
```
```python
Alignment
Numbers go right, text goes left.
> forces right.
```

## Slide 13: The order of the visits
The order of the visits
Row by row, and left to right inside each row.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
0
1
2
3
4
0
1
2
The numbers show when each cell is visited: 15 visits in all.

## Slide 14: Sum of each row
Sum of each row
```python
one run (random)
   7   9   3  19
  12  15   4  31
   2   2   0   4
  12  17   9  38
   1   7  16  24
```
`sum_of_rows.py`
```python
import random

table = []
for i in range(5):            # 5 rows of 3 random values
    row = []
    for j in range(3):
        row.append(random.randint(0, 19))
    table.append(row)

for row in table:             # add each row's sum at its end
    row.append(sum(row))

for row in table:
    for x in row:
        print(f"{x:4}", end="")
    print()
```
[LIVE] the file is in “week 5 code / sum_of_rows.py”.

## Slide 15: Rows and columns
Rows and columns
A row: already a list; for row in table gives it
A column: no list holds it; we have to collect it
Solution: loop over the rows, take [col] from each

## Slide 16: Average of each column
Average of each column
```python
python column_averages.py
movie 0: 4.0
movie 1: 4.0
movie 2: 3.67
movie 3: 4.67
movie 4: 3.67
```
`column_averages.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]
rows = len(ratings)
cols = len(ratings[0])

# the average rating of each movie (a column)
for col in range(cols):
    total = 0
    for row in range(rows):
        total = total + ratings[row][col]
    print(f"movie {col}: {round(total / rows, 2)}")
```
[LIVE] the file is in “week 5 code / column_averages.py”.

## Slide 17: Two-dimensional lists: the plan
Two-dimensional lists: the plan
Four things to do with a table.
Lists of lists
Visiting every cell
Building grids
Matrix operations

## Slide 18: Building a grid
Building a grid
```python
python make_grid.py
. . .
. X .
. . .
```
`make_grid.py`
```python
def make_grid(rows, cols, value):
    """Return a rows x cols grid filled with value."""
    grid = []
    for i in range(rows):
        grid.append([value] * cols)
    return grid

board = make_grid(3, 3, ".")
board[1][1] = "X"
for row in board:
    print(" ".join(row))
```
[LIVE] the file is in “week 5 code / make_grid.py”.

## Slide 19: A common bug: one row, three times
A common bug: one row, three times
```python
python grid_trap.py
. X .
. X .
. X .
True
```
`grid_trap.py`
```python
board = [["."] * 3] * 3      # looks like a 3 x 3 grid
board[1][1] = "X"
for row in board:
    print(" ".join(row))

print(board[0] is board[2])
```
[LIVE] the file is in “week 5 code / grid_trap.py”.

## Slide 20: Why every row changed
Why every row changed
Multiplying the outer list copies the reference, not the row.
0
1
2
```python
board
```
.
X
.
the one and only row
Multiplying a list repeats references, not rows.
Build every row separately, inside a loop, as make_grid does.

## Slide 21: Two-dimensional lists: the plan
Two-dimensional lists: the plan
Four things to do with a table.
Lists of lists
Visiting every cell
Building grids
Matrix operations

## Slide 22: Matrices
Matrices
A matrix: a rectangular table of numbers
Addition: add matching cells; same shape needed
Multiplication: a row of the left times a column of the right
The condition: columns of the left = rows of the right

## Slide 23: Multiplying two matrices
Multiplying two matrices
One cell of the answer: a row of a, times a column of b.
7
2
1
3
6
1
5
1
4
```python
a
```
8
3
5
1
4
1
1
3
4
```python
b
```
59
32
41
31
36
25
45
31
42
```python
c
```
×
=
c[0][0]  =  7 · 8  +  2 · 1  +  1 · 1  =  59
row 0 of a, times column 0 of b

## Slide 24: Adding two matrices
Adding two matrices
`matrix_add.py`
```python
def add(m1, m2):
    """Return m1 + m2. Assumes equal dimensions."""
    result = []
    for i in range(len(m1)):
        row = []
        for j in range(len(m1[0])):
            row.append(m1[i][j] + m2[i][j])
        result.append(row)
    return result
```
the file is in “week 5 code / matrix_add.py”.

## Slide 25: Multiplying two matrices
Multiplying two matrices
`matrix_mult.py`
```python
def mult(m1, m2):
    """Return m1 x m2. Assumes len(m1[0]) == len(m2)."""
    rows = len(m1)
    cols = len(m2[0])
    inner = len(m2)
    result = []
    for i in range(rows):
        row = []
        for j in range(cols):
            total = 0
            for k in range(inner):
                total = total + m1[i][k] * m2[k][j]
            row.append(total)
        result.append(row)
    return result
```
the file is in “week 5 code / matrix_mult.py”.

## Slide 26: Printing a matrix
Printing a matrix
`matrix_print.py`
```python
def print_matrix(m):
    """Print m row by row, then a blank line."""
    for row in m:
        for x in row:
            print(f"{x:5}", end="")
        print()
    print()
```
the file is in “week 5 code / matrix_print.py”.

## Slide 27: Using the matrix functions
Using the matrix functions
```python
python matrix_demo.py
   15    5    6
    4   10    2
    6    4    8

   59   32   41
   31   36   25
   45   31   42

  119   59   54
   75   79   38
  103   51   64
```
`matrix_demo.py`
```python
from matrix_add import add
from matrix_mult import mult
from matrix_print import print_matrix

a = [[7, 2, 1],
     [3, 6, 1],
     [5, 1, 4]]
b = [[8, 3, 5],
     [1, 4, 1],
     [1, 3, 4]]

print_matrix(add(a, b))
print_matrix(mult(a, b))
print_matrix(mult(a, add(a, b)))   # a x (a + b)
```
[LIVE] the file is in “week 5 code / matrix_demo.py”.

## Slide 28: Transpose
Transpose
```python
python transpose.py
[10, 12]
[12, 14]
[20, 25]
[12, 18]
```
`transpose.py`
```python
def transpose(m):
    """Return m with its rows and columns swapped."""
    result = []
    for col in range(len(m[0])):
        new_row = []
        for row in range(len(m)):
            new_row.append(m[row][col])
        result.append(new_row)
    return result

sales = [[10, 12, 20, 12],
         [12, 14, 25, 18]]
for row in transpose(sales):
    print(row)
```
[LIVE] the file is in “week 5 code / transpose.py”.

## Slide 29: Two-dimensional lists in one slide
Two-dimensional lists in one slide
Create
Write the rows inside [ ]
Or build each row in a loop
Never [[x] * m] * n
Read
t[r][c]: row first, then column
len(t) is the number of rows
len(t[0]) is the number of columns
Traverse
Outer loop over the rows
Inner loop over the columns
Columns need indexes
Compute
add: cell by cell
mult: row times column
transpose: swap r and c


---

# Lecture 5-2: Dictionaries and sets (week 5)

## Slide 1: Dictionaries and Sets
{ }
PYTHON COURSE · WEEK 5 · LECTURE 2
Dictionaries and Sets
Finding things by name
Reichman University

## Slide 2: Finding things by name
Finding things by name
A list finds a value by its position. Often we know a name instead.
Airport codes: TLV leads to Tel Aviv
Word counts: “the” leads to 4
Student records: an ID number leads to a grade
A phone book: a name leads to a number

## Slide 3: A dictionary maps keys to values
A dictionary maps keys to values
Each key leads to exactly one value.
key
value
```python
TLV
```
Tel Aviv
```python
JFK
```
New York
```python
CDG
```
Paris
```python
NRT
```
Tokyo

## Slide 4: Terms
Terms
Key: what we look things up by
Value: what we find there
Entry: one key together with its value
Lookup: d[key] gives the value for that key

## Slide 5: A dictionary in Python
A dictionary in Python
```python
python animal_sounds.py
A cow goes moo
{'cow': 'moo', 'dog': 'bark', 'cat': 'miao'}
3
```
`animal_sounds.py`
```python
sounds = {"cow": "moo", "dog": "woof"}

print("A cow goes", sounds["cow"])
sounds["cat"] = "miao"     # adds
sounds["dog"] = "bark"     # replaces
print(sounds)
print(len(sounds))
```
[LIVE] the file is in “week 5 code / animal_sounds.py”.

## Slide 6: Reading the dictionary
Reading the dictionary
`animal_sounds.py`
```python
sounds = {"cow": "moo", "dog": "woof"}

print("A cow goes", sounds["cow"])
sounds["cat"] = "miao"     # adds
sounds["dog"] = "bark"     # replaces
print(sounds)
print(len(sounds))
```
{ key: value }
Braces around the entries; a colon inside each.
sounds[key]
Looks up the value stored for that key.
sounds[key] = v
Adds the key if it is new, replaces its value if not.

## Slide 7: When the key is not there
When the key is not there
```python
python missing_key.py
False
None
???
Traceback (most recent call last):
  ...
KeyError: 'cat'
```
`missing_key.py`
```python
sounds = {"cow": "moo", "dog": "woof"}

print("cat" in sounds)
print(sounds.get("cat"))
print(sounds.get("cat", "???"))
print(sounds["cat"])
```
[LIVE] the file is in “week 5 code / missing_key.py”.

## Slide 8: Visiting every entry
Visiting every entry
```python
python iterate_dict.py
cow goes moo
dog goes woof
cat goes miao
moo is the sound of a cow
woof is the sound of a dog
miao is the sound of a cat
['cow', 'dog', 'cat']
['moo', 'woof', 'miao']
```
`iterate_dict.py`
```python
sounds = {"cow": "moo", "dog": "woof", "cat": "miao"}

for animal in sounds:
    print(f"{animal} goes {sounds[animal]}")

for animal, sound in sounds.items():
    print(f"{sound} is the sound of a {animal}")

print(list(sounds.keys()))
print(list(sounds.values()))
```
[LIVE] the file is in “week 5 code / iterate_dict.py”.

## Slide 9: The rules for keys
The rules for keys
Unique: one value per key; a new value replaces the old
Unchangeable: str, int and tuple can be keys; a list cannot
Values: anything at all, even a list or a dict
Order: entries keep the order they were added in

## Slide 10: Keys must not change
Keys must not change
```python
python tuple_keys.py
centre
3
Traceback (most recent call last):
  ...
TypeError: unhashable type: 'list'
```
`tuple_keys.py`
```python
names = {(0, 0): "corner", (1, 1): "centre"}
print(names[(1, 1)])

names[(0, 2)] = "corner"
print(len(names))

bad = {[0, 0]: "corner"}
```
[LIVE] the file is in “week 5 code / tuple_keys.py”.

## Slide 11: Dictionaries and sets: the plan
Dictionaries and sets: the plan
Four parts today.
Dictionaries
Counting and grouping
Sets
Why they are fast

## Slide 12: Counting: the idea
Counting: the idea
In pseudocode
start with an empty dictionary
for each word in the text:
seen it before? add 1 to its count
a new word? its count is 1
report the counts
Why a dictionary
A list of counters works only when we count 0, 1, 2, …

A dictionary can count anything: words, names, colours.

## Slide 13: Counting words
Counting words
```python
python word_count.py
the 4
cat 2
saw 2
dog 2
and 1
```
`word_count.py`
```python
text = "the cat saw the dog and the dog saw the cat"

counts = {}
for word in text.split():
    if word in counts:
        counts[word] = counts[word] + 1
    else:
        counts[word] = 1

for word, n in counts.items():
    print(word, n)
```
[LIVE] the file is in “week 5 code / word_count.py”.

## Slide 14: The same, with get
The same, with get
```python
python word_count_get.py
4 2 1
0
```
`word_count_get.py`
```python
text = "the cat saw the dog and the dog saw the cat"

counts = {}
for word in text.split():
    counts[word] = counts.get(word, 0) + 1

print(counts["the"], counts["dog"], counts["and"])
print(counts.get("bird", 0))
```
[LIVE] the file is in “week 5 code / word_count_get.py”.

## Slide 15: Grouping: a dictionary of lists
Grouping: a dictionary of lists
```python
python group_by_letter.py
a ['apple', 'avocado']
b ['banana', 'blueberry']
c ['cherry']
```
`group_by_letter.py`
```python
words = ["apple", "banana", "avocado",
         "cherry", "blueberry"]

groups = {}
for w in words:
    first = w[0]
    if first not in groups:
        groups[first] = []      # a new, empty list
    groups[first].append(w)

for letter, group in groups.items():
    print(letter, group)
```
[LIVE] the file is in “week 5 code / group_by_letter.py”.

## Slide 16: Dictionaries and sets: the plan
Dictionaries and sets: the plan
Four parts today.
Dictionaries
Counting and grouping
Sets
Why they are fast

## Slide 17: Sets
Sets
No order: {4, 3, 5} and {3, 4, 5} are the same set
No duplicates: adding 4 a second time changes nothing
Membership: x in s is fast for any size of s
Elements: unchangeable values, the same rule as for keys

## Slide 18: Sets in Python
Sets in Python
```python
python set_basics.py
{1, 3, 5, 7}
{9, 1, 7}
True False
3
```
`set_basics.py`
```python
s1 = set()
s1.add(3)
s1.add(1)
s1.add(3)              # already there: no change
s1.add(5)
s1.add(7)
s2 = set([7, 9, 1, 9, 1, 7])

print(s1)
print(s2)
print(3 in s1, 4 in s1)
print(len(s2))
```
[LIVE] the file is in “week 5 code / set_basics.py”.

## Slide 19: Union, intersection, difference
Union, intersection, difference
s1 = {3, 1, 5, 7}    s2 = {7, 9, 1}
```python
s1
```
```python
s2
```
3
5
1
7
9
union: in either
```python
s1 | s2  →  {1, 3, 5, 7, 9}
```
intersection: in both
```python
s1 & s2  →  {1, 7}
```
difference: in s1, not in s2
```python
s1 - s2  →  {3, 5}
```

## Slide 20: Set operations
Set operations
```python
python set_ops.py
{1, 3, 5, 7, 9}
{1, 7}
{3, 5}
True
```
`set_ops.py`
```python
s1 = {3, 1, 5, 7}
s2 = {7, 9, 1}

print(s1 | s2)       # union
print(s1 & s2)       # intersection
print(s1 - s2)       # difference
print({1, 7} <= s1)  # subset
```
[LIVE] the file is in “week 5 code / set_ops.py”.

## Slide 21: Using sets
Using sets
```python
python two_courses.py
['dana', 'maya']
['noam', 'yoni']
5
5 visits, 3 people
```
`two_courses.py`
```python
intro = {"maya", "noam", "dana", "yoni"}
calculus = {"dana", "omer", "maya"}

print(sorted(intro & calculus))    # in both
print(sorted(intro - calculus))    # intro only
print(len(intro | calculus))       # in either

visits = ["maya", "noam", "maya", "dana", "maya"]
print(f"{len(visits)} visits, {len(set(visits))} people")
```
[LIVE] the file is in “week 5 code / two_courses.py”.

## Slide 22: Which container?
Which container?
Choose by the most common operation.
list
In order, by position
Repeats allowed
t[3], t.append(x)
tuple
In order, cannot change
A fixed group of values
Can be a key
dict
Key leads to value
Look up by name
Counting, grouping
set
No order, no repeats
Fast x in s
Union, intersection

## Slide 23: Dictionaries and sets: the plan
Dictionaries and sets: the plan
Four parts today.
Dictionaries
Counting and grouping
Sets
Why they are fast

## Slide 24: A list and a set, timed
A list and a set, timed
```python
one run on a laptop
list: 8.3707 ms
set:  0.0029 ms
```
`membership_speed.py`
```python
import time

numbers = list(range(1000000))
as_set = set(numbers)

start = time.perf_counter()
found = 999999 in numbers
ms = (time.perf_counter() - start) * 1000
print(f"list: {round(ms, 4)} ms")

start = time.perf_counter()
found = 999999 in as_set
ms = (time.perf_counter() - start) * 1000
print(f"set:  {round(ms, 4)} ms")
```
[LIVE] the file is in “week 5 code / membership_speed.py”.

## Slide 25: How a set works
How a set works
A hash function turns each key into a bucket number.
key : value
```python
63 : 9
```
```python
321 : 6
```
```python
3 : 573
```
```python
7009 : 16
```
```python
143 : 8
```
```python
h(key) = key % 10
```
0
1
2
3
4
5
6
7
8
9
buckets
```python
63 : 9
```
```python
321 : 6
```
```python
3 : 573
```
```python
7009 : 16
```
```python
143 : 8
```

## Slide 26: Why lookup is fast
Why lookup is fast
Store: compute the bucket, put the entry there
Look up: compute the bucket, search only that bucket
The result: lookup time barely depends on the size
The price: a key must never change, or its bucket is wrong

## Slide 27: Dictionaries and sets in one slide
Dictionaries and sets in one slide
dict
{key: value, ...}
d[k] looks up; d[k] = v adds or replaces
d.get(k, default) when k may be missing
for k, v in d.items()
set
set() is empty; {} is a dict
s.add(x), x in s
|  &  -  for union, intersection, difference
set(list) drops the repeats
Patterns
Counting with get(k, 0) + 1
Grouping into a dict of lists
De-duplicating with set()
Fast membership tests


---

# Week 5 code files

The code files shown in the week 5 lectures.

### `animal_sounds.py`
```python
sounds = {"cow": "moo", "dog": "woof"}

print("A cow goes", sounds["cow"])
sounds["cat"] = "miao"     # adds
sounds["dog"] = "bark"     # replaces
print(sounds)
print(len(sounds))
```

### `column_averages.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]
rows = len(ratings)
cols = len(ratings[0])

# the average rating of each movie (a column)
for col in range(cols):
    total = 0
    for row in range(rows):
        total = total + ratings[row][col]
    print(f"movie {col}: {round(total / rows, 2)}")
```

### `format_specs.py`
```python
# [ ] mark the edges of each value
x = 7
r = 2 / 3
n = 1234567
name = "Dana"
print(f"[{x}]")         # [7]
print(f"[{x:4}]")       # [   7]
print(f"[{r:.3f}]")     # [0.667]
print(f"[{r:7.3f}]")    # [  0.667]
print(f"[{n:,}]")       # [1,234,567]
print(f"[{n:>12,}]")    # [   1,234,567]
print(f"[{name:6}]")    # [Dana  ]
```

### `grid_trap.py`
```python
board = [["."] * 3] * 3      # looks like a 3 x 3 grid
board[1][1] = "X"
for row in board:
    print(" ".join(row))

print(board[0] is board[2])
```

### `group_by_letter.py`
```python
words = ["apple", "banana", "avocado",
         "cherry", "blueberry"]

groups = {}
for w in words:
    first = w[0]
    if first not in groups:
        groups[first] = []      # a new, empty list
    groups[first].append(w)

for letter, group in groups.items():
    print(letter, group)
```

### `iterate_dict.py`
```python
sounds = {"cow": "moo", "dog": "woof", "cat": "miao"}

for animal in sounds:
    print(f"{animal} goes {sounds[animal]}")

for animal, sound in sounds.items():
    print(f"{sound} is the sound of a {animal}")

print(list(sounds.keys()))
print(list(sounds.values()))
```

### `make_grid.py`
```python
def make_grid(rows, cols, value):
    """Return a rows x cols grid filled with value."""
    grid = []
    for i in range(rows):
        grid.append([value] * cols)
    return grid

board = make_grid(3, 3, ".")
board[1][1] = "X"
for row in board:
    print(" ".join(row))
```

### `matrix_add.py`
```python
def add(m1, m2):
    """Return m1 + m2. Assumes equal dimensions."""
    result = []
    for i in range(len(m1)):
        row = []
        for j in range(len(m1[0])):
            row.append(m1[i][j] + m2[i][j])
        result.append(row)
    return result
```

### `matrix_demo.py`
```python
from matrix_add import add
from matrix_mult import mult
from matrix_print import print_matrix

a = [[7, 2, 1],
     [3, 6, 1],
     [5, 1, 4]]
b = [[8, 3, 5],
     [1, 4, 1],
     [1, 3, 4]]

print_matrix(add(a, b))
print_matrix(mult(a, b))
print_matrix(mult(a, add(a, b)))   # a x (a + b)
```

### `matrix_mult.py`
```python
def mult(m1, m2):
    """Return m1 x m2. Assumes len(m1[0]) == len(m2)."""
    rows = len(m1)
    cols = len(m2[0])
    inner = len(m2)
    result = []
    for i in range(rows):
        row = []
        for j in range(cols):
            total = 0
            for k in range(inner):
                total = total + m1[i][k] * m2[k][j]
            row.append(total)
        result.append(row)
    return result
```

### `matrix_print.py`
```python
def print_matrix(m):
    """Print m row by row, then a blank line."""
    for row in m:
        for x in row:
            print(f"{x:5}", end="")
        print()
    print()
```

### `membership_speed.py`
```python
import time

numbers = list(range(1000000))
as_set = set(numbers)

start = time.perf_counter()
found = 999999 in numbers
ms = (time.perf_counter() - start) * 1000
print(f"list: {round(ms, 4)} ms")

start = time.perf_counter()
found = 999999 in as_set
ms = (time.perf_counter() - start) * 1000
print(f"set:  {round(ms, 4)} ms")
```

### `missing_key.py`
```python
sounds = {"cow": "moo", "dog": "woof"}

print("cat" in sounds)
print(sounds.get("cat"))
print(sounds.get("cat", "???"))
print(sounds["cat"])
```

### `print_table.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

for row in range(len(ratings)):
    for col in range(len(ratings[row])):
        print(f"{ratings[row][col]:4}", end="")
    print()
```

### `ratings.py`
```python
# rows are reviewers, columns are movies
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

print(ratings[1][2])     # reviewer 1, movie 2
print(ratings[1])        # all of row 1
print(len(ratings))      # number of rows
print(len(ratings[0]))   # number of columns
```

### `set_basics.py`
```python
s1 = set()
s1.add(3)
s1.add(1)
s1.add(3)              # already there: no change
s1.add(5)
s1.add(7)
s2 = set([7, 9, 1, 9, 1, 7])

print(s1)
print(s2)
print(3 in s1, 4 in s1)
print(len(s2))
```

### `set_ops.py`
```python
s1 = {3, 1, 5, 7}
s2 = {7, 9, 1}

print(s1 | s2)       # union
print(s1 & s2)       # intersection
print(s1 - s2)       # difference
print({1, 7} <= s1)  # subset
```

### `sum_of_rows.py`
```python
import random

table = []
for i in range(5):            # 5 rows of 3 random values
    row = []
    for j in range(3):
        row.append(random.randint(0, 19))
    table.append(row)

for row in table:             # add each row's sum at its end
    row.append(sum(row))

for row in table:
    for x in row:
        print(f"{x:4}", end="")
    print()
```

### `transpose.py`
```python
def transpose(m):
    """Return m with its rows and columns swapped."""
    result = []
    for col in range(len(m[0])):
        new_row = []
        for row in range(len(m)):
            new_row.append(m[row][col])
        result.append(new_row)
    return result

sales = [[10, 12, 20, 12],
         [12, 14, 25, 18]]
for row in transpose(sales):
    print(row)
```

### `tuple_keys.py`
```python
names = {(0, 0): "corner", (1, 1): "centre"}
print(names[(1, 1)])

names[(0, 2)] = "corner"
print(len(names))

bad = {[0, 0]: "corner"}
```

### `two_courses.py`
```python
intro = {"maya", "noam", "dana", "yoni"}
calculus = {"dana", "omer", "maya"}

print(sorted(intro & calculus))    # in both
print(sorted(intro - calculus))    # intro only
print(len(intro | calculus))       # in either

visits = ["maya", "noam", "maya", "dana", "maya"]
print(f"{len(visits)} visits, {len(set(visits))} people")
```

### `word_count.py`
```python
text = "the cat saw the dog and the dog saw the cat"

counts = {}
for word in text.split():
    if word in counts:
        counts[word] = counts[word] + 1
    else:
        counts[word] = 1

for word, n in counts.items():
    print(word, n)
```

### `word_count_get.py`
```python
text = "the cat saw the dog and the dog saw the cat"

counts = {}
for word in text.split():
    counts[word] = counts.get(word, 0) + 1

print(counts["the"], counts["dog"], counts["and"])
print(counts.get("bird", 0))
```


---

# Lecture 6-1: Files (week 6)

## Slide 1: Files
.txt
PYTHON COURSE · WEEK 6 · LECTURE 1
Files
Reading and writing data
Reichman University

## Slide 2: Where a program's data comes from
Where a program's data comes from
So far we used only the first two.
In the code: ratings = [[4, 5, 4], ...]
The keyboard: input(), gone when the program ends
A file: on the disk before and after the run
Another program: its output is our input

## Slide 3: The big picture
The big picture
Programs reach devices through Python and the operating system.
Your program
open, read, print
Python
the input/output library
Operating system
folders, files, drivers
Keyboard
Screen
Disk: files
devices

## Slide 4: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 5: What a text file is
What a text file is
A name: demo.dat, grades.csv, notes.txt
A place: it lives in a folder on the disk
Contents: characters, one line after another
Line breaks: a special character, \n, ends each line

## Slide 6: A file is one long string
A file is one long string
Lines are separated by \n characters.
```python
demo.dat in an editor
4
1 1 2 
0 1 3 0 3
0 1
```
```python
4
```
```python
\n
```
```python
1
```
```python
·
```
```python
1
```
```python
·
```
```python
2
```
```python
·
```
```python
\n
```
```python
0
```
```python
·
```
```python
1
```
```python
·
```
```python
3
```
```python
·
```
```python
0
```
```python
·
```
```python
3
```
```python
\n
```
```python
0
```
```python
·
```
```python
1
```
```python
\n
```
what is stored: 23 characters  ·  “·” is a space, “\n” ends a line

## Slide 7: Reading a whole file
Reading a whole file
```python
python read_whole.py
'4\n1 1 2 \n0 1 3 0 3\n0 1\n'
4
1 1 2 
0 1 3 0 3
0 1
```
`read_whole.py`
```python
with open("demo.dat") as f:
    text = f.read()

print(repr(text))
print(text)
```
[LIVE] the file is in “week 6 code / read_whole.py”.

## Slide 8: The with statement
The with statement
`read_whole.py`
```python
with open("demo.dat") as f:
    text = f.read()

print(repr(text))
print(text)
```
open(name)
Finds the file, opens it to read.
with … as f:
Names it f; closes it at the end.
f.read()
The whole contents, as one str.

## Slide 9: Reading line by line
Reading line by line
```python
python read_lines.py
'4\n' ['4']
'1 1 2 \n' ['1', '1', '2']
'0 1 3 0 3\n' ['0', '1', '3', '0', '3']
'0 1\n' ['0', '1']
```
`read_lines.py`
```python
with open("demo.dat") as f:
    for line in f:
        print(repr(line), line.split())
```
[LIVE] the file is in “week 6 code / read_lines.py”.

## Slide 10: From text to numbers
From text to numbers
Always text: whatever is read from a file is a str
strip(): removes spaces and \n from both ends
split(): cuts a line into words
int() and float(): turn one word into a number
"3" + "4" is "34".
Convert before you compute: int("3") + int("4") is 7.

## Slide 11: Counting the values in a file
Counting the values in a file
```python
python count_values.py
0: 3
1: 4
2: 1
3: 2
```
`count_values.py`
```python
# How often each number appears in demo.dat.
# The first number, n: the rest are 0 .. n-1.

with open("demo.dat") as f:
    tokens = f.read().split()

n = int(tokens[0])
count = [0] * n
for t in tokens[1:]:
    count[int(t)] += 1

for i in range(n):
    print(f"{i}: {count[i]}")
```
[LIVE] the file is in “week 6 code / count_values.py”.

## Slide 12: Where Python looks for a file
Where Python looks for a file
A bare name: "demo.dat" is looked for in the current folder
Current folder: where the terminal is when python starts
A path: "data/demo.dat" looks inside data
In an editor: Run may start in another folder

## Slide 13: When the file is not there
When the file is not there
```python
python missing_file.py
No such file: demo.txt
```
`missing_file.py`
```python
name = "demo.txt"        # a typo: it is demo.dat
try:
    with open(name) as f:
        print(f.read())
except FileNotFoundError:
    print("No such file:", name)
```
[LIVE] the file is in “week 6 code / missing_file.py”.

## Slide 14: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 15: A file of records
A file of records
One line per student; commas separate the fields.
```python
grades.csv
name,hw,exam
Dana,88,92
Noam,75,64
Maya,95,81
Yoni,52,58
```
The header
line 1 names the columns
A record
every other line: one student
Fields
line.split(",") separates them

## Slide 16: Reading the records
Reading the records
```python
python final_grades.py
Dana   90.8
Noam   67.3
Maya   85.2
Yoni   56.2
```
`final_grades.py`
```python
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        final = 0.3 * int(hw) + 0.7 * int(exam)
        print(f"{name:5} {final:5.1f}")
```
[LIVE] the file is in “week 6 code / final_grades.py”.

## Slide 17: A bigger file: 13,509 towns
A bigger file: 13,509 towns
```python
python usa_points.py
13509 towns
header: ['669905.0', '247205.0',
         '1244962.0', '700000.0']
x: 669905.556 to 1244961.111
y: 245552.778 to 490000.0
```
`usa_points.py`
```python
# USA.txt: a header line with the bounding box,
# then one "x y" pair per town.

with open("USA.txt") as f:
    header = f.readline().split()
    xs, ys = [], []
    for line in f:
        x, y = line.split()
        xs.append(float(x))
        ys.append(float(y))

print(len(xs), "towns")
print("header:", header)
print(f"x: {min(xs)} to {max(xs)}")
print(f"y: {min(ys)} to {max(ys)}")
```
[LIVE] the file is in “week 6 code / usa_points.py”.

## Slide 18: The points, plotted
The points, plotted
Each of the 13,509 points is one town.

## Slide 19: Check the data, not the header
Check the data, not the header
The header says: y goes up to 700000.0
The data says: y goes up to 490000.0
Conclusion: the header is wrong

## Slide 20: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 21: Writing a file
Writing a file
open(name, "w"): creates the file for writing
open(name, "a"): adds to the end of an existing file
f.write(s): writes exactly s; add \n yourself
print(x, file=f): prints into the file, not the screen
"w" empties the file first.
Opening an existing file with "w" deletes its contents.

## Slide 22: Writing, then reading back
Writing, then reading back
```python
python write_squares.py
1 1
2 4
3 9
4 16
5 25
```
`write_squares.py`
```python
with open("squares.txt", "w") as f:
    for i in range(1, 6):
        f.write(f"{i} {i * i}\n")

with open("squares.txt") as f:
    print(f.read(), end="")
```
[LIVE] the file is in “week 6 code / write_squares.py”.

## Slide 23: Read, decide, write
Read, decide, write
```python
python passed.py
3 names written to passed.txt

passed.txt:
Dana
Noam
Maya
```
`passed.py`
```python
passed = []
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        if 0.3 * int(hw) + 0.7 * int(exam) >= 60:
            passed.append(name)

with open("passed.txt", "w") as f:
    for name in passed:
        f.write(name + "\n")
print(len(passed), "names written to passed.txt")
```
[LIVE] the file is in “week 6 code / passed.py”.

## Slide 24: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 25: Standard input and output
Standard input and output
Standard output: print writes there; the screen, by default
Standard input: input() reads it; the keyboard, by default
sys.stdin: standard input, as a file
sys.argv: the words typed after python file.py

## Slide 26: A program that writes numbers
A program that writes numbers
```python
python random_numbers.py 3
0.4234137005317864
0.2984657006398488
0.7456080688315734
```
`random_numbers.py`
```python
import random
import sys

n = int(sys.argv[1])   # typed after the name
for i in range(n):
    print(random.random())
```
[LIVE] the file is in “week 6 code / random_numbers.py”.

## Slide 27: A program that reads numbers
A program that reads numbers
```python
python average.py
100
200
100
300
<Ctrl-D>
Average: 175.0
```
`average.py`
```python
import sys

total, count = 0.0, 0
for line in sys.stdin:   # one line at a time
    total += float(line)
    count += 1
print("Average:", total / count)
```
[LIVE] the file is in “week 6 code / average.py”.

## Slide 28: Redirection and pipes
Redirection and pipes
The terminal can send input and output to files or programs.
```python
>
```
`random_numbers.py`
`data.txt`
output goes into a file
```python
<
```
`data.txt`
`average.py`
input comes from a file
```python
|
```
`random_numbers.py`
`average.py`
one feeds the next
light boxes are programs; tinted boxes are files

## Slide 29: Redirection: examples
Redirection: examples
With a file, and with a pipe.
```python
terminal
% python random_numbers.py 1000 > data.txt
% python average.py < data.txt
Average: 0.49570948891636646
% python random_numbers.py 1000000 | python average.py
Average: 0.5007775704132853
```

## Slide 30: One program, different inputs
One program, different inputs
The keyboard: python average.py
A file: python average.py < data.txt
A pipe: … | python average.py
The code: unchanged

## Slide 31: Files in one slide
Files in one slide
Read
with open(name) as f
f.read(): the whole file
for line in f: line by line
f.readline(): one line
Convert
Everything read is a str
strip(), then split()
int() and float() on each word
Write
open(name, "w") erases first
open(name, "a") appends
write adds no line break
Standard I/O
print and input
sys.stdin, sys.argv
>  <  |  in the terminal


---

# Lecture 6-2: PageRank (week 6)

## Slide 1: PageRank
#1
PYTHON COURSE · WEEK 6 · LECTURE 2
PageRank
Ranking pages by their links
Reichman University

## Slide 2: The problem
The problem
A search for “python” matches millions of pages. Which come first?
Relevance: is the page about what was searched for?
Importance: do other pages link to it?
PageRank: a number for importance, from the links alone

## Slide 3: What makes a page important
What makes a page important
Visits: pages people reach often matter more
Who links in: links from important pages count more
The problem: the definition is circular

## Slide 4: History
History
1998: Stanford students Sergey Brin and Larry Page
The idea: rank pages by the links that point to them
What came of it: Google's first ranking method
Brin & Page, “The Anatomy of a Large-Scale Hypertextual Web Search Engine”:  infolab.stanford.edu/~backrub/google.html

## Slide 5: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 6: A tiny web of five pages
A tiny web of five pages
Each arrow is a link from one page to another.
0
1
2
3
4
×2
×2
```python
web.dat
5
0 1
1 2  1 2
1 3  1 3  1 4
2 3
3 0
4 0  4 2
```
first: the number of pages;
then “from to” pairs, one per link

## Slide 7: The random surfer
The random surfer
A model of one person clicking links.
90% of the time: click one of the page's links, at random
10% of the time: jump to a random page
A page's rank: the share of the time the surfer spends there

## Slide 8: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 9: Counting the links
Counting the links
links[i][j]: how many links go from page i to page j.
0
1
0
0
0
0
0
2
2
1
0
0
0
1
0
1
0
0
0
0
1
0
1
0
0
0
1
2
3
4
0
1
2
3
4
to page j
from page i
1
5
1
1
2
links out

## Slide 10: Reading the web
Reading the web
`web_links.py`
```python
def read_links(filename):
    """Reads n, then "from to" pairs, from a web file.
    Returns links: links[i][j] counts the i -> j links."""
    with open(filename) as f:
        tokens = f.read().split()
    n = int(tokens[0])
    links = []
    for i in range(n):
        links.append([0] * n)     # a new row each time
    for k in range(1, len(tokens), 2):
        links[int(tokens[k])][int(tokens[k + 1])] += 1
    return links
```
the file is in “week 6 code / web_links.py”.

## Slide 11: From counts to chances
From counts to chances
Row 1: page 1 has five links.
0
0
2
2
1
0
1
2
3
4
```python
links[1]
```
```python
p[1][j]  =  0.10 / 5   +   0.90 × links[1][j] / 5
```
jump anywhere          follow one of the 5 links
0.02
0.02
0.38
0.38
0.20
```python
p[1]
```
0.02 + 0.02 + 0.38 + 0.38 + 0.20 = 1

## Slide 12: The transition matrix
The transition matrix
Row i: where the surfer goes next from page i.
0.02
0.92
0.02
0.02
0.02
0.02
0.02
0.38
0.38
0.20
0.02
0.02
0.02
0.92
0.02
0.92
0.02
0.02
0.02
0.02
0.47
0.02
0.47
0.02
0.02
0
1
2
3
4
0
1
2
3
4
```python
p
```

## Slide 13: Building the transition matrix
Building the transition matrix
`transition.py`
```python
def transition_matrix(links, jump=0.10):
    """p[i][j]: the chance of moving from page i to j.
    Assumes every page has at least one link."""
    n = len(links)
    p = []
    for i in range(n):
        out = sum(links[i])       # links leaving page i
        row = []
        for j in range(n):
            follow = links[i][j] / out
            row.append(jump / n + (1 - jump) * follow)
        p.append(row)
    return p
```
the file is in “week 6 code / transition.py”.

## Slide 14: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 15: The algorithm
The algorithm
Simulating the surfer
visits = 0 for every page
page = 0
repeat T times:
pick the next page, with the chances in p[page]
add 1 to visits[page]
rank of page i = visits[i] / T

## Slide 16: Picking a random page
Picking a random page
Put the probabilities in a row; pick a random number in [0, 1).
0
1
2
3
4
page
0.38
0.38
0.20
0
0.04
0.42
0.80
1.00
r = 0.63 falls between 0.42 and 0.80  →  page 3

## Slide 17: Picking a page in Python
Picking a page in Python
`next_page.py`
```python
import random


def next_page(row):
    """Picks page j with probability row[j]."""
    r = random.random()           # somewhere in [0, 1)
    total = 0.0
    for j in range(len(row)):
        total += row[j]
        if r < total:
            return j
    return len(row) - 1           # in case of rounding
```
the file is in “week 6 code / next_page.py”.

## Slide 18: The surfer
The surfer
`surfer.py`
```python
from next_page import next_page


def simulate(p, moves):
    """Moves the surfer, starting on page 0. Returns
    the share of the moves that ended on each page."""
    visits = [0] * len(p)
    page = 0
    for t in range(moves):
        page = next_page(p[page])
        visits[page] += 1
    ranks = []
    for v in visits:
        ranks.append(v / moves)
    return ranks
```
the file is in “week 6 code / surfer.py”.

## Slide 19: Putting it together
Putting it together
```python
python pagerank.py   (moves, then pages 0–4)
      100  0.250  0.260  0.150  0.280  0.060
   10,000  0.276  0.267  0.143  0.246  0.068
1,000,000  0.273  0.266  0.146  0.247  0.068
```
`pagerank.py`
```python
from web_links import read_links
from transition import transition_matrix
from surfer import simulate

links = read_links("web.dat")
p = transition_matrix(links)
for moves in [100, 10_000, 1_000_000]:
    ranks = simulate(p, moves)
    print(f"{moves:>9,}", end="")
    for r in ranks:
        print(f"{r:7.3f}", end="")
    print()
```
[LIVE] the file is in “week 6 code / pagerank.py”.

## Slide 20: The ranks
The ranks
A million moves: the share of time spent on each page.
0.273
page 0
0.266
page 1
0.146
page 2
0.247
page 3
0.068
page 4

## Slide 21: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 22: Computing the probabilities directly
Computing the probabilities directly
Instead of one surfer: keep the chance of being on each page
At the start: all of it on page 0, [1, 0, 0, 0, 0]
One move: new[j] = the sum over i of rank[i] × p[i][j]
Repeat: until the numbers stop changing

## Slide 23: One move, in numbers
One move, in numbers
Each new row is the previous row times the transition matrix.
0
1
2
3
4
1
0
0
0
0
after 0 moves
0.020
0.920
0.020
0.020
0.020
after 1 move
0.047
0.038
0.360
0.369
0.186
after 2 moves
pages 0 to 4

## Slide 24: One move, in Python
One move, in Python
`power_step.py`
```python
def step(rank, p):
    """rank[i]: the chance of being on page i now.
    Returns the chances one move later."""
    n = len(rank)
    new = [0.0] * n
    for i in range(n):
        for j in range(n):
            new[j] += rank[i] * p[i][j]
    return new
```
the file is in “week 6 code / power_step.py”.

## Slide 25: Repeating the move
Repeating the move
```python
python power.py   (moves, then pages 0–4)
  1  0.020  0.920  0.020  0.020  0.020
  2  0.047  0.038  0.360  0.369  0.186
  3  0.436  0.062  0.117  0.358  0.027
 10  0.284  0.240  0.148  0.261  0.067
 20  0.272  0.265  0.147  0.248  0.068
 30  0.273  0.266  0.146  0.247  0.068
```
`power.py`
```python
from web_links import read_links
from transition import transition_matrix
from power_step import step

p = transition_matrix(read_links("web.dat"))
rank = [1.0, 0.0, 0.0, 0.0, 0.0]  # on page 0
for move in range(1, 31):
    rank = step(rank, p)
    if move in [1, 2, 3, 10, 20, 30]:
        print(f"{move:>3}", end="")
        for r in rank:
            print(f"{r:7.3f}", end="")
        print()
```
[LIVE] the file is in “week 6 code / power.py”.

## Slide 26: Simulation vs. exact computation
Simulation vs. exact computation
Simulation
One surfer, many random moves
Easy to explain and to write
Approximate: a million moves for 3 digits
Different every run
Repeated multiplication
A crowd, spread by the matrix
One move costs n × n steps
Exact: 30 moves for 3 digits here
The same answer every run

## Slide 27: Limitations
Limitations
Dead ends: a page with no links makes out zero
The usual fix: from a dead end, jump to any page
The 10%: the 1998 paper jumped 15% of the time
Scale: billions of pages, a few links on each

## Slide 28: PageRank in one slide
PageRank in one slide
Model
Pages and links
web.dat: n, then from–to pairs
links[i][j] counts them
Transition matrix
p[i][j]: jump, or follow a link
Rows sum to 1
Simulation
Pick the next page with given chances
Count the visits
More moves, steadier ranks
Exact
new[j] = Σ rank[i] × p[i][j]
Repeat until it stops changing


---

# Week 6 code files

The code files shown in the week 6 lectures.

### `USA.txt`
(data file, 391,799 bytes, not included)

### `average.py`
```python
import sys

total, count = 0.0, 0
for line in sys.stdin:   # one line at a time
    total += float(line)
    count += 1
print("Average:", total / count)
```

### `count_values.py`
```python
# How often each number appears in demo.dat.
# The first number, n: the rest are 0 .. n-1.

with open("demo.dat") as f:
    tokens = f.read().split()

n = int(tokens[0])
count = [0] * n
for t in tokens[1:]:
    count[int(t)] += 1

for i in range(n):
    print(f"{i}: {count[i]}")
```

### `demo.dat`
```
4
1 1 2 
0 1 3 0 3
0 1
```

### `final_grades.py`
```python
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        final = 0.3 * int(hw) + 0.7 * int(exam)
        print(f"{name:5} {final:5.1f}")
```

### `grades.csv`
```
name,hw,exam
Dana,88,92
Noam,75,64
Maya,95,81
Yoni,52,58
```

### `missing_file.py`
```python
name = "demo.txt"        # a typo: it is demo.dat
try:
    with open(name) as f:
        print(f.read())
except FileNotFoundError:
    print("No such file:", name)
```

### `next_page.py`
```python
import random


def next_page(row):
    """Picks page j with probability row[j]."""
    r = random.random()           # somewhere in [0, 1)
    total = 0.0
    for j in range(len(row)):
        total += row[j]
        if r < total:
            return j
    return len(row) - 1           # in case of rounding
```

### `pagerank.py`
```python
from web_links import read_links
from transition import transition_matrix
from surfer import simulate

links = read_links("web.dat")
p = transition_matrix(links)
for moves in [100, 10_000, 1_000_000]:
    ranks = simulate(p, moves)
    print(f"{moves:>9,}", end="")
    for r in ranks:
        print(f"{r:7.3f}", end="")
    print()
```

### `passed.py`
```python
passed = []
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        if 0.3 * int(hw) + 0.7 * int(exam) >= 60:
            passed.append(name)

with open("passed.txt", "w") as f:
    for name in passed:
        f.write(name + "\n")
print(len(passed), "names written to passed.txt")
```

### `power.py`
```python
from web_links import read_links
from transition import transition_matrix
from power_step import step

p = transition_matrix(read_links("web.dat"))
rank = [1.0, 0.0, 0.0, 0.0, 0.0]  # on page 0
for move in range(1, 31):
    rank = step(rank, p)
    if move in [1, 2, 3, 10, 20, 30]:
        print(f"{move:>3}", end="")
        for r in rank:
            print(f"{r:7.3f}", end="")
        print()
```

### `power_step.py`
```python
def step(rank, p):
    """rank[i]: the chance of being on page i now.
    Returns the chances one move later."""
    n = len(rank)
    new = [0.0] * n
    for i in range(n):
        for j in range(n):
            new[j] += rank[i] * p[i][j]
    return new
```

### `random_numbers.py`
```python
import random
import sys

n = int(sys.argv[1])   # typed after the name
for i in range(n):
    print(random.random())
```

### `read_lines.py`
```python
with open("demo.dat") as f:
    for line in f:
        print(repr(line), line.split())
```

### `read_whole.py`
```python
with open("demo.dat") as f:
    text = f.read()

print(repr(text))
print(text)
```

### `redirection.txt`
```
Terminal transcript (macOS / Linux shell), not a Python file.
% python random_numbers.py 1000 > data.txt
% python average.py < data.txt
Average: 0.49570948891636646
% python random_numbers.py 1000000 | python average.py
Average: 0.5007775704132853
```

### `surfer.py`
```python
from next_page import next_page


def simulate(p, moves):
    """Moves the surfer, starting on page 0. Returns
    the share of the moves that ended on each page."""
    visits = [0] * len(p)
    page = 0
    for t in range(moves):
        page = next_page(p[page])
        visits[page] += 1
    ranks = []
    for v in visits:
        ranks.append(v / moves)
    return ranks
```

### `transition.py`
```python
def transition_matrix(links, jump=0.10):
    """p[i][j]: the chance of moving from page i to j.
    Assumes every page has at least one link."""
    n = len(links)
    p = []
    for i in range(n):
        out = sum(links[i])       # links leaving page i
        row = []
        for j in range(n):
            follow = links[i][j] / out
            row.append(jump / n + (1 - jump) * follow)
        p.append(row)
    return p
```

### `usa_points.py`
```python
# USA.txt: a header line with the bounding box,
# then one "x y" pair per town.

with open("USA.txt") as f:
    header = f.readline().split()
    xs, ys = [], []
    for line in f:
        x, y = line.split()
        xs.append(float(x))
        ys.append(float(y))

print(len(xs), "towns")
print("header:", header)
print(f"x: {min(xs)} to {max(xs)}")
print(f"y: {min(ys)} to {max(ys)}")
```

### `web.dat`
```
5
0 1
1 2  1 2
1 3  1 3  1 4
2 3
3 0
4 0  4 2
```

### `web_links.py`
```python
def read_links(filename):
    """Reads n, then "from to" pairs, from a web file.
    Returns links: links[i][j] counts the i -> j links."""
    with open(filename) as f:
        tokens = f.read().split()
    n = int(tokens[0])
    links = []
    for i in range(n):
        links.append([0] * n)     # a new row each time
    for k in range(1, len(tokens), 2):
        links[int(tokens[k])][int(tokens[k + 1])] += 1
    return links
```

### `write_squares.py`
```python
with open("squares.txt", "w") as f:
    for i in range(1, 6):
        f.write(f"{i} {i * i}\n")

with open("squares.txt") as f:
    print(f.read(), end="")
```
