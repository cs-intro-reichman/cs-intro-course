# Lecture 5-1: Lists, part 2: comprehensions, lists in action, tables (week 5)

## Slide 1: Lists, Part 2
[i][j]
PYTHON COURSE · WEEK 5 · LECTURE 1
Lists, Part 2
Comprehensions, lists in action, tables
Reichman University

## Slide 2: Today: lists, part 2
Today: lists, part 2
Three parts.
List comprehensions
lists in one line
Lists in action
cards, coupons, primes
Two-dimensional lists
tables and grids

## Slide 3: From a loop to a comprehension
From a loop to a comprehension
```python
python squares.py
[1, 4, 9, 16, 25]
[1, 4, 9, 16, 25]
```
`squares.py`
```python
# The loop way
squares = []
for k in range(1, 6):
    squares.append(k * k)
print(squares)

# The same list, in one line
squares = [k * k for k in range(1, 6)]
print(squares)
```

## Slide 4: Reading a comprehension
Reading a comprehension
Read it from the middle: first the loop, then the value.
`squares.py`
```python
squares = [k * k for k in range(1, 6)]
```
```python
for k in range(1, 6)
The loop: k takes the values 1 to 5, one by one.
```
```python
k * k
The value: computed for each k and put in the list.
```
```python
[ ]
The brackets: the values are collected into a new list.
```

## Slide 5: Keeping only some items
Keeping only some items
```python
python keep_some.py
[4, 2, 8]
['GRID', 'MATRIX', 'CELL']
```
`keep_some.py`
```python
numbers = [4, 9, 15, 2, 8, 23]
evens = [n for n in numbers if n % 2 == 0]
print(evens)

words = ["grid", "row", "matrix", "cell"]
long_words = [w.upper() for w in words if len(w) > 3]
print(long_words)
```

## Slide 6: When to use a comprehension
When to use a comprehension
Use it: to build a new list from a list or a range
Keep it short: if it needs two lines to explain, write the loop
Not for actions: a loop that prints or changes things stays a loop
Same result: a loop with append can build anything it builds

## Slide 7: Today: lists, part 2
Today: lists, part 2
Three parts.
List comprehensions
lists in one line
Lists in action
cards, coupons, primes
Two-dimensional lists
tables and grids

## Slide 8: The coupon collector problem
The coupon collector problem
The story: 100 different baseball cards, one in every cereal box
The question: how many boxes until you have all 100?
In general: draw random numbers from 0 to n − 1 until each has come up
The tool: a list of True and False, one entry per card

## Slide 9: Coupon collector: the algorithm
Coupon collector: the algorithm
In pseudocode
found = n values, all False
count = 0, distinct = 0
while distinct < n:
draw a random card c
add 1 to count
if found[c] is False:
found[c] = True
add 1 to distinct
report count
Why a list?
found[c] answers “do we have card c?” in one step.

The card number is the index into the list.

## Slide 10: Coupon collector: the program
Coupon collector: the program
```python
in the REPL
>>> import coupons
>>> coupons.collect(100)
679
>>> coupons.collect(100)
506
>>> coupons.collect(100)
569
```
`coupons.py`
```python
"""The coupon collector, as a function."""
import random


def collect(n):
    """Return the boxes needed to collect all n cards."""
    found = [False] * n      # found[c]: got card c yet?
    count = 0                # boxes bought
    distinct = 0             # different cards found
    while distinct < n:
        card = int(random.random() * n)
        count += 1
        if not found[card]:
            found[card] = True
            distinct += 1
    return count
```

## Slide 11: Coupon collector: the experiment
Coupon collector: the experiment
```python
python coupon_experiment.py
10 trials: 551.9 boxes
100 trials: 509.7 boxes
10000 trials: 519.8 boxes
theory: 518.7 boxes
```
`coupon_experiment.py`
```python
# How many boxes does it take, on average?
import coupons

n = 100
for trials in [10, 100, 10000]:
    results = [coupons.collect(n) for _ in range(trials)]
    average = sum(results) / trials
    print(f"{trials} trials: {round(average, 1)} boxes")

theory = sum([n / k for k in range(1, n + 1)])
print(f"theory: {round(theory, 1)} boxes")
```

## Slide 12: Prime numbers
Prime numbers
A prime: a whole number above 1 whose only divisors are 1 and itself
They thin out: 8 primes below 20, but only 983, 991 and 997 from 980 to 1000
They never run out: Euclid proved it, around 300 BCE
October 2024: a new prime was found, with 41,024,320 digits

## Slide 13: The sieve of Eratosthenes
The sieve of Eratosthenes
Cross out the multiples of each prime. What is left is prime.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
1
1 is not prime
4
6
8
10
12
14
16
18
20
22
24
26
28
30
p = 2
9
15
21
27
p = 3
25
p = 5
2
3
5
7
11
13
17
19
23
29
10 primes

## Slide 14: The sieve: the program
The sieve: the program
```python
python sieve.py
2 3 5 7 11 13 17 19 23 29 
10 primes up to 30
```
`sieve.py`
```python
n = 30
is_prime = [True] * (n + 1)    # is k still in?
is_prime[0] = False
is_prime[1] = False
for p in range(2, n + 1):
    if is_prime[p]:
        # cross out the multiples of p
        for m in range(2 * p, n + 1, p):
            is_prime[m] = False

primes = [k for k in range(n + 1) if is_prime[k]]
for p in primes:
    print(p, end=" ")
print()
print(f"{len(primes)} primes up to {n}")
```

## Slide 15: The thinning of the primes
The thinning of the primes
```python
python thinning.py
100: 25 primes, 25%
10000: 1229 primes, 12%
1000000: 78498 primes, 8%
```
`thinning.py`
```python
def count_primes(n):
    """Return the number of primes from 2 to n."""
    is_prime = [True] * (n + 1)
    is_prime[0] = False
    is_prime[1] = False
    for p in range(2, n + 1):
        if is_prime[p]:
            for m in range(2 * p, n + 1, p):
                is_prime[m] = False
    return len([k for k in range(n + 1) if is_prime[k]])


for n in [100, 10000, 1000000]:
    count = count_primes(n)
    share = round(100 * count / n)
    print(f"{n}: {count} primes, {share}%")
```

## Slide 16: Building a deck of cards
Building a deck of cards
```python
python deck.py
52 cards
2 of Clubs
2 of Diamonds
2 of Hearts
2 of Spades
3 of Clubs
...
Ace of Spades
```
`deck.py`
```python
ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10",
         "Jack", "Queen", "King", "Ace"]
suits = ["Clubs", "Diamonds", "Hearts", "Spades"]

deck = []
for rank in ranks:
    for suit in suits:
        deck.append(f"{rank} of {suit}")

print(f"{len(deck)} cards")
for card in deck[:5]:
    print(card)
print("...")
print(deck[-1])
```

## Slide 17: Shuffling
Shuffling
```python
python shuffle.py   (one run)
['4', '2', '3', 'A', '5', '6']
['4', '5', '3', 'A', '2', '6']
['4', '5', '6', 'A', '2', '3']
['4', '5', '6', '3', '2', 'A']
['4', '5', '6', '3', 'A', '2']
```
`shuffle.py`
```python
import random

deck = ["A", "2", "3", "4", "5", "6"]
n = len(deck)
for i in range(n - 1):
    # pick a random position r, from i to n - 1
    r = i + int(random.random() * (n - i))
    # swap the cards at positions i and r
    deck[i], deck[r] = deck[r], deck[i]
    print(deck)
```

## Slide 18: A fair shuffle
A fair shuffle
Fair: every order of the deck is equally likely
This algorithm: swap each position with a random later one, or itself
A common mistake: swapping with any random position is not fair
It matters: players beat a poker site that shuffled badly

## Slide 19: Today: lists, part 2
Today: lists, part 2
Three parts.
List comprehensions
lists in one line
Lists in action
cards, coupons, primes
Two-dimensional lists
tables and grids

## Slide 20: Data in rows and columns
Data in rows and columns
A lot of data comes as tables.
Ratings: reviewers down the side, movies across the top
Images: rows and columns of pixels
Sales: models down the side, quarters across
Game boards: a 3 × 3 tic-tac-toe grid

## Slide 21: A table of ratings
A table of ratings
Each value is found by two numbers: a row and a column.
4
5
4
5
4
5
3
4
4
4
3
4
3
5
3
0
1
2
3
4
0
1
2
movie (column)
reviewer (row)
row 1, column 2  →  reviewer 1 gave movie 2 a 4

## Slide 22: An image is a table
An image is a table
Each number is one pixel: 1 is dark, 0 is light.
0
0
0
0
0
0
0
0
0
0
1
1
1
1
0
0
0
0
0
1
1
1
1
0
0
0
0
0
1
1
1
1
0
0
0
0
0
0
0
0
what the list stores
what the screen shows

## Slide 23: A list of lists
A list of lists
A row: an ordinary list, like [4, 5, 4, 5, 4]
The table: a list whose items are the rows
One value: ratings[row][col], row first, then column
Its size: len(ratings) rows, len(ratings[0]) columns

## Slide 24: Writing a table in Python
Writing a table in Python
```python
python ratings.py
4
[5, 3, 4, 4, 4]
3
5
```
`ratings.py`
```python
# rows are reviewers, columns are movies
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

print(ratings[1][2])     # reviewer 1, movie 2
print(ratings[1])        # all of row 1
print(len(ratings))      # number of rows
print(len(ratings[0]))   # number of columns
```

## Slide 25: A list of lists in memory
A list of lists in memory
The outer list holds three references, one to each row.
```python
ratings
```
0
1
2
4
5
4
5
4
```python
ratings[0]
```
5
3
4
4
4
```python
ratings[1]
```
3
4
3
5
3
```python
ratings[2]
```

## Slide 26: Reading ratings[1][2]
Reading ratings[1][2]
Two indexes, two steps: first pick a row, then pick a cell.
```python
ratings
```
the table
5
3
4
4
4
ratings[1] picks a row
4
…[2] picks a cell in it

## Slide 27: Two-dimensional lists: the plan
Two-dimensional lists: the plan
Four things to do with a table.
Lists of lists
Visiting every cell
Building grids
Matrix operations

## Slide 28: Printing every cell
Printing every cell
```python
python print_table.py
   4   5   4   5   4
   5   3   4   4   4
   3   4   3   5   3
```
`print_table.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

for row in range(len(ratings)):
    for col in range(len(ratings[row])):
        print(f"{ratings[row][col]:4}", end="")
    print()
```

## Slide 29: Reading the nested loop
Reading the nested loop
`print_table.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

for row in range(len(ratings)):
    for col in range(len(ratings[row])):
        print(f"{ratings[row][col]:4}", end="")
    print()
```
Outer loop
One pass for each row.
Inner loop
One pass for each column of that row.
end="" and print()
Stay on the line; then end the row.

## Slide 30: Format specs in f-strings
Format specs in f-strings
`format_specs.py`
```python
# [ ] mark the edges of each value
x = 7
r = 2 / 3
n = 1234567
name = "Dana"
print(f"[{x}]")         # [7]
print(f"[{x:4}]")       # [   7]
print(f"[{r:.3f}]")     # [0.667]
print(f"[{r:7.3f}]")    # [  0.667]
print(f"[{n:,}]")       # [1,234,567]
print(f"[{n:>12,}]")    # [   1,234,567]
print(f"[{name:6}]")    # [Dana  ]
```
```python
Width
{x:4} uses at least 4 characters.
```
```python
Decimal places
{r:.3f} keeps 3 decimal places.
```
```python
Thousands
{n:,} adds a comma every 3 digits.
```
```python
Alignment
Numbers go right, text goes left.
> forces right.
```

## Slide 31: The order of the visits
The order of the visits
Row by row, and left to right inside each row.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
0
1
2
3
4
0
1
2
The numbers show when each cell is visited: 15 visits in all.

## Slide 32: Sum of each row
Sum of each row
```python
one run (random)
   7   9   3  19
  12  15   4  31
   2   2   0   4
  12  17   9  38
   1   7  16  24
```
`sum_of_rows.py`
```python
import random

table = []
for i in range(5):            # 5 rows of 3 random values
    row = []
    for j in range(3):
        row.append(random.randint(0, 19))
    table.append(row)

for row in table:             # add each row's sum at its end
    row.append(sum(row))

for row in table:
    for x in row:
        print(f"{x:4}", end="")
    print()
```

## Slide 33: Rows and columns
Rows and columns
A row: already a list; for row in table gives it
A column: no list holds it; we have to collect it
Solution: loop over the rows, take [col] from each

## Slide 34: Average of each column
Average of each column
```python
python column_averages.py
movie 0: 4.0
movie 1: 4.0
movie 2: 3.67
movie 3: 4.67
movie 4: 3.67
```
`column_averages.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]
rows = len(ratings)
cols = len(ratings[0])

# the average rating of each movie (a column)
for col in range(cols):
    total = 0
    for row in range(rows):
        total = total + ratings[row][col]
    print(f"movie {col}: {round(total / rows, 2)}")
```

## Slide 35: Two-dimensional lists: the plan
Two-dimensional lists: the plan
Four things to do with a table.
Lists of lists
Visiting every cell
Building grids
Matrix operations

## Slide 36: Building a grid
Building a grid
```python
python make_grid.py
. . .
. X .
. . .
```
`make_grid.py`
```python
def make_grid(rows, cols, value):
    """Return a rows x cols grid filled with value."""
    grid = []
    for i in range(rows):
        grid.append([value] * cols)
    return grid

board = make_grid(3, 3, ".")
board[1][1] = "X"
for row in board:
    print(" ".join(row))
```

## Slide 37: A common bug: one row, three times
A common bug: one row, three times
```python
python grid_trap.py
. X .
. X .
. X .
True
```
`grid_trap.py`
```python
board = [["."] * 3] * 3      # looks like a 3 x 3 grid
board[1][1] = "X"
for row in board:
    print(" ".join(row))

print(board[0] is board[2])
```

## Slide 38: Why every row changed
Why every row changed
Multiplying the outer list copies the reference, not the row.
0
1
2
```python
board
```
.
X
.
the one and only row
Multiplying a list repeats references, not rows.
Build every row separately, with a loop or a comprehension.

## Slide 39: Building a grid, the short way
Building a grid, the short way
```python
python grid_comprehension.py
. . . .
. X . .
. . . .
False
```
`grid_comprehension.py`
```python
rows, cols = 3, 4
board = [["."] * cols for _ in range(rows)]
board[1][1] = "X"
for row in board:
    print(" ".join(row))

print(board[0] is board[2])
```

## Slide 40: Comprehensions on a table
Comprehensions on a table
```python
python table_comprehension.py
[4, 4, 3]
[22, 20, 18]
[4, 5, 3]
[5, 3, 4]
[4, 4, 3]
[5, 4, 5]
[4, 4, 3]
```
`table_comprehension.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

# one column: movie 2
print([row[2] for row in ratings])

# one number per row: each reviewer's total
print([sum(row) for row in ratings])

# transpose: column c becomes row c
flipped = [[row[c] for row in ratings]
           for c in range(len(ratings[0]))]
for row in flipped:
    print(row)
```

## Slide 41: Two-dimensional lists: the plan
Two-dimensional lists: the plan
Four things to do with a table.
Lists of lists
Visiting every cell
Building grids
Matrix operations

## Slide 42: Matrices
Matrices
A matrix: a rectangular table of numbers
Addition: add matching cells; same shape needed
Multiplication: a row of the left times a column of the right
The condition: columns of the left = rows of the right

## Slide 43: Multiplying two matrices
Multiplying two matrices
One cell of the answer: a row of a, times a column of b.
7
2
1
3
6
1
5
1
4
```python
a
```
8
3
5
1
4
1
1
3
4
```python
b
```
59
32
41
31
36
25
45
31
42
```python
c
```
×
=
c[0][0]  =  7 · 8  +  2 · 1  +  1 · 1  =  59
row 0 of a, times column 0 of b

## Slide 44: Adding two matrices
Adding two matrices
`matrix_add.py`
```python
def add(m1, m2):
    """Return m1 + m2. Assumes equal dimensions."""
    result = []
    for i in range(len(m1)):
        row = []
        for j in range(len(m1[0])):
            row.append(m1[i][j] + m2[i][j])
        result.append(row)
    return result
```

## Slide 45: Multiplying two matrices
Multiplying two matrices
`matrix_mult.py`
```python
def mult(m1, m2):
    """Return m1 x m2. Assumes len(m1[0]) == len(m2)."""
    rows = len(m1)
    cols = len(m2[0])
    inner = len(m2)
    result = []
    for i in range(rows):
        row = []
        for j in range(cols):
            total = 0
            for k in range(inner):
                total = total + m1[i][k] * m2[k][j]
            row.append(total)
        result.append(row)
    return result
```

## Slide 46: Printing a matrix
Printing a matrix
`matrix_print.py`
```python
def print_matrix(m):
    """Print m row by row, then a blank line."""
    for row in m:
        for x in row:
            print(f"{x:5}", end="")
        print()
    print()
```

## Slide 47: Using the matrix functions
Using the matrix functions
```python
python matrix_demo.py
   15    5    6
    4   10    2
    6    4    8

   59   32   41
   31   36   25
   45   31   42

  119   59   54
   75   79   38
  103   51   64
```
`matrix_demo.py`
```python
from matrix_add import add
from matrix_mult import mult
from matrix_print import print_matrix

a = [[7, 2, 1],
     [3, 6, 1],
     [5, 1, 4]]
b = [[8, 3, 5],
     [1, 4, 1],
     [1, 3, 4]]

print_matrix(add(a, b))
print_matrix(mult(a, b))
print_matrix(mult(a, add(a, b)))   # a x (a + b)
```
```python
from matrix_add import add brings in just the name add.
So we call add(a, b), not matrix_add.add(a, b).
```

## Slide 48: Transpose
Transpose
```python
python transpose.py
[10, 12]
[12, 14]
[20, 25]
[12, 18]
```
`transpose.py`
```python
def transpose(m):
    """Return m with its rows and columns swapped."""
    result = []
    for col in range(len(m[0])):
        new_row = []
        for row in range(len(m)):
            new_row.append(m[row][col])
        result.append(new_row)
    return result

sales = [[10, 12, 20, 12],
         [12, 14, 25, 18]]
for row in transpose(sales):
    print(row)
```

## Slide 49: Two-dimensional lists in one slide
Two-dimensional lists in one slide
Create
Write the rows inside [ ]
Or build each row in a loop
Or use a comprehension
Never [[x] * m] * n
Read
t[r][c]: row first, then column
len(t) is the number of rows
len(t[0]) is the number of columns
Traverse
Outer loop over the rows
Inner loop over the columns
Columns need indexes
Compute
add: cell by cell
mult: row times column
transpose: swap r and c


---

# Lecture 5-2: Dictionaries and sets (week 5)

## Slide 1
INTRO TO CS COURSE · WEEK 5 · LECTURE 2
Dictionaries and Sets
Reaching a value by name

## Slide 2
Lecture overview
1
Dictionaries
a value reached by its key
2
Keys
what can be one, and why
3
Patterns
counting, functions, nesting
4
Sets
when only membership matters
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 3
Why lists and tuples aren’t enough
Revisiting student records (week 4) – storing dynamic records (name & grade) while enabling fast lookup by name.
`find_student_list.py`
```python
for name, grade in students:
    if name == "Ron Cohen":
        print(name, grade)   # Ron Cohen 95
        break
```
The core problems
Code overhead: Multi-line unpacking code for a basic query.
Sequential search: Must check items one by one until match is found (or not).
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
✗
✓
name
position
value
a middleman step we never wanted
```python
students
```
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 4
A dictionary
`first_dict.py`
```python
grades = {"Dana Levi": 88, 
	"Ron Cohen": 95,
          "Yael Bar": 73}

print(grades["Ron Cohen"])   # 95
grades["Ron Cohen"] = 100    # one line
```
What changed ?
The same data: Nothing added or dropped.
Direct addressing: Access values via unique keys instead of positions.
No sequential overhead: Bypasses earlier records to jump straight to the key.
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
Index-free structure: Eliminates positional middleman steps
    Key (name)
Value (grade)
Dictionary keys must be unique. Real-world systems often use unique identifiers (e.g., Student ID) as keys, storing composite data as values.
```python
grades
```
✓
A collection of key-value pairs, which allows direct access via key.
Item 

## Slide 5
```python
Square brackets [], in and not in
```
Some of a list's operators transfer to a dictionary, and some cannot.
`dict_basics.py`
```python
# grades is the same three students
print(grades["Ron Cohen"])        # 95
print(grades[0])                  # KeyError: 0
print("Ron Cohen" in grades)      # True
print("Tal Shani" not in grades)  # True
print(95 in grades)               # False
print(len(grades))                # 3
```
```python
What transfers, and what does not
The bracket: a key, not a position.
in / not in: about keys, not values.
len: how many pairs.
No slicing, + or *: there is no order.
```
```python
[ ]
```
```python
in
```
```python
not in
```
these transfer
```python
[ : : ]
```
```python
+
```
```python
*
```
a dictionary has none of these
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 6
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Omer Katz"
```
```python
91
```
```python
93
```
The four core dictionary operations
Add, change, remove and check membership.
`dict_ops.py`
```python
grades = {"Dana Levi": 88, "Ron Cohen": 95,
          "Yael Bar": 73}

grades["Omer Katz"] = 91       # add a new pair
grades["Dana Levi"] = 93       # change a value
grades.pop("Yael Bar")         # remove a pair
print("Ron Cohen" in grades)   # True
print(grades)
# {'Dana Levi': 93, 'Ron Cohen': 95,
#  'Omer Katz': 91}
```
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
```python
"Omer Katz"
```
```python
91
```
```python
93
```
✗
```python
Common pitfalls
Assignment does both: Adds, or replaces.
in asks about keys: Not about values.
.pop on a missing key: Raises a KeyError.
```
```python
grades
```

## Slide 7
Handling missing keys
```python
The KeyError exception and two approaches for safe access.
```
`keyerror.py`
```python
grades = {"Dana Levi": 88, "Ron Cohen": 95}

print(grades["Tal Shani"])
# KeyError: 'Tal Shani'
```
`get.py`
```python
# option 1: in
if "Tal Shani" in grades:        # ask first
    print(grades["Tal Shani"])
# option 2: .get()
print(grades.get("Tal Shani"))           # None
print(grades.get('Tal Shani', 'n/a'))    # 'n/a'
```
```python
Safe retrieval options
Membership check first - in: 
Using    if key in dict:  before accessing a key.
Default fallback - .get()
Returns None (or custom default)   instead of crashing.
```
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
grades
```

## Slide 8
Keys must be immutable
`key_types.py`
```python
# a number, a string or a tuple - never a list
grades[("Yael", "Bar")] = 73    # a tuple: fine
grades[["Yael", "Bar"]] = 73    # a list: no
# TypeError: unhashable type: 'list'
```
Why is it so important ? 
The rule: Keys must be immutable (numbers, strings, tuples)
The reason: A key's value determines its lookup position.
If it changed: The new position no longer matches where the data was originally placed.
The result: The stored data becomes unreachable.
0
1
2
3
4
```python
["Yael", "Bar"]
```
```python
73
```
```python
["Yael", "Barr"]
```
```python
?
```
✗
The slot is chosen by a number computed from the key itself. Change the key and the number is different — the pair stays in slot 2, and the key now points at an empty one.
Hypothetical: What if lists were allowed as keys ?
✗
✓
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 9
Common dictionary methods
method
what it does
example
```python
.get(k)
```
The value for k, or None when there is no such key.
```python
grades.get("Tal")
```
```python
.keys()
```
Every key, in the order the pairs were put in.
```python
list(grades.keys())
```
```python
.values()
```
Every value, in the same order.
```python
sum(grades.values())
```
```python
.items()
```
Every pair, each one a (key, value) tuple.
```python
list(grades.items())
```
```python
.pop(k)
```
Removes the pair and returns its value; KeyError if absent.
```python
grades.pop("Yael Bar")
```
```python
.update(d2)
```
Copies every pair of dictionary d2 in; a repeated key is 
overwritten.
```python
grades.update(more)
```
```python
.copy()
```
A copy of the dictionary - not a second name for this one.
```python
b = grades.copy()
```
```python
.clear()
```
Empties it, in place. It is the same dictionary.
```python
grades.clear()
```
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 10
Built-in functions that work on dictionaries
Functions, not methods: the dictionary goes inside the parentheses.
`builtins.py`
```python
print(len(grades))          # 3
print(sorted(grades))       # the keys
print(min(grades))          # 'Dana Levi'
print(max(grades))          # 'Yael Bar'
print(sum(grades))          # TypeError
print(sum(grades.values())) # 256
```
```python
Every one of them is applied on the keys - sorted, min and max order the keys and never a value. len counts pairs. 
For the values, ask: sum(grades.values()) is 256.
```
the keys
```python
len
```
```python
3
```
```python
sorted
```
```python
a list of the keys
```
```python
min
```
```python
"Dana Levi"
```
```python
max
```
```python
"Yael Bar"
```
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
```python
grades
```
```python
sum
```
```python
TypeError
```
the keys are names
sum adds the keys - so they must be numbers.

## Slide 11
Iterating over a dictionary
Iterating by keys, values or key-value pairs (items)
`loop_dict.py`
```python
for name in grades:             # the keys
    print(name)

for grade in grades.values():   # the values
    print(grade)

for name, grade in grades.items():   # both
    print(name, grade)
```
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
```python
"Dana Levi"
```
```python
"Ron Cohen"
```
```python
"Yael Bar"
```
```python
88
```
```python
95
```
```python
73
```
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
```python
Iteration patterns
Directly: you get the keys, not pairs.
Preferred: use .items() for both.
Tuple unpacking: for k, v in d.items()
The number of keys must hold still: never add or remove a key while looping over a dictionary. Loop over list(d) if you must.
```
```python
grades
```
```python
Note: Dictionary views
.keys(), .values() and .items() are dynamic views, not lists, and cannot be indexed.
Use list(d.keys()) if positional access is needed.
```
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 12
Dictionary key ordering
Guaranteed insertion order vs. explicit sorting
`ordering.py`
```python
grades["Omer Katz"] = 91   # added last

for name in sorted(grades):   # ask for order
    print(name, grades[name])
# Dana Levi 88
# Omer Katz 91
# Ron Cohen 95
# Yael Bar 73
```
Language vs. conceptual conventions
Official guarantee: Python maintains insertion order as of version 3.7.
Abstract dictionary concept: Assume no order.
```python
Best Practices
Predictable iteration: Iteration order matches entry insertion order.
Explicit sorting: Use sorted(d) when alphabetical or numerical order is required.
sorted(grades): Returns a list of the keys, in order.
```
Print your results sorted - a habit worth building now.

## Slide 13
Class exercise: Counting words
Task: How many times does each word appear in sentence?
`counting_v1.py`
```python
sentence = "The rain in Spain falls mainly in the plain"counts = {}               # create an empty dictionaryfor word in sentence.lower().split():    if word in counts:        counts[word] += 1    else:			        counts[word] = 1  # create a new entryprint(counts)
# {'the': 2, 'rain': 1, 'in': 2, 'spain': 1, 'falls': 1, 'mainly': 1, 'plain': 1}
```
`counting_v2.py`
```python
sentence = "The rain in Spain falls mainly in the plain"counts = {}               # create an empty dictionary
for word in sentence.lower().split():    counts[word] = counts.get(word, 0) + 1
print(counts)
# {'the': 2, 'rain': 1, 'in': 2, 'spain': 1,
#  'falls': 1, 'mainly': 1, 'plain': 1}
```

## Slide 14
Dictionaries alias, exactly like lists
Same picture, same rule, new type.
`dict_alias.py`
```python
a = {"x": 1}
b = a             # not a copy - a second name
b["y"] = 2
print(a)          # {'x': 1, 'y': 2}
print(a is b)     # True

c = dict(a)       # a real copy  (a.copy() too)
c["z"] = 3
print(a)          # {'x': 1, 'y': 2} - untouched
```
```python
"x"
```
```python
1
```
```python
"y"
```
```python
2
```
```python
a
```
```python
b
```
```python
"x"
```
```python
1
```
```python
"y"
```
```python
2
```
```python
"z"
```
```python
3
```
```python
c
```
```python
= gives a second name. dict(d) gives a second dictionary.
```
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 15
Passing dictionaries to functions
Just like lists, dictionaries are mutable: Modifying them inside a function affects the original object.
`dict_to_function.py`
```python
def add_grade(grades, name, grade):
    scores[name] = grade   # no return

grades_dict = {"Dana Levi": 88}
add_grade(grades_dict, "Ron Cohen", 95)
print(grades_dict)
# {'Dana Levi': 88, 'Ron Cohen': 95}
```
```python
"Dana Levi"
```
```python
88
```
inside add_grade
```python
grades_dict
```
```python
grades
```
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```

## Slide 16
Class exercise: a bonus for everyone
Task: add the same bonus to every student, and let nobody pass 100.
`add_bonus.py`
```python
def add_bonus(grades, points):
    for name in grades:
        new = grades[name] + points
        grades[name] = min(new, 100)

add_bonus(grades, 7)  # it returns None
print(grades)
# {'Dana Levi': 95, 'Ron Cohen': 100,
#  'Yael Bar': 80}
```
inside add_bonus
```python
"Dana Levi"
```
```python
88
```
```python
95
```
```python
"Ron Cohen"
```
```python
95
```
```python
100
```
```python
"Yael Bar"
```
```python
73
```
```python
80
```
old
new
```python
grades
```
```python
grades
```
the same dictionary
Each slot is re-pointed to a new number. The dictionary itself is never replaced - that is why the caller sees the change.

## Slide 17
Returning a dictionary from a function
Task: Turn the list of records from the first slides into a dictionary.
`build_index.py`
```python
def build_index(students):
    grades = {}
    for name, grade in students:
        grades[name] = grade
    return grades

grades = build_index(students)
print(grades["Ron Cohen"])   # 95
print(students)   # still the list it was
```
inside build_index
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
```python
students
```
```python
students
```
the same list
```python
"Dana Levi"
```
```python
88
```
```python
"Ron Cohen"
```
```python
95
```
```python
"Yael Bar"
```
```python
73
```
```python
grades
```
```python
grades
```
a new dictionary
The input list remains untouched. 
The function creates and returns a new dictionary.

## Slide 18
Dictionary comprehension
The comprehension from the last lecture, with one character added.
`build_index.py`
```python
def build_index(students):
    grades = {}
    for name, grade in students:
        grades[name] = grade
    return grades
```
`dict_comp.py`
```python
grades = {name: grade for name, grade in students}
print(grades)
# {'Dana Levi': 88, 'Ron Cohen': 95, 'Yael Bar': 73}

grades["Omer Katz"] = 91
```
```python
honours = {name: g for name, g in grades.items() if g >= 90}
print(honours)      # {'Ron Cohen': 95, 'Omer Katz': 91}
```
```python
curved = {name: g + 5 for name, g in grades.items()}
print(grades)       # unchanged
```
Mutate vs. return
changes what it was given
builds a new one and returns it
a comprehension is always here
Read it from the middle: first the loop, then the value — the reading rule from Lecture 5-1.
The colon is the only new character: brackets collect values, braces with key: value collect pairs.
A comprehension always builds a new dictionary and hands it back; it can never change the one it reads.

## Slide 19
Class exercise: Merging two dictionaries
Task: Merge two dictionaries. If a key is in both, the second dictionary wins.
`merge_bug.py`
```python
def merge(dict1, dict2):
    my_dict = dict1
    for k, v in dict2.items():
        my_dict[k] = v
    return my_dict

salaries = {"Eli": 1000, "Noam": 2000,
            "Shahar": 3000}
raises   = {"Yotam": 1800, "Moshe": 4000,
            "Shahar": 7000}
print(merge(salaries, raises))   # correct!
print(salaries)   # ... and destroyed
```
```python
"Eli"
```
```python
1000
```
```python
"Noam"
```
```python
2000
```
```python
dict1
```
```python
my_dict
```
```python
"Yotam"
```
```python
1800
```
Correct return value, corrupted input data.
```python
The hidden bug: Unexpected mutation
Invisible side effects: The return value looks correct, hiding the fact that input data was changed.
Aliasing bug: my_dict = dict1 creates an alias, not a new dictionary. Changing my_dict will cause dict1 to change too.
The fix: Create a new copy using my_dict = dict1.copy() or my_dict = dict(dict1).
```

## Slide 20
Complex values in dictionaries
Values can store lists, tuples or nested dictionaries – accessed in steps.
`nested_dict.py`
```python
school = {"Noa":  {"History": 90, "Math": 85},
          "Noya": {"History": 95, "Math": 90},
          "Alma": {"History": 82, "CS": 87}}

print(school["Noya"]["Math"])   # 90

for name, courses in school.items():
    for course, grade in courses.items():
        print(name, course, grade)
```
The nested loop is the matrices nested loop from 5-1, with names instead of positions.
```python
"Noa"
```
```python
{...}
```
```python
"Noya"
```
```python
{...}
```
```python
"Alma"
```
```python
{...}
```
```python
school
```
```python
"History"
```
```python
95
```
```python
"Math"
```
```python
90
```
First bracket selects the outer value (a dictionary); second bracket accesses its internal element.
The Noya entry, and inside it the Math entry. Two steps, two pairs of brackets.
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets

## Slide 21
Class exercise: Inverting a nested dictionary
Task: from student → course → grade, build course → student → grade.
`invert.py`
```python
by_course = {}

for name, courses in school.items():
    for course, grade in courses.items():
        if course not in by_course:
            by_course[course] = {}
        by_course[course][name] = grade

print(by_course)
```
`expected.txt`
```python
# {'History': {'Noa': 90, 'Noya': 95, 'Alma': 82},
#  'Math':    {'Noa': 85, 'Noya': 90},
#  'CS':      {'Alma': 87}}
```
```python
Avoiding KeyError
Initialization guard: Check if inner dictionary exists. If not, create it, empty.
Why: You cannot assign values to a key inside a non-existent dictionary.
```
by_course
```python
"History"
```
```python
"Noa"
```
```python
90
```
```python
"Noya"
```
```python
95
```
```python
"Alma"
```
```python
82
```
```python
"Math"
```
```python
"Noa"
```
```python
85
```
```python
"Noya"
```
```python
90
```
```python
"CS"
```
```python
"Alma"
```
```python
87
```
Noa is first: both her courses are new, so the guard creates an empty dictionary for each.
Noya: both courses already exist, so the guard is skipped.
Alma: History exists, but CS is new - the guard fires again, on the last pass.

## Slide 22
A set
An unordered collection of unique, immutable elements (dictionary without values, only keys).
`first_set.py`
```python
basket = {"apple", "orange", "apple",
          "pear", "orange"}
print(basket)             # in no set order
print(len(basket))        # 3
print("pear" in basket)   # True

empty_set  = set()   # the empty set
empty_dict = {}      # a DICTIONARY
```
```python
{} was taken by dictionaries first, so the empty set needs the word set().
```
```python
"apple"
```
```python
"orange"
```
```python
"apple"
```
```python
"pear"
```
```python
"orange"
```
✗
✗
```python
"apple"
```
```python
"orange"
```
```python
"pear"
```
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets
```python
basket
```
Key characteristics
Uniqueness: Duplicate elements are automatically removed upon creation.
Unordered: Sets do not guarantee positional index access.
Immutability: Elements inside a set must be immutable (like dictionary keys).

## Slide 23
Set operations
Operators and methods sets
`set_ops.py`
```python
s = {"milk", "bread"}
s.add("eggs")
s.remove("bread")   # KeyError if absent

set1 = {1, 5, 8, 2, 10}
set2 = {3, 6, 5, 2, 12}

print(set1 | set2)  # {1, 2, 3, 5, 6, 8, 10, 12}
print(set1 & set2)  # {2, 5}
print(set1 - set2)  # {1, 8, 10}
print(set1 ^ set2)  # {1, 3, 6, 8, 10, 12}
```
operator
method
union  
```python
|
```
```python
.union()
```
intersection  
```python
&
```
```python
.intersection()
```
difference    \
```python
-
```
```python
.difference()
```
symmetric difference
	
```python
^
```
```python
.symmetric_difference()
```
```python
set1 | set2
```
1
2
union
```python
set1 & set2
```
1
2
intersection
```python
set1 - set2
```
1
2
difference
```python
set1 ^ set2
```
1
2
one or the other
The shaded part is what the expression returns.

## Slide 24
Set comparisons
Comparison and membership operators and the methods for sets
`set_compare.py`
```python
a, b = {1, 2}, {1, 2, 3}
c = {3, 4}
nums = [1, 2, 3]

print(a <= b, a < b)        # True  True
print(b <= b, b < b)        # True  False
print(b >= a, a == {2, 1})  # True  True
print(a <= c, c <= a)       # both False
print(3 in b, 3 not in a)   # both True

print(a.isdisjoint(c))      # True - no overlap
print(a.issubset(nums))     # a list works
print(a <= nums)            # TypeError
```
operator
method
subset   
```python
<=
```
```python
.issubset()
```
proper subset  
```python
<
```
none
superset  
```python
>=
```
```python
.issuperset()
```
proper superset   
```python
>
```
none
equal    =
```python
==
```
none
disjoint
none
```python
.isdisjoint()
```
not equal
```python
!=
```
none
not member  
```python
not in
```
```python
.isdisjoint()
```
member  	
```python
in
```
none

## Slide 25
Class exercise: Is one set a subset of another?
Task: Implement a function that that checks whether set1  set2 
`subset_loop.py`
```python
def is_subset(set1, set2):
    subset = True
    for item in set1:
        if item not in set2:
            subset = False
            break
    return subset

set1 = {"apple", "orange", "pear"}
set2 = {"apple"," pear"}
print(is_subset(set1, set2)     # False
print(is_subset(set2, set1)     # True
```
Additional self practice: implement the following
.
Union
set1  set2
Proper superset
set1  set2
 
Difference
set1 \ set2
Not equal
set1  set2

## Slide 26
Primary use case: Deduplication
Removing duplicates in a single, clean step
`dedup.py`
```python
names = ["Omer", "Dana", "Omer", "Yaniv", "Dana"]
unique = set(names)

print(len(unique))      # 3
print(sorted(unique))
# ['Dana', 'Omer', 'Yaniv']
```
```python
Quick clean-up
Passing a list through set() automatically discards all repeated 
With a list: A program you give up on.
Use sorted(set(names)) to display the unique list in order.
```
```python
"Omer"
```
```python
"Dana"
```
```python
"Omer"
```
```python
"Yaniv"
```
```python
"Dana"
```
✗
✗
```python
unique
```
```python
"Dana"
```
```python
"Omer"
```
```python
"Yaniv"
```

## Slide 27
Set comprehension
When the duplicates you want gone are not the items themselves.
`set_comp.py`
```python
names = ["Omer Katz", "Dana Levi", "Omer Barak",
         "Yaniv Levi", "Dana Levi"]

families = {name.split()[1] for name in names}
```
```python
print(len(families))     # 3
print(sorted(families))  # ['Barak', 'Katz', 'Levi']
```
what you write
what comes back
list
```python
[x for x in …]
```
order and duplicates kept
set
```python
{x for x in …}
```
no order, no duplicates
dictionary
```python
{k: v for … in …}
```
key-value pairs
The colon is the entire difference between the last two rows.
```python
"Omer Katz"
```
```python
"Dana Levi"
```
```python
"Omer Barak"
```
```python
"Yaniv Levi"
```
```python
"Dana Levi"
```
✗
✗
```python
name.split()[1]
```
```python
"Katz"
```
```python
"Barak"
```
```python
"Levi"
```
```python
families
```

## Slide 28
Instant lookups: Is it in ?
Checking membership without searching one-by-one
Searching a list vs. searching a set
List: Scans items one-by-one from start to finish.
Set: Calculates the exact spot and jumps directly to it.
Bottom line: If your code frequently asks "is it in the collection?", use a set instead of a list.
`in_cost.py`
```python
import time

def how_long(collection, asks):
    t = time.perf_counter()
    for w in asks:
        w in collection
    return time.perf_counter() - t

words = [str(i) for i in range(100_000)]
asks  = words[::10]                # 10,000 questions

print(how_long(words, asks))       # ~3 seconds
print(how_long(set(words), asks))  # ~0.001 seconds
```

## Slide 29
Lecture summary
list
dictionary
set
Syntax
```python
[1, 2]
```
```python
{"a": 1, "b": 2}
```
```python
{1, 2}
```
Element types
Any values
 (mutable or immutable)
Keys: Immutable
Values: any type
Immutable elements 
only
Access method
```python
Positional index (lst[i])
```
```python
Key lookup (d["a"])
```
```python
Membership check 
(elem in s) or iteration
```
Duplicates
Allowed
Keys must be unique
Not allowed
Ordering
Insertion order
Insertion order (since Python 3.7)
Unordered / Non-positional
Empty syntax
```python
[]
```
```python
{}
```
```python
set()
```
Use a dictionary when
Lookup a value by key: Each item has a unique identifier (name, ID) you search by (and not 0, 1, 2,...).
Counting & frequency: Tracking occurrences where items serve as lookup keys.
Use a set when
Existence checks: You only care if an item is in there, or not.
Duplicates must go: set(items) drops them all.
Set operation: union, intersection, difference...
Dictionaries
Operators
Keys
Methods & Built-ins
Looping
Functions
Nested
Sets
Comprehension
```python
[x for x in …]
```
```python
{k: v for … in …}
```
```python
{x for x in …}
```

## Slide 30
What is coming
Files
Week 6: Everything today gets more interesting when the text comes from a real file.
Recursion
Week 7: A dictionary that remembers answers already computed turns a slow function into a fast one.
Efficiency
Week 9: "Essentially does not get slower" finally gets its proper name.

## Slide 31
INTRO TO CS COURSE · WEEK 6 · LECTURE 1
Next: Files
Reading text from outside the program


---

# Week 5 code files

The code files shown in the week 5 lectures.

### `animal_sounds.py`
```python
sounds = {"cow": "moo", "dog": "woof"}

print("A cow goes", sounds["cow"])
sounds["cat"] = "miao"     # adds
sounds["dog"] = "bark"     # replaces
print(sounds)
print(len(sounds))
```

### `column_averages.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]
rows = len(ratings)
cols = len(ratings[0])

# the average rating of each movie (a column)
for col in range(cols):
    total = 0
    for row in range(rows):
        total = total + ratings[row][col]
    print(f"movie {col}: {round(total / rows, 2)}")
```

### `coupon_experiment.py`
```python
# How many boxes does it take, on average?
import coupons

n = 100
for trials in [10, 100, 10000]:
    results = [coupons.collect(n) for _ in range(trials)]
    average = sum(results) / trials
    print(f"{trials} trials: {round(average, 1)} boxes")

theory = sum([n / k for k in range(1, n + 1)])
print(f"theory: {round(theory, 1)} boxes")
```

### `coupons.py`
```python
"""The coupon collector, as a function."""
import random


def collect(n):
    """Return the boxes needed to collect all n cards."""
    found = [False] * n      # found[c]: got card c yet?
    count = 0                # boxes bought
    distinct = 0             # different cards found
    while distinct < n:
        card = int(random.random() * n)
        count += 1
        if not found[card]:
            found[card] = True
            distinct += 1
    return count
```

### `deck.py`
```python
ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10",
         "Jack", "Queen", "King", "Ace"]
suits = ["Clubs", "Diamonds", "Hearts", "Spades"]

deck = []
for rank in ranks:
    for suit in suits:
        deck.append(f"{rank} of {suit}")

print(f"{len(deck)} cards")
for card in deck[:5]:
    print(card)
print("...")
print(deck[-1])
```

### `format_specs.py`
```python
# [ ] mark the edges of each value
x = 7
r = 2 / 3
n = 1234567
name = "Dana"
print(f"[{x}]")         # [7]
print(f"[{x:4}]")       # [   7]
print(f"[{r:.3f}]")     # [0.667]
print(f"[{r:7.3f}]")    # [  0.667]
print(f"[{n:,}]")       # [1,234,567]
print(f"[{n:>12,}]")    # [   1,234,567]
print(f"[{name:6}]")    # [Dana  ]
```

### `grid_comprehension.py`
```python
rows, cols = 3, 4
board = [["."] * cols for _ in range(rows)]
board[1][1] = "X"
for row in board:
    print(" ".join(row))

print(board[0] is board[2])
```

### `grid_trap.py`
```python
board = [["."] * 3] * 3      # looks like a 3 x 3 grid
board[1][1] = "X"
for row in board:
    print(" ".join(row))

print(board[0] is board[2])
```

### `group_by_letter.py`
```python
words = ["apple", "banana", "avocado",
         "cherry", "blueberry"]

groups = {}
for w in words:
    first = w[0]
    if first not in groups:
        groups[first] = []      # a new, empty list
    groups[first].append(w)

for letter, group in groups.items():
    print(letter, group)
```

### `iterate_dict.py`
```python
sounds = {"cow": "moo", "dog": "woof", "cat": "miao"}

for animal in sounds:
    print(f"{animal} goes {sounds[animal]}")

for animal, sound in sounds.items():
    print(f"{sound} is the sound of a {animal}")

print(list(sounds.keys()))
print(list(sounds.values()))
```

### `keep_some.py`
```python
numbers = [4, 9, 15, 2, 8, 23]
evens = [n for n in numbers if n % 2 == 0]
print(evens)

words = ["grid", "row", "matrix", "cell"]
long_words = [w.upper() for w in words if len(w) > 3]
print(long_words)
```

### `make_grid.py`
```python
def make_grid(rows, cols, value):
    """Return a rows x cols grid filled with value."""
    grid = []
    for i in range(rows):
        grid.append([value] * cols)
    return grid

board = make_grid(3, 3, ".")
board[1][1] = "X"
for row in board:
    print(" ".join(row))
```

### `matrix_add.py`
```python
def add(m1, m2):
    """Return m1 + m2. Assumes equal dimensions."""
    result = []
    for i in range(len(m1)):
        row = []
        for j in range(len(m1[0])):
            row.append(m1[i][j] + m2[i][j])
        result.append(row)
    return result
```

### `matrix_demo.py`
```python
from matrix_add import add
from matrix_mult import mult
from matrix_print import print_matrix

a = [[7, 2, 1],
     [3, 6, 1],
     [5, 1, 4]]
b = [[8, 3, 5],
     [1, 4, 1],
     [1, 3, 4]]

print_matrix(add(a, b))
print_matrix(mult(a, b))
print_matrix(mult(a, add(a, b)))   # a x (a + b)
```

### `matrix_mult.py`
```python
def mult(m1, m2):
    """Return m1 x m2. Assumes len(m1[0]) == len(m2)."""
    rows = len(m1)
    cols = len(m2[0])
    inner = len(m2)
    result = []
    for i in range(rows):
        row = []
        for j in range(cols):
            total = 0
            for k in range(inner):
                total = total + m1[i][k] * m2[k][j]
            row.append(total)
        result.append(row)
    return result
```

### `matrix_print.py`
```python
def print_matrix(m):
    """Print m row by row, then a blank line."""
    for row in m:
        for x in row:
            print(f"{x:5}", end="")
        print()
    print()
```

### `membership_speed.py`
```python
import time

numbers = list(range(1000000))
as_set = set(numbers)

start = time.perf_counter()
found = 999999 in numbers
ms = (time.perf_counter() - start) * 1000
print(f"list: {round(ms, 4)} ms")

start = time.perf_counter()
found = 999999 in as_set
ms = (time.perf_counter() - start) * 1000
print(f"set:  {round(ms, 4)} ms")
```

### `missing_key.py`
```python
sounds = {"cow": "moo", "dog": "woof"}

print("cat" in sounds)
print(sounds.get("cat"))
print(sounds.get("cat", "???"))
print(sounds["cat"])
```

### `print_table.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

for row in range(len(ratings)):
    for col in range(len(ratings[row])):
        print(f"{ratings[row][col]:4}", end="")
    print()
```

### `ratings.py`
```python
# rows are reviewers, columns are movies
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

print(ratings[1][2])     # reviewer 1, movie 2
print(ratings[1])        # all of row 1
print(len(ratings))      # number of rows
print(len(ratings[0]))   # number of columns
```

### `set_basics.py`
```python
s1 = set()
s1.add(3)
s1.add(1)
s1.add(3)              # already there: no change
s1.add(5)
s1.add(7)
s2 = set([7, 9, 1, 9, 1, 7])

print(s1)
print(s2)
print(3 in s1, 4 in s1)
print(len(s2))
```

### `set_ops.py`
```python
s1 = {3, 1, 5, 7}
s2 = {7, 9, 1}

print(s1 | s2)       # union
print(s1 & s2)       # intersection
print(s1 - s2)       # difference
print({1, 7} <= s1)  # subset
```

### `shuffle.py`
```python
import random

deck = ["A", "2", "3", "4", "5", "6"]
n = len(deck)
for i in range(n - 1):
    # pick a random position r, from i to n - 1
    r = i + int(random.random() * (n - i))
    # swap the cards at positions i and r
    deck[i], deck[r] = deck[r], deck[i]
    print(deck)
```

### `sieve.py`
```python
n = 30
is_prime = [True] * (n + 1)    # is k still in?
is_prime[0] = False
is_prime[1] = False
for p in range(2, n + 1):
    if is_prime[p]:
        # cross out the multiples of p
        for m in range(2 * p, n + 1, p):
            is_prime[m] = False

primes = [k for k in range(n + 1) if is_prime[k]]
for p in primes:
    print(p, end=" ")
print()
print(f"{len(primes)} primes up to {n}")
```

### `squares.py`
```python
# The loop way
squares = []
for k in range(1, 6):
    squares.append(k * k)
print(squares)

# The same list, in one line
squares = [k * k for k in range(1, 6)]
print(squares)
```

### `sum_of_rows.py`
```python
import random

table = []
for i in range(5):            # 5 rows of 3 random values
    row = []
    for j in range(3):
        row.append(random.randint(0, 19))
    table.append(row)

for row in table:             # add each row's sum at its end
    row.append(sum(row))

for row in table:
    for x in row:
        print(f"{x:4}", end="")
    print()
```

### `table_comprehension.py`
```python
ratings = [[4, 5, 4, 5, 4],
           [5, 3, 4, 4, 4],
           [3, 4, 3, 5, 3]]

# one column: movie 2
print([row[2] for row in ratings])

# one number per row: each reviewer's total
print([sum(row) for row in ratings])

# transpose: column c becomes row c
flipped = [[row[c] for row in ratings]
           for c in range(len(ratings[0]))]
for row in flipped:
    print(row)
```

### `thinning.py`
```python
def count_primes(n):
    """Return the number of primes from 2 to n."""
    is_prime = [True] * (n + 1)
    is_prime[0] = False
    is_prime[1] = False
    for p in range(2, n + 1):
        if is_prime[p]:
            for m in range(2 * p, n + 1, p):
                is_prime[m] = False
    return len([k for k in range(n + 1) if is_prime[k]])


for n in [100, 10000, 1000000]:
    count = count_primes(n)
    share = round(100 * count / n)
    print(f"{n}: {count} primes, {share}%")
```

### `transpose.py`
```python
def transpose(m):
    """Return m with its rows and columns swapped."""
    result = []
    for col in range(len(m[0])):
        new_row = []
        for row in range(len(m)):
            new_row.append(m[row][col])
        result.append(new_row)
    return result

sales = [[10, 12, 20, 12],
         [12, 14, 25, 18]]
for row in transpose(sales):
    print(row)
```

### `tuple_keys.py`
```python
names = {(0, 0): "corner", (1, 1): "centre"}
print(names[(1, 1)])

names[(0, 2)] = "corner"
print(len(names))

bad = {[0, 0]: "corner"}
```

### `two_courses.py`
```python
intro = {"maya", "noam", "dana", "yoni"}
calculus = {"dana", "omer", "maya"}

print(sorted(intro & calculus))    # in both
print(sorted(intro - calculus))    # intro only
print(len(intro | calculus))       # in either

visits = ["maya", "noam", "maya", "dana", "maya"]
print(f"{len(visits)} visits, {len(set(visits))} people")
```

### `word_count.py`
```python
text = "the cat saw the dog and the dog saw the cat"

counts = {}
for word in text.split():
    if word in counts:
        counts[word] = counts[word] + 1
    else:
        counts[word] = 1

for word, n in counts.items():
    print(word, n)
```

### `word_count_get.py`
```python
text = "the cat saw the dog and the dog saw the cat"

counts = {}
for word in text.split():
    counts[word] = counts.get(word, 0) + 1

print(counts["the"], counts["dog"], counts["and"])
print(counts.get("bird", 0))
```


---

# Lecture 6-1: Files (week 6)

## Slide 1: Files
.txt
PYTHON COURSE · WEEK 6 · LECTURE 1
Files
Reading and writing data
Reichman University

## Slide 2: Where a program's data comes from
Where a program's data comes from
So far we used only the first two.
In the code: ratings = [[4, 5, 4], ...]
The keyboard: input(), gone when the program ends
A file: on the disk before and after the run
Another program: its output is our input

## Slide 3: The big picture
The big picture
Programs reach devices through Python and the operating system.
Your program
open, read, print
Python
the input/output library
Operating system
folders, files, drivers
Keyboard
Screen
Disk: files
devices

## Slide 4: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 5: What a text file is
What a text file is
A name: demo.dat, grades.csv, notes.txt
A place: it lives in a folder on the disk
Contents: characters, one line after another
Line breaks: a special character, \n, ends each line

## Slide 6: A file is one long string
A file is one long string
Lines are separated by \n characters.
```python
demo.dat in an editor
4
1 1 2 
0 1 3 0 3
0 1
```
```python
4
```
```python
\n
```
```python
1
```
```python
·
```
```python
1
```
```python
·
```
```python
2
```
```python
·
```
```python
\n
```
```python
0
```
```python
·
```
```python
1
```
```python
·
```
```python
3
```
```python
·
```
```python
0
```
```python
·
```
```python
3
```
```python
\n
```
```python
0
```
```python
·
```
```python
1
```
```python
\n
```
what is stored: 23 characters  ·  “·” is a space, “\n” ends a line

## Slide 7: Reading a whole file
Reading a whole file
```python
python read_whole.py
'4\n1 1 2 \n0 1 3 0 3\n0 1\n'
4
1 1 2 
0 1 3 0 3
0 1
```
`read_whole.py`
```python
with open("demo.dat") as f:
    text = f.read()

print(repr(text))
print(text)
```
```python
repr(s) shows a string the way you would type it in code:
in quotes, with \n for each line break.
print(s) acts on the line breaks; repr(s) shows them.
```

## Slide 8: The with statement
The with statement
`read_whole.py`
```python
with open("demo.dat") as f:
    text = f.read()

print(repr(text))
print(text)
```
open(name)
Finds the file, opens it to read.
with … as f:
Names it f; closes it at the end.
f.read()
The whole contents, as one str.

## Slide 9: Reading line by line
Reading line by line
```python
python read_lines.py
'4\n' ['4']
'1 1 2 \n' ['1', '1', '2']
'0 1 3 0 3\n' ['0', '1', '3', '0', '3']
'0 1\n' ['0', '1']
```
`read_lines.py`
```python
with open("demo.dat") as f:
    for line in f:
        print(repr(line), line.split())
```

## Slide 10: From text to numbers
From text to numbers
Always text: whatever is read from a file is a str
strip(): removes spaces and \n from both ends
split(): cuts a line into words
int() and float(): turn one word into a number
"3" + "4" is "34".
Convert before you compute: int("3") + int("4") is 7.

## Slide 11: Counting the values in a file
Counting the values in a file
```python
python count_values.py
0: 3
1: 4
2: 1
3: 2
```
`count_values.py`
```python
# How often each number appears in demo.dat.
# The first number, n: the rest are 0 .. n-1.

with open("demo.dat") as f:
    tokens = f.read().split()

n = int(tokens[0])
count = [0] * n
for t in tokens[1:]:
    count[int(t)] += 1

for i in range(n):
    print(f"{i}: {count[i]}")
```

## Slide 12: Where Python looks for a file
Where Python looks for a file
A bare name: "demo.dat" is looked for in the current folder
Current folder: where the terminal is when python starts
A path: "data/demo.dat" looks inside data
Run in VS Code: starts in the folder you opened (File > Open Folder)
So: open the folder that holds the program and its data file

## Slide 13: When the file is not there
When the file is not there
```python
python missing_file.py
No such file: demo.txt
```
`missing_file.py`
```python
name = "demo.txt"        # a typo: it is demo.dat
try:
    with open(name) as f:
        print(f.read())
except FileNotFoundError:
    print("No such file:", name)
```

## Slide 14: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 15: A file of records
A file of records
One line per student; commas separate the fields.
```python
grades.csv
name,hw,exam
Dana,88,92
Noam,75,64
Maya,95,81
Yoni,52,58
```
The header
line 1 names the columns
A record
every other line: one student
Fields
line.split(",") separates them

## Slide 16: Reading the records
Reading the records
```python
python final_grades.py
Dana   90.8
Noam   67.3
Maya   85.2
Yoni   56.2
```
`final_grades.py`
```python
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        final = 0.3 * int(hw) + 0.7 * int(exam)
        print(f"{name:5} {final:5.1f}")
```

## Slide 17: USA.txt: the first lines
USA.txt: the first lines
A header line, then one line per town.
```python
USA.txt
669905.0 247205.0 1244962.0 700000.0
 1097038.8890   245552.7780
 1103961.1110   247133.3330
 1104677.7780   247205.5560
 1108586.1110   249238.8890
 1109713.8890   250111.1110
...
```
The header
line 1, four numbers that give the box the map fits in
A town
each line after it holds one town's two coordinates
13,510 lines
the header, then 13,509 towns

## Slide 18: A bigger file: 13,509 towns
A bigger file: 13,509 towns
```python
python usa_points.py
13509 towns
header: ['669905.0', '247205.0',
         '1244962.0', '700000.0']
x: 669905.556 to 1244961.111
y: 245552.778 to 490000.0
```
`usa_points.py`
```python
# USA.txt: a header line with the bounding box,
# then one "x y" pair per town.

with open("USA.txt") as f:
    header = f.readline().split()
    xs, ys = [], []
    for line in f:
        x, y = line.split()
        xs.append(float(x))
        ys.append(float(y))

print(len(xs), "towns")
print("header:", header)
print(f"x: {min(xs)} to {max(xs)}")
print(f"y: {min(ys)} to {max(ys)}")
```

## Slide 19: Drawing the map: the plan
Drawing the map: the plan
W and H: the size of the map, 60 columns by 18 rows
The grid: H rows of W spaces, a 2D list as in 5-1
Each town: puts a * in one cell of the grid
Columns: west to east, from 0 to W - 1
Rows: north to south, from 0 at the top to H - 1

## Slide 20: From a town to a cell
From a town to a cell
Worked example: the first town in USA.txt.
The map, west to east
```python
left = 669905.556
```
```python
right = 1244961.111
```
```python
1097038.889
```
The columns of the grid
```python
0
```
```python
59
```
```python
43
```
The same share of the way across: 0.743
```python
the arithmetic
x = 1097038.889
(x - left) / (right - left) = 0.743
0.743 * (W - 1) = 43.8
col = int(43.8) = 43

y = 245552.778, the smallest y
(top - y) / (top - bottom) = 1.0
1.0 * (H - 1) = 17.0
row = 17, the bottom line
```

## Slide 21: usa_map.py: reading the towns
usa_map.py: reading the towns
```python
usa_map.py (lines 1 to 10)
```
```python
# Draws the towns of USA.txt as a map of characters.
W, H = 60, 18          # columns and rows

xs, ys = [], []
with open("USA.txt") as f:
    f.readline()       # skip the header
    for line in f:
        x, y = line.split()
        xs.append(float(x))
        ys.append(float(y))
```
W, H
the map's size, 60 by 18 characters
readline()
skips the header line
xs, ys
one entry per town, as in usa_points.py

## Slide 22: usa_map.py: drawing the towns
usa_map.py: drawing the towns
```python
usa_map.py (lines 12 to 22)
```
```python
left, right = min(xs), max(xs)
bottom, top = min(ys), max(ys)

grid = [[" "] * W for _ in range(H)]
for i in range(len(xs)):
    col = int((xs[i] - left) / (right - left) * (W - 1))
    row = int((top - ys[i]) / (top - bottom) * (H - 1))
    grid[row][col] = "*"

for row in grid:
    print("".join(row))
```
left ... top
the edges of the map, from the data
col, row
the cell, as in the worked example
The last loop
prints the grid, one row per line

## Slide 23: The map, printed
The map, printed
Each * is one or more towns.
```python
python usa_map.py
********************************** *
***************** **********************                 **
********* * *******************************       ***** ****
**** * ** ******* **************************  *************
*****    ***********************************************
***** * *** ********************************************
*******  *  ****************************************
 *******  **** ************************************
  *****  *****************************************
   ***** ** ***************************************
    ************ *******************************
       ***************************************
             ***  * *************************
                    *** ************** ******
                        ******            ****
                         ****             ****
                           *               ***
                                           *
```

## Slide 24: The points, plotted
The points, plotted
Each of the 13,509 points is one town.

## Slide 25: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 26: Writing a file
Writing a file
open(name, "w"): creates the file for writing
open(name, "a"): adds to the end of an existing file
f.write(s): writes exactly s; add \n yourself
print(x, file=f): prints into the file, not the screen
"w" empties the file first.
Opening an existing file with "w" deletes its contents.

## Slide 27: Writing, then reading back
Writing, then reading back
```python
python write_squares.py
1 1
2 4
3 9
4 16
5 25
```
`write_squares.py`
```python
with open("squares.txt", "w") as f:
    for i in range(1, 6):
        f.write(f"{i} {i * i}\n")

with open("squares.txt") as f:
    print(f.read(), end="")
```

## Slide 28: Read, decide, write
Read, decide, write
```python
python passed.py
3 names written to passed.txt

passed.txt:
Dana
Noam
Maya
```
`passed.py`
```python
passed = []
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        if 0.3 * int(hw) + 0.7 * int(exam) >= 60:
            passed.append(name)

with open("passed.txt", "w") as f:
    for name in passed:
        f.write(name + "\n")
print(len(passed), "names written to passed.txt")
```

## Slide 29: Files: the plan
Files: the plan
Four parts today.
Reading a file
Files of data
Writing a file
Standard input and output

## Slide 30: Standard input and output
Standard input and output
Standard output: print writes there; the screen, by default
Standard input: input() reads it; the keyboard, by default
sys.stdin: standard input, as a file
sys.argv: the words typed after python file.py

## Slide 31: A program that writes numbers
A program that writes numbers
```python
python random_numbers.py 3
0.4234137005317864
0.2984657006398488
0.7456080688315734
```
`random_numbers.py`
```python
import random
import sys

n = int(sys.argv[1])   # typed after the name
for i in range(n):
    print(random.random())
```

## Slide 32: A program that reads numbers
A program that reads numbers
```python
python average.py
100
200
100
300
<Ctrl-D>
Average: 175.0
```
`average.py`
```python
import sys

total, count = 0.0, 0
for line in sys.stdin:   # one line at a time
    total += float(line)
    count += 1
print("Average:", total / count)
```

## Slide 33: Redirection and pipes
Redirection and pipes
The terminal can send input and output to files or programs.
```python
>
```
`random_numbers.py`
`data.txt`
output goes into a file
```python
<
```
`data.txt`
`average.py`
input comes from a file
```python
|
```
`random_numbers.py`
`average.py`
one feeds the next
light boxes are programs; tinted boxes are files

## Slide 34: Redirection: examples
Redirection: examples
With a file, and with a pipe.
```python
terminal
% python random_numbers.py 1000 > data.txt
% python average.py < data.txt
Average: 0.49570948891636646
% python random_numbers.py 1000000 | python average.py
Average: 0.5007775704132853
```

## Slide 35: One program, different inputs
One program, different inputs
The keyboard: python average.py
A file: python average.py < data.txt
A pipe: … | python average.py
The code: unchanged

## Slide 36: Files in one slide
Files in one slide
Read
with open(name) as f
f.read(): the whole file
for line in f: line by line
f.readline(): one line
Convert
Everything read is a str
strip(), then split()
int() and float() on each word
Write
open(name, "w") erases first
open(name, "a") appends
write adds no line break
Standard I/O
print and input
sys.stdin, sys.argv
>  <  |  in the terminal


---

# Lecture 6-2: PageRank (week 6)

## Slide 1: PageRank
#1
INTRO TO CS· WEEK 6 · LECTURE 2
PageRank
Ranking pages by their links
Reichman University

## Slide 2: The problem
The problem
A search for “python” matches millions of pages. Which come first?
Relevance: is the page about what was searched for?
Importance: do other pages link to it?
PageRank: a number for importance, from the links alone

## Slide 3: What makes a page important
What makes a page important
Visits: pages people reach often matter more
Who links in: links from important pages count more
The problem: the definition is circular

## Slide 4: History
History
1998: Stanford students Sergey Brin and Larry Page
The idea: rank pages by the links that point to them
What came of it: Google's first ranking method
Brin & Page, “The Anatomy of a Large-Scale Hypertextual Web Search Engine”:  infolab.stanford.edu/~backrub/google.html

## Slide 5: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 6: A tiny web of five pages
A tiny web of five pages
Each arrow is a link from one page to another.
0
1
2
3
4
×2
×2
```python
web.dat
5
0 1
1 2  1 2
1 3  1 3  1 4
2 3
3 0
4 0  4 2
```
first: the number of pages;
then “from to” pairs, one per link

## Slide 7: The random surfer
The random surfer
A model of one person clicking links.
90% of the time: click one of the page's links, at random
10% of the time: jump to a random page
A page's rank: the share of the time the surfer spends there

## Slide 8: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 9: Counting the links
Counting the links
links[i][j]: how many links go from page i to page j.
0
1
0
0
0
0
0
2
2
1
0
0
0
1
0
1
0
0
0
0
1
0
1
0
0
0
1
2
3
4
0
1
2
3
4
to page j
from page i
1
5
1
1
2
links out

## Slide 10: Reading the web
Reading the web
`web_links.py`
```python
def read_links(filename):
    """Reads n, then "from to" pairs, from a web file.
    Returns links: links[i][j] counts the i -> j links."""
    with open(filename) as f:
        tokens = f.read().split()
    n = int(tokens[0])
    links = [[0] * n for _ in range(n)]   # n new rows
    for k in range(1, len(tokens), 2):
        links[int(tokens[k])][int(tokens[k + 1])] += 1
    return links
```

## Slide 11: From counts to chances
From counts to chances
Row 1: page 1 has five links.
0
0
2
2
1
0
1
2
3
4
```python
links[1]
```
```python
p[1][j]  =  0.10 / 5   +   0.90 × links[1][j] / 5
```
jump anywhere
5 = the number of pages
follow one of page 1's links
5 = the links on page 1 (0 + 0 + 2 + 2 + 1)
0.02
0.02
0.38
0.38
0.20
```python
p[1]
```
0.02 + 0.02 + 0.38 + 0.38 + 0.20 = 1

## Slide 12: The transition matrix
The transition matrix
Row i: where the surfer goes next from page i.
0.02
0.92
0.02
0.02
0.02
0.02
0.02
0.38
0.38
0.20
0.02
0.02
0.02
0.92
0.02
0.92
0.02
0.02
0.02
0.02
0.47
0.02
0.47
0.02
0.02
0
1
2
3
4
0
1
2
3
4
```python
p
```

## Slide 13: Building the transition matrix
Building the transition matrix
`transition.py`
```python
def transition_matrix(links, jump=0.10):
    """p[i][j]: the chance of moving from page i to j.
    Assumes every page has at least one link."""
    n = len(links)
    p = []
    for i in range(n):
        out = sum(links[i])       # links leaving page i
        row = []
        for j in range(n):
            follow = links[i][j] / out
            row.append(jump / n + (1 - jump) * follow)
        p.append(row)
    return p
```

## Slide 14: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 15: The algorithm
The algorithm
Simulating the surfer
visits = 0 for every page
page = 0
repeat T times:
pick the next page, with the chances in p[page]
add 1 to visits[page]
rank of page i = visits[i] / T

## Slide 16: Picking a random page
Picking a random page
Put the probabilities in a row; pick a random number in [0, 1).
0
1
2
3
4
page
0.38
0.38
0.20
0
0.04
0.42
0.80
1.00
r = 0.63 falls between 0.42 and 0.80  →  page 3

## Slide 17: Picking a page in Python
Picking a page in Python
`next_page.py`
```python
import random


def next_page(row):
    """Picks page j with probability row[j]."""
    r = random.random()           # somewhere in [0, 1)
    total = 0.0
    for j in range(len(row)):
        total += row[j]
        if r < total:
            return j
    return len(row) - 1           # in case of rounding
```

## Slide 18: The surfer
The surfer
`surfer.py`
```python
from next_page import next_page


def simulate(p, moves):
    """Moves the surfer, starting on page 0. Returns
    the share of the moves that ended on each page."""
    visits = [0] * len(p)
    page = 0
    for _ in range(moves):
        page = next_page(p[page])
        visits[page] += 1
    return [v / moves for v in visits]
```

## Slide 19: Putting it together
Putting it together
```python
python pagerank.py   (moves, then pages 0–4)
      100  0.250  0.260  0.150  0.280  0.060
   10,000  0.276  0.267  0.143  0.246  0.068
1,000,000  0.273  0.266  0.146  0.247  0.068
```
`pagerank.py`
```python
from web_links import read_links
from transition import transition_matrix
from surfer import simulate

links = read_links("web.dat")
p = transition_matrix(links)
for moves in [100, 10_000, 1_000_000]:
    ranks = simulate(p, moves)
    print(f"{moves:>9,}", end="")
    for r in ranks:
        print(f"{r:7.3f}", end="")
    print()
```

## Slide 20: The ranks
The ranks
A million moves: the share of time spent on each page.
0.273
page 0
0.266
page 1
0.146
page 2
0.247
page 3
0.068
page 4

## Slide 21: PageRank: the plan
PageRank: the plan
Four steps today.
A model of the web
The transition matrix
Simulating a surfer
Computing it exactly

## Slide 22: Computing the probabilities directly
Computing the probabilities directly
rank[i]: the share of a crowd of surfers that is on page i now
At the start: the whole crowd on page 0, [1, 0, 0, 0, 0]
p[i][j]: the chance to go from page i to page j, by a link or a jump
One move: the new rank[j] is the sum over i of rank[i] × p[i][j]
Repeat: the new ranks replace the old, until they stop changing

## Slide 23: The crowd, move by move
The crowd, move by move
100 surfers, all starting on page 0. Each click is one move.
×2
×2
0
1
2
3
4
at the start
page 0
```python
1.000
```
100
page 1
```python
0.000
```
0
page 2
```python
0.000
```
0
page 3
```python
0.000
```
0
page 4
```python
0.000
```
0
after 1 move
page 0
```python
0.020
```
2
page 1
```python
0.920
```
92
page 2
```python
0.020
```
2
page 3
```python
0.020
```
2
page 4
```python
0.020
```
2
after 2 moves
page 0
```python
0.047
```
5
page 1
```python
0.038
```
4
page 2
```python
0.360
```
36
page 3
```python
0.369
```
37
page 4
```python
0.186
```
18
after 3 moves
page 0
```python
0.436
```
43
page 1
```python
0.062
```
6
page 2
```python
0.117
```
12
page 3
```python
0.358
```
36
page 4
```python
0.027
```
3
after 10 moves
page 0
```python
0.284
```
28
page 1
```python
0.240
```
24
page 2
```python
0.148
```
15
page 3
```python
0.261
```
26
page 4
```python
0.067
```
7
after 30 moves
page 0
```python
0.273
```
27
page 1
```python
0.266
```
26
page 2
```python
0.146
```
15
page 3
```python
0.247
```
25
page 4
```python
0.068
```
7
the same ranks as the simulation
dots

## Slide 24: One move, in Python
One move, in Python
`power_step.py`
```python
def step(rank, p):
    """rank[i]: the chance of being on page i now.
    Returns the chances one move later."""
    n = len(rank)
    new = [0.0] * n
    for i in range(n):
        for j in range(n):
            new[j] += rank[i] * p[i][j]
    return new
```

## Slide 25: Repeating the move
Repeating the move
```python
python power.py   (moves, then pages 0–4)
  1  0.020  0.920  0.020  0.020  0.020
  2  0.047  0.038  0.360  0.369  0.186
  3  0.436  0.062  0.117  0.358  0.027
 10  0.284  0.240  0.148  0.261  0.067
 20  0.272  0.265  0.147  0.248  0.068
 30  0.273  0.266  0.146  0.247  0.068
```
`power.py`
```python
from web_links import read_links
from transition import transition_matrix
from power_step import step

p = transition_matrix(read_links("web.dat"))
rank = [1.0, 0.0, 0.0, 0.0, 0.0]  # on page 0
for move in range(1, 31):
    rank = step(rank, p)
    if move in [1, 2, 3, 10, 20, 30]:
        print(f"{move:>3}", end="")
        for r in rank:
            print(f"{r:7.3f}", end="")
        print()
```

## Slide 26: Simulation vs. exact computation
Simulation vs. exact computation
Simulation
One surfer, many random moves
Easy to explain and to write
Approximate: a million moves for 3 digits
Different every run
Repeated multiplication
A crowd, spread by the matrix
One move costs n × n steps
Exact: 30 moves for 3 digits here
The same answer every run

## Slide 27: What simulation is good for
What simulation is good for
On big or messy problems, simulation often wins.
Changing the rules
Real surfers press Back, or get bored.
Simulation: add a few lines to the loop.
Exact method: there may be no table p for it.
No big table
The exact method keeps all n × n chances.
A billion pages: a billion billion numbers.
A surfer only needs the links of its page.
Many computers
Surfers do not depend on each other.
Run thousands at once, on many machines.
Add up their visit counts at the end.
Checking the math
Two different methods, the same numbers.
If they disagree, one of them has a bug.

## Slide 28: PageRank in one slide
PageRank in one slide
Model
Pages and links
web.dat: n, then from–to pairs
links[i][j] counts them
Transition matrix
p[i][j]: jump, or follow a link
Rows sum to 1
Simulation
Pick the next page with given chances
Count the visits
More moves, steadier ranks
Exact
new[j] = Σ rank[i] × p[i][j]
Repeat until it stops changing


---

# Week 6 code files

The code files shown in the week 6 lectures.

### `USA.txt`
(data file, 391,799 bytes, not included)

### `average.py`
```python
import sys

total, count = 0.0, 0
for line in sys.stdin:   # one line at a time
    total += float(line)
    count += 1
print("Average:", total / count)
```

### `count_values.py`
```python
# How often each number appears in demo.dat.
# The first number, n: the rest are 0 .. n-1.

with open("demo.dat") as f:
    tokens = f.read().split()

n = int(tokens[0])
count = [0] * n
for t in tokens[1:]:
    count[int(t)] += 1

for i in range(n):
    print(f"{i}: {count[i]}")
```

### `demo.dat`
```
4
1 1 2 
0 1 3 0 3
0 1
```

### `final_grades.py`
```python
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        final = 0.3 * int(hw) + 0.7 * int(exam)
        print(f"{name:5} {final:5.1f}")
```

### `grades.csv`
```
name,hw,exam
Dana,88,92
Noam,75,64
Maya,95,81
Yoni,52,58
```

### `missing_file.py`
```python
name = "demo.txt"        # a typo: it is demo.dat
try:
    with open(name) as f:
        print(f.read())
except FileNotFoundError:
    print("No such file:", name)
```

### `next_page.py`
```python
import random


def next_page(row):
    """Picks page j with probability row[j]."""
    r = random.random()           # somewhere in [0, 1)
    total = 0.0
    for j in range(len(row)):
        total += row[j]
        if r < total:
            return j
    return len(row) - 1           # in case of rounding
```

### `pagerank.py`
```python
from web_links import read_links
from transition import transition_matrix
from surfer import simulate

links = read_links("web.dat")
p = transition_matrix(links)
for moves in [100, 10_000, 1_000_000]:
    ranks = simulate(p, moves)
    print(f"{moves:>9,}", end="")
    for r in ranks:
        print(f"{r:7.3f}", end="")
    print()
```

### `passed.py`
```python
passed = []
with open("grades.csv") as f:
    f.readline()              # skip the header
    for line in f:
        name, hw, exam = line.strip().split(",")
        if 0.3 * int(hw) + 0.7 * int(exam) >= 60:
            passed.append(name)

with open("passed.txt", "w") as f:
    for name in passed:
        f.write(name + "\n")
print(len(passed), "names written to passed.txt")
```

### `power.py`
```python
from web_links import read_links
from transition import transition_matrix
from power_step import step

p = transition_matrix(read_links("web.dat"))
rank = [1.0, 0.0, 0.0, 0.0, 0.0]  # on page 0
for move in range(1, 31):
    rank = step(rank, p)
    if move in [1, 2, 3, 10, 20, 30]:
        print(f"{move:>3}", end="")
        for r in rank:
            print(f"{r:7.3f}", end="")
        print()
```

### `power_step.py`
```python
def step(rank, p):
    """rank[i]: the chance of being on page i now.
    Returns the chances one move later."""
    n = len(rank)
    new = [0.0] * n
    for i in range(n):
        for j in range(n):
            new[j] += rank[i] * p[i][j]
    return new
```

### `random_numbers.py`
```python
import random
import sys

n = int(sys.argv[1])   # typed after the name
for i in range(n):
    print(random.random())
```

### `read_lines.py`
```python
with open("demo.dat") as f:
    for line in f:
        print(repr(line), line.split())
```

### `read_whole.py`
```python
with open("demo.dat") as f:
    text = f.read()

print(repr(text))
print(text)
```

### `redirection.txt`
```
Terminal transcript (macOS / Linux shell), not a Python file.
% python random_numbers.py 1000 > data.txt
% python average.py < data.txt
Average: 0.49570948891636646
% python random_numbers.py 1000000 | python average.py
Average: 0.5007775704132853
```

### `surfer.py`
```python
from next_page import next_page


def simulate(p, moves):
    """Moves the surfer, starting on page 0. Returns
    the share of the moves that ended on each page."""
    visits = [0] * len(p)
    page = 0
    for _ in range(moves):
        page = next_page(p[page])
        visits[page] += 1
    return [v / moves for v in visits]
```

### `transition.py`
```python
def transition_matrix(links, jump=0.10):
    """p[i][j]: the chance of moving from page i to j.
    Assumes every page has at least one link."""
    n = len(links)
    p = []
    for i in range(n):
        out = sum(links[i])       # links leaving page i
        row = []
        for j in range(n):
            follow = links[i][j] / out
            row.append(jump / n + (1 - jump) * follow)
        p.append(row)
    return p
```

### `usa_map.py`
```python
# Draws the towns of USA.txt as a map of characters.
W, H = 60, 18          # columns and rows

xs, ys = [], []
with open("USA.txt") as f:
    f.readline()       # skip the header
    for line in f:
        x, y = line.split()
        xs.append(float(x))
        ys.append(float(y))

left, right = min(xs), max(xs)
bottom, top = min(ys), max(ys)

grid = [[" "] * W for _ in range(H)]
for i in range(len(xs)):
    col = int((xs[i] - left) / (right - left) * (W - 1))
    row = int((top - ys[i]) / (top - bottom) * (H - 1))
    grid[row][col] = "*"

for row in grid:
    print("".join(row))
```

### `usa_points.py`
```python
# USA.txt: a header line with the bounding box,
# then one "x y" pair per town.

with open("USA.txt") as f:
    header = f.readline().split()
    xs, ys = [], []
    for line in f:
        x, y = line.split()
        xs.append(float(x))
        ys.append(float(y))

print(len(xs), "towns")
print("header:", header)
print(f"x: {min(xs)} to {max(xs)}")
print(f"y: {min(ys)} to {max(ys)}")
```

### `web.dat`
```
5
0 1
1 2  1 2
1 3  1 3  1 4
2 3
3 0
4 0  4 2
```

### `web_links.py`
```python
def read_links(filename):
    """Reads n, then "from to" pairs, from a web file.
    Returns links: links[i][j] counts the i -> j links."""
    with open(filename) as f:
        tokens = f.read().split()
    n = int(tokens[0])
    links = [[0] * n for _ in range(n)]   # n new rows
    for k in range(1, len(tokens), 2):
        links[int(tokens[k])][int(tokens[k + 1])] += 1
    return links
```

### `write_squares.py`
```python
with open("squares.txt", "w") as f:
    for i in range(1, 6):
        f.write(f"{i} {i * i}\n")

with open("squares.txt") as f:
    print(f.read(), end="")
```
