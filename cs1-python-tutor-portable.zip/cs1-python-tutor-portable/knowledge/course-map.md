# Course map: Introduction to Computer Science (Python)

Skill version 2026-10-10. Lectures marked *not available yet* are not in this version of the skill.

## Lectures

| Week | Lecture | Topic | File |
|---|---|---|---|
| 1 | 1-1 | Intro and basics | `lectures-weeks-01-02.md` |
| 1 | 1-2 | Types and I/O | `lectures-weeks-01-02.md` |
| 1 | code | Code files from the week 1 lectures | `lectures-weeks-01-02.md` |
| 2 | 2-1 | Conditionals and while loops | `lectures-weeks-01-02.md` |
| 2 | 2-2 | The for loop and numeral systems | `lectures-weeks-01-02.md` |
| 2 | 2-x | Gambler's ruin (simulation) | `lectures-weeks-01-02.md` |
| 3 | 3-1 | Strings | `lectures-weeks-03-04.md` |
| 3 | 3-2 | Approximation algorithms | `lectures-weeks-03-04.md` |
| 3 | code | Code files from the week 3 lectures | `lectures-weeks-03-04.md` |
| 4 | 4-1 | Functions | `lectures-weeks-03-04.md` |
| 4 | 4-2 | Lists and tuples | `lectures-weeks-03-04.md` |
| 4 | code | Code files from the week 4 lectures | `lectures-weeks-03-04.md` |
| 5 | 5-1 | Two-dimensional lists | `lectures-weeks-05-06.md` |
| 5 | 5-2 | Dictionaries and sets | `lectures-weeks-05-06.md` |
| 5 | code | Code files from the week 5 lectures | `lectures-weeks-05-06.md` |
| 6 | 6-1 | Files | `lectures-weeks-05-06.md` |
| 6 | 6-2 | PageRank | `lectures-weeks-05-06.md` |
| 6 | code | Code files from the week 6 lectures | `lectures-weeks-05-06.md` |
| 7 | 7-1 | Recursion | *not available yet* |
| 8 | 8-1 | Computer fundamentals: the Vic computer | `lectures-weeks-07-09.md` |
| 8 | 8-2 | AI agents for coding | *not available yet* |
| 8 | code | Code files from the week 8 lectures | `lectures-weeks-07-09.md` |
| 9 | 9-1 | Software engineering | *not available yet* |
| 9 | 9-2 | Complexity | *not available yet* |
| 10 | 10-1 | Searching and sorting | *not available yet* |
| 10 | 10-2 | Objects and classes (using classes) | `lectures-weeks-10-12.md` |
| 10 | code | Code files from the week 10 lectures | `lectures-weeks-10-12.md` |
| 11 | 11-1 | Writing classes | `lectures-weeks-10-12.md` |
| 11 | 11-2 | Image processing | *not available yet* |
| 11 | code | Code files from the week 11 lectures | `lectures-weeks-10-12.md` |
| 12 | 12-1 | Advanced data structures 1 | *not available yet* |
| 12 | 12-2 | Advanced data structures 2 | *not available yet* |

## Recitations

*No recitations in this version.*

## Homework assignments

These are graded. Use the hint ladder, never write solutions.

*No homework assignments in this version.*
