# Course syllabus

Introduction to Computer Science
Reichman University, 2026-2027
Instructors: Kfir Bar and Shlomit Arian
“What I hear, I forget; What I see, I remember; What I do, I understand.”
(Confucius, 551-479 BC)
Objectives: The course exposes students to computer science fundamentals and equips them with solid programming skills, using a hands-on approach. Key elements of the theory and practice of computer science are presented in the context of programming examples and exercises. Through this experience, students develop an appreciation of the elegance and joy of computer science, and become competent Python programmers. The course assumes no previous experience. Students are expected to be curious and motivated to learn computer science not because it leads to great careers, but because it is fun and intellectually rewarding.
Methodology: 13 semester weeks, each consisting of two 2-hour lectures, one 2-hour recitation (תירגול), one 2-hours workshop (סדנה) and a homework assignment. Of these course elements, the homework assignments are by far the most important. Students should expect to work 6-12 hours a week on each homework assignment.
The course grade is based on a midterm exam (20%), final exam (65%), and homework assignments (15%). In order to pass the course, students must get at least 60 in the final exam. If the homework assignments are so important, how come they get such a small weight? The answer is that if you will not do the homework on your own, you will not pass the exams.
English is the official written language of this course. The spoken language in the lectures is Hebrew in the regular tracks and English in the international track; in all tracks though, all written materials (lecture notes, homework, web site, etc.) are in English. The course provides an excellent opportunity to improve your English in an applied context.
Questions and answers are welcome and encouraged. Post your questions on the course's Questions and Answers (Q&A) forum, and they will be answered shortly by the course staff, or by students who know the answer and want to help out.
The course website and the Q&A forum are the hub of all the course activities. The lecture slides, homework assignments and course materials for every week will be uploaded to the course website every Sunday. The course website is also the official repository of all the course's announcements, rules and regulations. If we say x in a class meeting and the course website says y, you must ignore x and do y. Each student is responsible for visiting the course website and Q&A forum daily and following the guidelines listed there.
Civilized behavior in and out the class activities is expected. Please refrain from doing things that would irritate you if you were to teach this course. Examples include being late to class meetings, posting silly messages in the Q&A forum, not following instructor requests during class activities, and so on. Use your judgment.



Course Plan (by week)
The plan listed below is tentative. The actual week-by-week plan will be published in the course website, one week in advance.

Topics, more or less by week | Topics, more or less by week
1 | Welcome to computer science, and to the course.
 | Programming basics: variables and data types.
2 | Conditional and iterative processing.
 | Examples: The decimal and binary systems, Monte Carlo simulation.
3 | Approximation algorithms, string processing.
4 | Functions and the art of modular programming, lists and tuples.
 | Examples: prime numbers.
5 | Two-dimensional lists, dictionaries and sets
6 | Working with files, graphs
Example: PageRank
7 | Midterm examination, recursion: concepts and techniques.
 | Examples: fractals, permutations, artificial landscapes.
8 | Hardware, computer structure and low-level programming. 
Coding with AI agents.
9 | Complexity, computability; Searching and sorting algorithms.
10 | Object-oriented programming I: the client’s perspective.
Object-oriented programming II: the class-writer’s perspective.
11 | Image processing; advanced data structures I
12 | Advanced data structures II.
Compression with Huffman codes.
13 | Machine learning: Introduction and basic concepts.
 | Basic algorithms and implementations.


---

# From Zero to Code: setting up Python

From Zero to Code:
Getting Started with Python and VS Code
Welcome to RUNI’s Introduction to Computer Science course! Three tools that will be used extensively in this course are Python, VS Code, and GitHub. Python is a powerful and widely used programming language; VS Code is a popular code editor that, with the right extensions, serves as an Integrated Development Environment (IDE) for many programming languages, including Python; GitHub is a cloud-based platform that helps developers store, share, and manage versions of their software. This document guides you through setting up Python and VS Code on your Mac or Windows computer; we’ll deal with GitHub later. Because you are a computer science student, we view this document not only as a technical guide but also as part of your computer science education.
Background
Python was created by the Dutch programmer Guido van Rossum and first released in 1991. It is named after the British comedy group Monty Python, not after the snake. Today, Python is open-source software, developed by a worldwide community and supported by the non-profit Python Software Foundation.
VS Code was developed by Microsoft, which made a wise decision to let people use it to develop programs in any language, including Python. This decision was consistent with Microsoft’s vision to build a global developers ecosystem. This is also why Microsoft bought the GitHub platform, which we will discuss and use later in the course.
Python, VS Code, and GitHub are freely available and can be used on almost any computer platform. Why are companies willing to invest money and resources in developing give-away software? That’s an interesting question that you are welcome to think about.
Installing Python
To run Python programs, you need the Python interpreter: a program that reads Python code and executes it, statement by statement. Behind the scenes, the interpreter first translates the code into a lower-level form called bytecode and then executes the bytecode. This happens automatically: unlike some other languages, Python has no separate compilation step for you to perform.
Install the latest stable version of Python: at the time of writing (October 2026), Python 3.15.0. If a newer 3.15 release (such as 3.15.1) is listed when you download, take the newest one.
Mac users (Apple Silicon or Intel): Go to the Python Releases for macOS page and, under the newest Python 3.15 release, click macOS installer. The same installer works on all Macs. Open the downloaded .pkg file and follow the installation steps, keeping the default options.
Windows users: Go to the Python Releases for Windows page and, under the newest Python 3.15 release, click Windows installer (64-bit), or Windows installer (ARM64) if your laptop has an ARM processor (see Settings > System > About > System type). Run the installer and, on its first screen, check the box Add python.exe to PATH before clicking Install Now. This setting lets you start Python by typing python in a terminal. (The same page also links to a Python install manager; this guide uses the standard installer instead.)
Once Python is installed, you’re all set. If VS Code was open during the installation, restart it so that it finds the new installation.
Installing VS Code
Download and install VS Code for your operating system from Microsoft’s VS Code page.
Locate VS Code in your computer’s applications folder, or use your OS search bar to find it. Launch (start executing) VS Code on your computer.
VS Code is designed for writing programs in many different programming languages. Before using it in our course, customize it to work with Python. To do so, click the sidebar’s Extensions icon, search for “Python”, and install the extension named Python by Microsoft. This extension, together with a few companion extensions installed along with it, adds Python support to VS Code: color-coded syntax, error detection, and tools for running and debugging programs.
Python program development: Writing and Running
0. Assumptions
We assume that you’ve installed Python, VS Code, and the Python extension.
In the first few weeks of the course, you will not write Python programs from scratch. Instead, we will give you skeletal programs (תכניות שלדיות) that you will have to complete. Each program, say MyProg, is stored in a separate file, say MyProg.py. Keeping files well organized is essential. In a nutshell, we use folders to keep together programs that have something in common. For example, all the programs that belong to Homework Assignment 1 are given in a folder named HW1. These programs are available on the course website in Moodle as a single compressed file named HW1.zip.
Create a folder named intro2cs on your computer. Download HW1.zip from the “Week 1” section on the course website and extract it into the intro2cs folder.
Next, start VS Code. All the operations described below are performed in VS Code.
1. Open the relevant folder
To start working on an existing program, open the folder where the program’s code is stored. For example, let’s open the folder intro2cs/HW1/code:
Select File > Open Folder;
Navigate to the intro2cs/HW1/code folder on your computer;
Click Open (on Windows: Select Folder) to load the folder’s files into VS Code.
The first time you open a folder, VS Code asks whether you trust the authors of its files. Click Yes, I trust the authors. Figure 1 shows how to open a folder on a Mac.

Figure 1. Opening the intro2cs/HW1/code folder from VS Code’s Welcome page (Mac).
2. Select a file to work on
Once a folder has been opened in VS Code, its files appear in the sidebar pane that VS Code calls Explorer. Click the file you want to work on. For example, if you wish to edit the Demo0 program, click the file name Demo0.py.
3. Open a new terminal session
The terms “terminal”, “command prompt”, and “shell” are used on different platforms to describe the same thing: an interactive program that lets developers manage files and run programs by typing textual commands. The names of these commands are cryptic and telegraphic. For example, the command ls lists the files in the current folder, and pwd prints the path of the current folder (in Unix, folders are called directories). There are numerous such commands, but for the purpose of this course, you need to know only a few of them.
VS Code has a built-in terminal, which is accessed as follows:
Click Terminal > New Terminal.
A terminal pane will open at the bottom of the VS Code window, in the folder you opened in step 1. On a Mac, the terminal runs a shell named zsh; on Windows, it runs PowerShell.
As a sanity check, type the following command in the terminal and press Enter:
Mac: python3 --version
Windows: python --version
If the terminal responds with Python 3.15.0 (or a newer 3.15 release), Python was installed successfully on your computer. If you get a different version or an error message:
Mac: Quit VS Code completely (⌘+Q), start it again, open a new terminal, and repeat the check. If the problem persists, run the Python installer again.
Windows: If python opens the Microsoft Store or is “not recognized”, the Add python.exe to PATH box was probably left unchecked. Run the installer again, choose Uninstall, and then install Python again, this time with the box checked. Restart VS Code and repeat the check.
4. Editing
To edit a file, use the VS Code editor, which provides color-coded syntax, helpful editing hints, and syntax error detection. To practice editing, locate in the loaded file the statement i = 0. Just below it, enter the new statement print(i). Make sure that print(i) starts at exactly the same column as i = 0. In Python, indentation (the spaces at the beginning of a line) is part of the syntax: a misaligned statement either causes an error or changes the program’s meaning.
To save your edits, click File > Save (or press Ctrl+S on Windows or ⌘+S on Mac). Curiously, VS Code does not feature a traditional file-save icon.
5. Running
To run Demo0.py, enter the following command in the terminal:
Mac: python3 Demo0.py
Windows: python Demo0.py
This command starts the Python interpreter and applies it to the file Demo0.py. The interpreter executes the program, and you will see on the screen what the program is supposed to do; thanks to the statement you added, the output will include the number 0.
If the program has a syntax error, the interpreter reports it, including the line number, and runs nothing. Other errors, such as an attempt to divide by zero, are detected only when the offending statement is reached; these are called runtime errors.
Curiously, on a Mac the command is python3, not python: a convention from the years when Macs came with the older Python 2 preinstalled as python.
Alternatively, click the Run Python File button (the triangle at the top-right corner of the editor). It uses the Python version shown in the status bar at the bottom of the window; if that version is not 3.15, click it and select Python 3.15.
Did you manage to run your first Python program?
If so, Mazal Tov! You made the first step in your software developer journey.
If you encounter errors and problems along the way, don’t worry. You just joined the millions of developers who struggle with software bugs at any given moment on this planet. So, welcome to the club! During the first week of the course, we’ll discuss installation problems and debugging and help you sort them out. If you need assistance, post a question in the Week 1 Q&A forum on the course website or raise it during the first week’s workshop (סדנה). Remember: troubleshooting is a key part of learning, so don’t hesitate to ask for help!


---

# Using AI chatbots in the course

Using AI Chatbots: A Guide to the Perplexed
שימוש בסוכני בינה מלאכותית: מורה נבוכים ונבוכות
By “AI Chatbots” we refer to such programs as ChatGPT (by OpenAI), Claude (by Anthropic), Copilot (by Microsoft), and similar tools. An “AI chatbot” can be described as a conversational search engine that simulates an intelligent, personal assistant.
Chatbots can greatly enhance your learning experience. Using a chatbot is optional. If you use one, we recommend the course AI tutor, described in the next section, and not other chatbots. If you choose to use chatbots, it’s important to do so wisely and responsibly. Over-reliance on chatbots can diminish your ability to think independently and use information critically. Specifically in your journey as a computer science student, becoming too dependent on chatbots can inhibit your performance in two mission-critical situations: exams and job interviews. In both situations, you won’t have access to chatbots or to the Internet. Therefore, to succeed in this course and beyond, it’s essential to develop skills to solve problems and write code independently.
So, how can you use chatbots wisely, to enhance your learning performance and career prospects? That’s what this little document is all about.
The course AI tutor (recommended)
The course has its own AI tutor. It runs inside Claude and was set up by the course staff for this course. It knows the lecture slides, the code examples and the homework assignments, and it follows the guidelines in this document: it explains and guides, but it doesn’t solve homework for you. We recommend that you use it as your AI chatbot in this course.
Why the course tutor and not another chatbot? Other chatbots are not set up for this course, and we can’t control what they do. They don’t know our lectures, they often use Python that the course hasn’t taught yet, and when asked, they usually hand you a complete homework solution, which takes away the practice you need for the exam. The course tutor knows where you are in the course: it uses only the Python taught so far, points you to the relevant lecture slide, and guides you through homework one step at a time. For these reasons, we don’t recommend using other chatbots for this course.
Installing the tutor. The tutor, with step-by-step instructions for installing, using and updating it, is at github.com/cs-intro-reichman/cs-intro-course. Installing takes about two minutes. After that, open a new chat in Claude and ask your question: the tutor switches on by itself, and you don’t need to mention it.
Using the tutor. Ask it the way you would ask a teaching assistant, in English or in Hebrew. For example:
•	“I don’t understand what return does. Can you explain it with an example from the lecture?”
•	“My program prints 0 instead of 3. Here is my code: …” The tutor shows you where the problem is and helps you find the fix yourself.
•	“I’m stuck on Homework 1, program 3. Here is what I tried: …” Always show what you tried. The tutor answers with hints and leading questions, one step at a time.
•	“Give me three practice questions on loops for the exam.”
The tutor won’t write homework solutions for you, even if you ask. It will offer a hint instead. This is on purpose: you’ll need to solve such problems on your own in the exam.
Keeping it up to date. New lectures and homework assignments are added to the tutor during the semester. When the course staff announce a new version, or when the tutor tells you that a topic isn’t in its material yet, reinstall it as explained on the tutor’s page (github.com/cs-intro-reichman/cs-intro-course).
1. Use AI for research and clarification, not shortcuts
Use chatbots for answering questions and providing explanations. Don’t use them as a shortcut to avoid doing the hard work yourself. For example, if you are working on some programming or algorithmic problem, ask the chatbot to explain the underlying principles, not to solve the problem for you. Understanding the why and how is far more important than getting to the right answer. For example, suppose that Bob and Alice were asked to write a program that performs binary search. Bob prompted the chatbot to “Write a Python program that performs binary search”. Alice’s prompt was “Explain binary search, and give an example”. Bob will undermine his ability to write code without external help. Alice will be motivated and guided to solve the problem on her own.
2. Verify information
AI chatbots can provide incorrect or incomplete information. Therefore, develop a habit to double-check what the chatbot says. To do so, confirm the chatbot’s answers using your course materials and common sense. For example, after asking "How can I check if two strings are equal in Python?", a chatbot answered: ”You can compare the two strings using the is operator”. As it turns out, this answer sometimes works, but is generally incorrect (the right operator is ==). The course AI tutor makes mistakes like this less often, because it works from the course material, but it can still be wrong, so check its answers too.
3. Ask clear and specific questions
For example, instead of asking "What is a loop?" ask "Can you explain the difference between a for loop and a while loop?" This will lead to more detailed and useful explanations, helping you gain deeper insights into the material.
4. Don't rely on AI for problem-solving
When it comes to programming or solving algorithmic problems, it's important to practice handling these problems on your own. Deep learning happens only when you struggle with a problem, make mistakes, and debug your code by trial and error. To reiterate an important point: In your exams and job interviews, you will not have access to AI assistance. Therefore, you must develop your ability to approach and solve problems on your own.
5. Use AI to supplement, not replace, your learning
Chatbots can supplement your learning experience, but they don’t replace traditional learning methods. Attending lectures, and doing homework assignments on your own, are vital components of a strong computer science foundation. Use chatbots as an additional resource to clarify doubts and fill in missing information, but keep your primary focus on learning through direct engagement with the course materials. In particular, go over the lecture slides after each lecture, play with the given code examples, and, optionally, use a chatbot to enhance your learning. For example, you can copy-paste a code example that was given in the lecture, and ask the chatbot to explain, or improve it. The course AI tutor already knows the lecture slides, so you can simply ask, for example, “Explain the code on slide 16 of lecture 4-1”.
6. Learn to think critically and creatively
One of the key skills you will develop in computer science is critical thinking. While chatbots are great at providing answers, they don’t teach you how to ask the right questions or think creatively. Push yourself to explore multiple solutions to a problem and consider alternative approaches. This kind of thinking will serve you well not only in exams but also in your future career as a computer scientist. For example, if you wrote code that solves a problem, and the code works correctly, you can copy-paste the code into the chatbot, and ask it to show you other ways to solve the problem. Seeing multiple solutions and understanding their pros and cons provides a tremendous educational value. (For a homework assignment, the course AI tutor will review your code and discuss other approaches with you, but it won’t write them out, because the assignment is graded.)
7. Use old school learning techniques
When you sit for job interviews, recruiters will assess your problem-solving skills and knowledge, not your ability to use AI tools. Focus on understanding the core concepts thoroughly so that you can demonstrate your skills confidently without external assistance. Practicing problems by hand, using paper and pencil, writing on whiteboards, coding from scratch in pseudo-code: these are the best techniques for preparing for exams and job interviews.
