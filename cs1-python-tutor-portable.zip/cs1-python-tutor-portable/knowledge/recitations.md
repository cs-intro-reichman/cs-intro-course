# Recitation, week 1: Types, expressions and I/O

## From `recitation 1.pptx`

## Slide 1
```python
>>>
```
INTRO TO CS COURSE · WEEK 1 · RECITATION 1
Recitation 1
Types, expressions and I/O

## Slide 2
Recitation overview
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
1
REPL warm-up
predict, then run
2
Receipt and time
input, casting, // and %
3
Bugs and booleans
three kinds of errors; answers without if
4
Randomness
a fair die, built step by step

## Slide 3
How this recitation works
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
Try first
Every exercise starts with time on your own - the chip says how many minutes. No solution appears before it runs out.
Three levels
Easy, Mid and High, in that order. Extra, at the end, is for a fast room or for home.
Only this week
Nothing here needs if, loops or anything from week 2. If you know them, do not use them yet.
The files
Every program shown is in the 'recitation 1 code' folder. Run it, change it, break it.

## Slide 4
Before we start: three checks
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
```python
1 · The interpreter
In a terminal, type python --version (or python3 --version). You should see Python 3.13.
```
```python
2 · The REPL
Type python, then 2 ** 10 at the >>> prompt. You should see 1024. Leave with exit().
```
```python
3 · A script
In VS Code, open an empty folder, create hello.py with one print line, and press Run.
```

## Slide 5
Warm-up: numbers
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
WARM-UP · 4 MIN
Write the output of every line on paper. Then we run it and compare.
`warmup_numbers.py`
```python
print(7 / 2)
print(7 // 2)
print(7 % 2)
print(2 ** 10)
print(-7 // 2)
print(type(7 / 2))
print(10 / 5)
print(1 / 3)
```
```python
Your answers
?
?
?
?
?
?
?
?
```

## Slide 6
Warm-up: numbers - the answers
What each line prints. Check it against your paper.
`warmup_numbers.py`
```python
print(7 / 2)
print(7 // 2)
print(7 % 2)
print(2 ** 10)
print(-7 // 2)
print(type(7 / 2))
print(10 / 5)
print(1 / 3)
```
```python
The answers
3.5
3
1
1024
-4
<class 'float'>
2.0
0.3333333333333333
```

## Slide 7
Warm-up: text and casting
WARM-UP · 4 MIN
Same game. One of these lines does not print anything. Which one, and why?
`warmup_text.py`
```python
print("6" + "5")
print("6" * 3)
print(6 * "5")
print(int("6") + 5)
print(str(6) + "5")
print(float("6"))
print(bool(0), bool("0"))
print("6" + 5)
```
```python
Your answers
?
?
?
?
?
?
?
?
```

## Slide 8
Warm-up: text and casting - the answers
What each line prints - and the one line that does not.
`warmup_text.py`
```python
print("6" + "5")
print("6" * 3)
print(6 * "5")
print(int("6") + 5)
print(str(6) + "5")
print(float("6"))
print(bool(0), bool("0"))
print("6" + 5)
```
```python
The answers
65
666
555
11
65
6.0
False True
TypeError - and the program stops
```

## Slide 9
Exercise 1: The receipt
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
EASY · 7 MIN ON YOUR OWN
Task: a cashier types an item, a quantity and a unit price. Print the receipt.
Read the item name, the quantity (whole) and the unit price
VAT is 18% of the subtotal; the total is subtotal plus VAT
Three lines of output, built with f-strings, rounded to 2 digits
```python
terminal
```
```python
Item: notebook
Quantity: 3
Unit price: 12.5
notebook x 3 = 37.5
VAT (18%): 6.75
Total: 44.25
```
```python
Think about
Input is text: wrap input() in int() or float()
round(x, 2) rounds x to two decimal places
```

## Slide 10
Exercise 1: one solution
`receipt.py`
```python
item = input("Item: ")
quantity = int(input("Quantity: "))
price = float(input("Unit price: "))

subtotal = quantity * price
vat = subtotal * 0.18
total = subtotal + vat

print(f"{item} x {quantity} = {subtotal}")
print(f"VAT (18%): {round(vat, 2)}")
print(f"Total: {round(total, 2)}")
```
```python
Three things to notice
Casting: int() for a count, float() for a price - the type says what the value is
f-strings: anything inside the braces is evaluated and turned into text
round(): only the printed value is rounded; the arithmetic is exact as it can be
```

## Slide 11
Exercise 1: the run
`receipt.py`
```python
item = input("Item: ")
quantity = int(input("Quantity: "))
price = float(input("Unit price: "))

subtotal = quantity * price
vat = subtotal * 0.18
total = subtotal + vat

print(f"{item} x {quantity} = {subtotal}")
print(f"VAT (18%): {round(vat, 2)}")
print(f"Total: {round(total, 2)}")
```
`python receipt.py`
```python
Item: notebook
Quantity: 3
Unit price: 12.5
notebook x 3 = 37.5
VAT (18%): 6.75
Total: 44.25
```

## Slide 12
Exercise 1, expansion: a discount
`receipt_discount.py`
```python
item = input("Item: ")
quantity = int(input("Quantity: "))
price = float(input("Unit price: "))
discount = float(input("Discount (%): "))
subtotal = quantity * price
paid = subtotal * (1 - discount / 100)
vat = paid * 0.18
total = paid + vat
print(f"{item} x {quantity} = {subtotal}")
print(f"After discount: {round(paid, 2)}")
print(f"VAT (18%): {round(vat, 2)}")
print(f"Total: {round(total, 2)}")
```
```python
What changed
One more input: the discount, as a percentage
One more line: 1 - discount / 100 is the part the customer pays
Order matters: the discount first, then VAT on the reduced price
Try it: notebook, 3, 12.5, 10 gives 33.75, 6.08 and 39.83
```

## Slide 13
Exercise 2: Seconds to h:m:s
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
EASY · 8 MIN ON YOUR OWN
Task: read a number of seconds and print it as hours, minutes and seconds.
3725 seconds is 1 hour, 2 minutes and 5 seconds
Use only whole numbers: no decimal point anywhere in the output
Two operators do all the work - which two?
```python
terminal
```
```python
Seconds: 3725
1 hours
2 minutes
5 seconds
```
```python
Think about
// answers 'how many whole units fit?'
% answers 'what is left over?'
An hour is 3600 seconds, a minute is 60
```

## Slide 14
The idea: peel off the units
3725 seconds. Take the biggest unit first, then work on what is left.
```python
1 · Hours - how many whole hours fit: 3725 // 3600 is 1
2 · What is left - the remainder: 3725 % 3600 is 125
3 · Minutes - the same pair on what is left, with 60: 125 // 60 is 2
4 · Seconds - and the remainder of that: 125 % 60 is 5
```
In pseudocode
read the number of seconds
hours = seconds // 3600
rest = seconds % 3600
minutes = rest // 60
seconds = rest % 60
print hours, minutes, seconds

## Slide 15
Exercise 2: one solution
`seconds.py`
```python
total = int(input("Seconds: "))

hours = total // 3600
rest = total % 3600
minutes = rest // 60
seconds = rest % 60

print(f"{hours} hours")
print(f"{minutes} minutes")
print(f"{seconds} seconds")
```
```python
Why these operators
Why not /: 3725 / 3600 is 1.0347..., a float
The remainder: % keeps the seconds that did not fit into hours
Naming: rest is a variable, computed once and used twice
```
`python seconds.py`
```python
Seconds: 3725
1 hours
2 minutes
5 seconds
```

## Slide 16
Exercise 3: Three bugs
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: this program has three bugs, one of each kind. Find them, name the kind, fix them.
Run it as it is; read the message from the last line up
Fix one bug, run again, read the next message
The third bug prints no message: the program runs, the answer is wrong
```python
terminal
```
```python
$ python average.py
  File "average.py", line 5
    print(f"Average: {average}"
         ^
SyntaxError: '(' was never closed
```

## Slide 17
Exercise 3: the three bugs, fixed
`average.py`
```python
# average.py - the average of two grades
first = float(input("First grade: "))
second = float(input("Second grade: "))
average = (first + second) / 2
print(f"Average: {average}")
```
```python
One of each kind
Syntax: the missing ) on line 5 - Python refuses to run anything until it is fixed
Runtime: second / 2 divides text by a number - TypeError the moment that line runs; cast both inputs
Logical: first + second / 2 adds first to half of second; parentheses fix the precedence
```
`python average.py`
```python
First grade: 80
Second grade: 90
Average: 85.0
```

## Slide 18
Reading a traceback
The habit that saves the most time this semester:
Last line first - the kind of error and what caused it
Then the File line - the file name and the line number
Then the caret - points at the exact expression that failed
Everything in between is Python showing its work
A traceback is not an insult.
It is the interpreter telling you, as precisely as it can, where to look.

## Slide 19
Exercise 4: Answers without if
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: two yes-or-no questions. Print True or False - the comparison is the answer.
Triangle: read three stick lengths. Can they form a triangle? Each pair of sides must add up to more than the third
Palindrome: read a three-digit number. Is it the same backwards? 121 yes, 123 no
No if anywhere: a boolean expression is a value - print it, or store it
```python
terminal
```
```python
Sides: 3 4 5 -> True
Sides: 1 2 5 -> False
Number: 121 -> True
Number: 123 -> False
```
```python
Think about
and joins three comparisons into one answer
First digit of a 3-digit number: n // 100; last digit: n % 10
```

## Slide 20
Exercise 4: the triangle
`triangle.py`
```python
a = int(input("Side a: "))
b = int(input("Side b: "))
c = int(input("Side c: "))

ok = a + b > c and a + c > b and b + c > a
print(f"Triangle: {ok}")
```
```python
One expression is the answer
Precedence: + binds tighter than >, and > tighter than and - no parentheses needed, but they never hurt
A name for the answer: ok holds True or False; next week if ok: will read like English
Three tests: 3 4 5, 1 2 5 and 5 1 2 - the last one catches a program that checked only one pair
```
`python triangle.py`
```python
Side a: 5
Side b: 1
Side c: 2
Triangle: False
```

## Slide 21
Exercise 4: the palindrome
`palindrome3.py`
```python
n = int(input("A three-digit number: "))

first = n // 100
last = n % 10
print(f"Palindrome: {first == last}")
```
```python
Digits without strings
First digit: n // 100 - how many whole hundreds
Last digit: n % 10 - what is left after the tens
The middle digit never matters: 121, 131 and 191 are all palindromes
Inside the f-string: first == last is evaluated, and the result is True or False
```
`python palindrome3.py`
```python
A three-digit number: 121
Palindrome: True
```

## Slide 22
Exercise 5: A fair die
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
HIGH · 12 MIN ON YOUR OWN
Task: simulate a fair six-sided die. Print a whole number from 1 to 6, each equally likely.
```python
You have random.random(): a float in [0, 1) - 0 is possible, 1 is not
Four things are wrong with that for a die. Name them before you fix them
Then: an N-sided die, and then any whole number from low to high (both included)
```
```python
the REPL
```
```python
>>> import random
>>> random.random()
0.7303...
>>> ???
4
```
```python
Think about
Multiplying stretches the range; adding shifts it; int() cuts the decimals
Check each step on paper with 0.0 and with 0.999
```

## Slide 23
The idea: stretch, cut, shift
random.random() is a float in [0, 1). Fix one gap per step; check 0.0 and 0.999 each time.
```python
1 · Stretch - r * 6 is a float in [0, 6): 0.0 stays 0.0, 0.999 becomes 5.994
2 · Cut - int(r * 6) is a whole number from 0 to 5: 5.994 becomes 5
3 · Shift - int(r * 6) + 1 is a whole number from 1 to 6: a die
4 · Check - each face owns a slice of width 1/6 of [0, 1): the die is fair
```
In pseudocode
r = a random float in [0, 1)
stretch: r * 6, now in [0, 6)
cut: int(...), now 0 to 5
shift: + 1, now 1 to 6
print it

## Slide 24
Exercise 5: one solution, step by step
`die.py`
```python
import random

r = random.random()
print(f"random.random() gave {r}")

stretched = r * 6
cut = int(stretched)
face = cut + 1
print(f"stretched: {stretched}")
print(f"cut: {cut}")
print(f"the die shows {face}")
```
```python
Why it is fair
Equal slices: r falls in [0, 1/6) for a 1, in [1/6, 2/6) for a 2, and so on - six slices of the same size
The top is safe: r is never 1.0, so r * 6 is never 6.0, so the face is never 7
One line: int(random.random() * 6) + 1 is how it is written in real code
```

## Slide 25
Exercise 5: the run
`die.py`
```python
import random

r = random.random()
print(f"random.random() gave {r}")

stretched = r * 6
cut = int(stretched)
face = cut + 1
print(f"stretched: {stretched}")
print(f"cut: {cut}")
print(f"the die shows {face}")
```
```python
python die.py (one run)
```
```python
random.random() gave 0.7303
stretched: 4.3818
cut: 4
the die shows 5
```

## Slide 26
Exercise 5: N sides, and any range
The same three steps, with the task's own numbers in place of 6 and 1.
`die_n.py`
```python
import random
n = int(input("How many sides? "))
r = random.random()
face = int(r * n) + 1
print(f"The die shows {face}")
```
`random_range.py`
```python
import random
low = int(input("Lowest: "))
high = int(input("Highest: "))
count = high - low + 1
r = random.random()
value = int(r * count) + low
print(f"Picked {value}")
```
N sides: stretch by N, cut, shift by 1. N = 6 is the die; N = 2 is a coin.
A range: high - low + 1 values, so stretch by that count and shift by low. Check: 0.0 gives low, 0.999 gives high.

## Slide 27
Exercise 5: is doubling a die two dice?
Dana rolled one die and doubled it. Noam rolled two. Same thing?
`double_die.py`
```python
import random
face = int(random.random() * 6) + 1
total = 2 * face
print(f"Doubled: {total}")
```
`two_dice.py`
```python
import random
first = int(random.random() * 6) + 1
second = int(random.random() * 6) + 1
total = first + second
print(f"Two dice: {total}")
```
```python
Think about
Can Dana's program ever print 7? Can it print 3?
Which total does Noam's program print most often, and why?
How many times does each program call random.random()?
```

## Slide 28
Exercise 5: is doubling a die two dice?
Dana rolled one die and doubled it. Noam rolled two. Same thing?
`double_die.py`
```python
import random
face = int(random.random() * 6) + 1
total = 2 * face
print(f"Doubled: {total}")
```
`two_dice.py`
```python
import random
first = int(random.random() * 6) + 1
second = int(random.random() * 6) + 1
total = first + second
print(f"Two dice: {total}")
```
```python
No. Dana's total is always even, and 2, 4, ..., 12 are equally likely. Noam's can be 7, and 7 is the most likely sum.
Each call to random.random() is a fresh draw: two independent values need two calls.
```

## Slide 29
Extra: if there is time
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
EXTRA
Two more exercises. In class if we are ahead of the plan; otherwise the first thing to try at home.
Extra 1: The clock
22:45 plus 150 minutes: the two operators of exercise 2, with a wrap-around at 24.
Extra 2: Four digits
The digits of a four-digit number, their sum, and the number backwards - with // and % only.

## Slide 30
Extra 1: The clock
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
EXTRA
Task: it is 22:45. A film lasts 150 minutes. When does it end?
Read the hour, the minutes and the duration in minutes
Print the time when the film ends, on a 24-hour clock
22:45 plus 150 minutes is 1:15 the next day - the hours wrap around at 24
```python
terminal
```
```python
Hours now: 22
Minutes now: 45
Duration in minutes: 150
Ends at 1:15
```
```python
Think about
Turn everything into minutes first, then back into hours and minutes
Wrapping around 24: what does % do for you?
```

## Slide 31
Extra 1: one solution
`clock.py`
```python
hours = int(input("Hours now: "))
minutes = int(input("Minutes now: "))
duration = int(input("Duration in minutes: "))

total = hours * 60 + minutes + duration
end_hours = (total // 60) % 24
end_minutes = total % 60

print(f"Ends at {end_hours}:{end_minutes}")
```
```python
The plan, in three lines
One unit: total is minutes since midnight, plus the film
Back out: // 60 gives hours, % 60 gives the minutes that did not fit
The wrap: % 24 turns 25 hours into 1 - the same trick as a clock face
```
`python clock.py`
```python
Hours now: 22
Minutes now: 45
Duration in minutes: 150
Ends at 1:15
```

## Slide 32
Extra 1, expansion: always two digits
`clock_two_digits.py`
```python
hours = int(input("Hours now: "))
minutes = int(input("Minutes now: "))
duration = int(input("Duration in minutes: "))

total = hours * 60 + minutes + duration
end_hours = (total // 60) % 24
end_minutes = total % 60

tens = end_minutes // 10
ones = end_minutes % 10
print(f"Ends at {end_hours}:{tens}{ones}")
```
```python
Digits are units too
Tens and ones: // 10 and % 10 split a number below 100 into its two digits
Printing them side by side: {tens}{ones} with nothing in between
9:05 now prints as 9:05 - and 9:30 still prints as 9:30
```
`python clock_two_digits.py`
```python
Hours now: 9
Minutes now: 0
Duration in minutes: 5
Ends at 9:05
```

## Slide 33
Extra 2: Four digits
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
EXTRA
Task: read a four-digit number. Print its digits, their sum, and the number backwards.
```python
4913 has the digits 4, 9, 1, 3; their sum is 17; backwards it is 3194
Only //, %, * and + - no strings, no loops
One more line: is the number a palindrome? True or False
```
```python
terminal
```
```python
Number: 4913
Digits: 4 9 1 3
Sum: 17
Backwards: 3194
Palindrome: False
```
```python
Think about
Thousands: n // 1000. Then the remainder, with 100, 10 and 1
Backwards: the units digit goes into the thousands place
```

## Slide 34
Extra 2: one solution
`digits.py`
```python
n = int(input("Number: "))

d1 = n // 1000          # thousands
d2 = n % 1000 // 100    # hundreds
d3 = n % 100 // 10      # tens
d4 = n % 10             # units
backwards = d4 * 1000 + d3 * 100 + d2 * 10 + d1

print(f"Digits: {d1} {d2} {d3} {d4}")
print(f"Sum: {d1 + d2 + d3 + d4}")
print(f"Backwards: {backwards}")
print(f"Palindrome: {n == backwards}")
```
```python
Reading the digit lines
Remainder, then quotient: n % 1000 // 100 drops the thousands, then counts the hundreds
Left to right: % and // have the same precedence, so it is (n % 1000) // 100
Backwards: the place values 1000, 100, 10, 1 are handed out in reverse order
```

## Slide 35
Extra 2: the run
`digits.py`
```python
n = int(input("Number: "))

d1 = n // 1000          # thousands
d2 = n % 1000 // 100    # hundreds
d3 = n % 100 // 10      # tens
d4 = n % 10             # units
backwards = d4 * 1000 + d3 * 100 + d2 * 10 + d1

print(f"Digits: {d1} {d2} {d3} {d4}")
print(f"Sum: {d1 + d2 + d3 + d4}")
print(f"Backwards: {backwards}")
print(f"Palindrome: {n == backwards}")
```
`python digits.py`
```python
Number: 4913
Digits: 4 9 1 3
Sum: 17
Backwards: 3194
Palindrome: False
```

## Slide 36
The swap without a temporary
Swap two numbers using only + and -. Fill in the trace for a = 7, b = 3.
`swap.py`
```python
a = int(input("a: "))
b = int(input("b: "))

a = a + b
b = a - b
a = a - b

print(f"a = {a}, b = {b}")
```
step | a | b
start | 7 | 3
a = a + b |  | 
b = a - b |  | 
a = a - b |  | 

## Slide 37
The swap without a temporary - the trace
With a = 7, b = 3: after each line, exactly one of the two variables has changed.
`swap.py`
```python
a = int(input("a: "))
b = int(input("b: "))

a = a + b
b = a - b
a = a - b

print(f"a = {a}, b = {b}")
```
step | a | b
start | 7 | 3
a = a + b | 10 | 3
b = a - b | 10 | 7
a = a - b | 3 | 7

## Slide 38
Recitation summary
Warm-up
Receipt & time
Bugs
Booleans
Randomness
Extra
Wrap-up
What we practised
Casting
int(input()) and float(input()) for every number you read.
// and %
Whole units and the remainder: time, money, digits.
f-strings
Expressions inside the braces become text.
Booleans
A comparison is a value: print it, store it, combine it with and.
Tools we used
Built-ins
print, input, int, float, str, bool, type, round, abs
Modules
random.random() in [0, 1); math.pi and math.sqrt in the extras
Operators
+ - * / // % ** and the six comparisons
Errors
SyntaxError, TypeError, ValueError, ZeroDivisionError - read from the bottom

## Slide 39
Self practice
AT HOME
Write a program for each of these.
Circle
Read a radius and print the circumference and the area, using math.pi and round().
Average of three
Read three grades and print their average, rounded to one decimal place.
Change
Read an amount in shekels and print how many 10, 5, 2 and 1 shekel coins give exactly that amount, using as few coins as possible.
Savings
Read a starting amount, a yearly interest rate in percent and a number of years; print the final amount, using **.

## Slide 40
INTRO TO COURSE · WEEK 2 · RECITATION 2
Next: Conditionals and loops
if, elif, else, while and for

## From `average.py`

### `average.py`
```python
# average.py - the average of two grades
first = float(input("First grade: "))
second = float(input("Second grade: "))
average = (first + second) / 2
print(f"Average: {average}")
```

## From `average_bugs.py`

### `average_bugs.py`
```python
# average.py - the average of two grades
first = input("First grade: ")
second = input("Second grade: ")
average = first + second / 2
print(f"Average: {average}"
```

## From `clock.py`

### `clock.py`
```python
hours = int(input("Hours now: "))
minutes = int(input("Minutes now: "))
duration = int(input("Duration in minutes: "))

total = hours * 60 + minutes + duration
end_hours = (total // 60) % 24
end_minutes = total % 60

print(f"Ends at {end_hours}:{end_minutes}")
```

## From `clock_two_digits.py`

### `clock_two_digits.py`
```python
hours = int(input("Hours now: "))
minutes = int(input("Minutes now: "))
duration = int(input("Duration in minutes: "))

total = hours * 60 + minutes + duration
end_hours = (total // 60) % 24
end_minutes = total % 60

tens = end_minutes // 10
ones = end_minutes % 10
print(f"Ends at {end_hours}:{tens}{ones}")
```

## From `die.py`

### `die.py`
```python
import random

r = random.random()
print(f"random.random() gave {r}")

stretched = r * 6
cut = int(stretched)
face = cut + 1
print(f"stretched: {stretched}")
print(f"cut: {cut}")
print(f"the die shows {face}")
```

## From `die_n.py`

### `die_n.py`
```python
import random
n = int(input("How many sides? "))
r = random.random()
face = int(r * n) + 1
print(f"The die shows {face}")
```

## From `digits.py`

### `digits.py`
```python
n = int(input("Number: "))

d1 = n // 1000          # thousands
d2 = n % 1000 // 100    # hundreds
d3 = n % 100 // 10      # tens
d4 = n % 10             # units
backwards = d4 * 1000 + d3 * 100 + d2 * 10 + d1

print(f"Digits: {d1} {d2} {d3} {d4}")
print(f"Sum: {d1 + d2 + d3 + d4}")
print(f"Backwards: {backwards}")
print(f"Palindrome: {n == backwards}")
```

## From `double_die.py`

### `double_die.py`
```python
import random
face = int(random.random() * 6) + 1
total = 2 * face
print(f"Doubled: {total}")
```

## From `palindrome3.py`

### `palindrome3.py`
```python
n = int(input("A three-digit number: "))

first = n // 100
last = n % 10
print(f"Palindrome: {first == last}")
```

## From `random_range.py`

### `random_range.py`
```python
import random
low = int(input("Lowest: "))
high = int(input("Highest: "))
count = high - low + 1
r = random.random()
value = int(r * count) + low
print(f"Picked {value}")
```

## From `receipt.py`

### `receipt.py`
```python
item = input("Item: ")
quantity = int(input("Quantity: "))
price = float(input("Unit price: "))

subtotal = quantity * price
vat = subtotal * 0.18
total = subtotal + vat

print(f"{item} x {quantity} = {subtotal}")
print(f"VAT (18%): {round(vat, 2)}")
print(f"Total: {round(total, 2)}")
```

## From `receipt_discount.py`

### `receipt_discount.py`
```python
item = input("Item: ")
quantity = int(input("Quantity: "))
price = float(input("Unit price: "))
discount = float(input("Discount (%): "))
subtotal = quantity * price
paid = subtotal * (1 - discount / 100)
vat = paid * 0.18
total = paid + vat
print(f"{item} x {quantity} = {subtotal}")
print(f"After discount: {round(paid, 2)}")
print(f"VAT (18%): {round(vat, 2)}")
print(f"Total: {round(total, 2)}")
```

## From `seconds.py`

### `seconds.py`
```python
total = int(input("Seconds: "))

hours = total // 3600
rest = total % 3600
minutes = rest // 60
seconds = rest % 60

print(f"{hours} hours")
print(f"{minutes} minutes")
print(f"{seconds} seconds")
```

## From `swap.py`

### `swap.py`
```python
a = int(input("a: "))
b = int(input("b: "))

a = a + b
b = a - b
a = a - b

print(f"a = {a}, b = {b}")
```

## From `triangle.py`

### `triangle.py`
```python
a = int(input("Side a: "))
b = int(input("Side b: "))
c = int(input("Side c: "))

ok = a + b > c and a + c > b and b + c > a
print(f"Triangle: {ok}")
```

## From `two_dice.py`

### `two_dice.py`
```python
import random
first = int(random.random() * 6) + 1
second = int(random.random() * 6) + 1
total = first + second
print(f"Two dice: {total}")
```

## From `warmup_numbers.py`

### `warmup_numbers.py`
```python
print(7 / 2)
print(7 // 2)
print(7 % 2)
print(2 ** 10)
print(-7 // 2)
print(type(7 / 2))
print(10 / 5)
print(1 / 3)
```

## From `warmup_text.py`

### `warmup_text.py`
```python
print("6" + "5")
print("6" * 3)
print(6 * "5")
print(int("6") + 5)
print(str(6) + "5")
print(float("6"))
print(bool(0), bool("0"))
print("6" + 5)
```


---

# Recitation, week 2: Conditions and loops

## From `recitation 2.pptx`

## Slide 1
```python
while
```
PYTHON COURSE · WEEK 2 · RECITATION 2
Recitation 2
Conditions and while loops

## Slide 2
Recitation overview
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
1
Predictions
booleans, floats, and the four loop bugs
2
Conditions
elif, order, a one-line if, and guards
3
while
games that stop when something happens
4
Loops inside loops
patterns, and a stream that ends with a sentinel

## Slide 3
Warm-up: booleans and floats
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
WARM-UP · 3 MIN
x is 7. Write the output of every line before we run it. Two of the lines are traps.
`warmup_booleans.py`
```python
x = 7
print(x > 5 and x < 10)
print(not x == 7)
print(x % 2 == 0 or x % 3 == 0)
print(5 <= x <= 7)
print(x == 7.0, x == "7")
print(0.1 + 0.2 == 0.3)
print(abs(0.1 + 0.2 - 0.3) < 1e-9)
print(type(x > 5))
```
```python
The answers
True
False
False (7 is odd and not a multiple of 3)
True (one comparison, not two)
True False (7 == 7.0, but "7" is text)
False (the float trap)
True (compare the gap)
<class 'bool'>
```

## Slide 4
Warm-up: how many lines?
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
WARM-UP · 4 MIN
One character apart. How many lines does each print, and what is i after?
`warmup_loops_1.py`
```python
# A
i = 0
while i < 5:
    print(i)
    i += 1

# B
i = 0
while i <= 5:
    print(i)
    i += 1
```
The answers
A: 5 lines, 0 to 4, and i ends at 5
B: 6 lines, 0 to 5, and i ends at 6
Neither is wrong: using one when you meant the other is the bug

## Slide 5
Warm-up: what goes wrong?
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
WARM-UP · 2 MIN
Two more. Each has one of the classic loop bugs. Which, and what is printed?
`warmup_loops_2.py`
```python
# C
i = 0
while i < 5:
    print(i)
i += 1

# D
i = 1
total = 0
while i < 4:
    total = 0
    total += i
    i += 1
print(total)
```
```python
The answers
C: prints 0 forever - the update sits outside the body. Ctrl-C stops it
D: prints 3, not 6 - total is reset to 0 on every pass
Read the indentation, not the intention
```

## Slide 6
Exercise 1: Ticket price
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
EASY · 7 MIN ON YOUR OWN
Task: a cinema charges by age. Read an age and print the price.
Under 5: free. 5 to 17: 20. 18 to 64: 40. 65 and up: 25
One if-elif-else chain, with the tests in an order that works
Print 'Free' for a price of 0, using the conditional expression (one line)
```python
terminal
```
```python
Age: 3
Free

Age: 70
Price: 25
```
```python
Think about
An elif chain stops at the first True test
x if condition else y is a value: assign it, print it
```

## Slide 7
Exercise 1: Is Eligible to Vote
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
EASY · 7 MIN ON YOUR OWN
Task: a cinema charges by age. Read an age and print the price.
Under 5: free. 5 to 17: 20. 18 to 64: 40. 65 and up: 25
One if-elif-else chain, with the tests in an order that works
Print 'Free' for a price of 0, using the conditional expression (one line)
```python
terminal
```
```python
Age: 3
Free

Age: 70
Price: 25
```
```python
Think about
An elif chain stops at the first True test
x if condition else y is a value: assign it, print it
```

## Slide 8
Exercise 1: one solution
`ticket.py`
```python
age = int(input("Age: "))

if age < 5:
    price = 0
elif age < 18:
    price = 20
elif age < 65:
    price = 40
else:
    price = 25

msg = f"Price: {price}"
print("Free" if price == 0 else msg)
```
```python
Reading the chain
Each test assumes the earlier ones failed: age < 18 only runs for ages 5 and up, so it means 5 to 17
The else: whoever is left - 65 and up
A value, not a statement: the conditional expression picks one of two strings to print
```
`python ticket.py`
```python
Age: 17
Price: 20
```

## Slide 9
Alice reordered the tests. Same result?
Alice tested the biggest group first. Same result for every age?
```python
ticket.py (ours)
```
```python
if age < 5:
    price = 0
elif age < 18:
    price = 20
elif age < 65:
    price = 40
else:
    price = 25
```
`ticket_alice.py`
```python
if age < 65:
    price = 40
elif age < 18:
    price = 20
elif age < 5:
    price = 0
else:
    price = 25
```
```python
No. A three-year-old passes age < 65 first and pays 40. The later tests never run.
Rule: most specific test first, or make every test exclusive: 5 <= age < 18.
```

## Slide 10
Exercise 2: The quadratic equation, properly
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
EASY · 7 MIN ON YOUR OWN
Task: lecture 1-2's quadratic.py crashes when d is negative, and assumes a is 1. Fix both.
Read a, b and c as floats; the equation is a x² + b x + c = 0
If a is 0 it is not quadratic: one root -c / b when b is not 0, otherwise 'Not an equation'
Otherwise d = b² - 4 a c decides: no real roots, one root, or two
Round every root to 2 digits; call math.sqrt only when it is safe
```python
terminal
```
```python
a: 1
b: -3
c: 2
x1 = 2.0
x2 = 1.0
```
Think about
A guard runs before the operation it protects: test d, then take the root
Ask about a before d: the formula divides by 2a
Three cases of d: an elif chain, in an order that cannot overlap

## Slide 11
Exercise 2: one solution
`quadratic.py`
```python
import math
a = float(input("a: "))
b = float(input("b: "))
c = float(input("c: "))
if a == 0:
    if b == 0:
        print("Not an equation")
    else:
        print(f"One root: {round(-c / b, 2)}")
else:
    d = b * b - 4 * a * c
    if d < 0:
        print("No real roots")
    elif d == 0:
        print(f"One root: {round(-b / (2 * a), 2)}")
    else:
        root = math.sqrt(d)
        print(f"x1 = {round((-b + root) / (2 * a), 2)}")
        print(f"x2 = {round((-b - root) / (2 * a), 2)}")
```
Guards, nested
a == 0 first: the formula divides by 2a, so the linear case is answered before any root is computed
d decides: an elif chain with three cases that cannot overlap - negative, zero, positive
math.sqrt(d) only in the else: the guard of lecture 2-1, protecting the call that crashed in lecture 1-2
round(..., 2) on the printed value: the arithmetic stays exact; only the text is shortened
`python quadratic.py`
```python
a: 1
b: 2
c: 1
One root: -1.0
```

## Slide 12
Exercise 2: the run
`quadratic.py`
```python
import math
a = float(input("a: "))
b = float(input("b: "))
c = float(input("c: "))
if a == 0:
    if b == 0:
        print("Not an equation")
    else:
        print(f"One root: {round(-c / b, 2)}")
else:
    d = b * b - 4 * a * c
    if d < 0:
        print("No real roots")
    elif d == 0:
        print(f"One root: {round(-b / (2 * a), 2)}")
    else:
        root = math.sqrt(d)
        print(f"x1 = {round((-b + root) / (2 * a), 2)}")
        print(f"x2 = {round((-b - root) / (2 * a), 2)}")
```
`python quadratic.py`
```python
a: 1
b: -3
c: 2
x1 = 2.0
x2 = 1.0

a: 0
b: 2
c: -8
One root: 4.0
```

## Slide 13
Exercise 3: Guess the number
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: the computer picks a secret number from 1 to 100. The player guesses until it is found.
After every guess print Higher, Lower or Correct
A guess outside 1 to 100 is refused with a message and does not count
At the end, print how many valid tries it took
```python
terminal
```
```python
Guess: 50
Higher
Guess: 200
Between 1 and 100, please
Guess: 62
Correct in 2 tries
```
```python
Think about
Rounds unknown in advance: while True and break when it is found
The secret: int(random.random() * 100) + 1, a 100-sided die
```

## Slide 14
Exercise 3: one solution
`guess.py`
```python
import random
secret = int(random.random() * 100) + 1
tries = 0
while True:
    guess = int(input("Guess: "))
    if guess < 1 or guess > 100:
        print("Between 1 and 100, please")
    else:
        tries += 1
        if guess < secret:
            print("Higher")
        elif guess > secret:
            print("Lower")
        else:
            print(f"Correct in {tries} tries")
            break
```
```python
The shape of the loop
while True: the exit is in the middle of the body, where the answer is known
The invalid branch first: it counts nothing and asks again
Nested if: inside the else, the three valid cases; tries is bumped once, before them
break: ends the loop at once; the header never becomes False
```

## Slide 15
Exercise 3: the run
`guess.py`
```python
import random
secret = int(random.random() * 100) + 1
tries = 0
while True:
    guess = int(input("Guess: "))
    if guess < 1 or guess > 100:
        print("Between 1 and 100, please")
    else:
        tries += 1
        if guess < secret:
            print("Higher")
        elif guess > secret:
            print("Lower")
        else:
            print(f"Correct in {tries} tries")
            break
```
`python guess.py`
```python
Guess: 50
Higher
Guess: 75
Lower
Guess: 62
Correct in 3 tries
```

## Slide 16
Exercise 3, expansion: the computer guesses
`computer_guesses.py`
```python
low = 1
high = 100
rounds = 0
while True:
    guess = (low + high) // 2
    rounds += 1
    answer = input(f"Is it {guess}? (h/l/c) ")
    if answer == "c":
        print(f"Got it in {rounds} rounds")
        break
    elif answer == "h":
        low = guess + 1
    else:
        high = guess - 1
```
Roles reversed
You think of a number; the computer guesses the middle of what is left
h means 'higher than that', l means 'lower', c means 'correct'
Halving: every answer throws away half the range - at most 7 rounds for 1 to 100
Bisection in disguise: lecture 3-2 will do this to find a square root

## Slide 17
Exercise 4: The 3n + 1 game
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: start from n. If n is even, halve it; if it is odd, make it 3n + 1. Stop at 1. Count the steps.
6 -> 3 -> 10 -> 5 -> 16 -> 8 -> 4 -> 2 -> 1: eight steps
Read n, print the sequence on one line, then the number of steps
Nobody has proved that every n reaches 1 - but every n ever tried does
```python
terminal
```
```python
n: 6
6 3 10 5 16 8 4 2 1
8 steps
```
```python
Think about
A loop that runs until a condition is met: while n != 1
Even or odd: n % 2 == 0
One accumulator counts the steps
```

## Slide 18
Exercise 4: one solution
`collatz.py`
```python
n = int(input("n: "))

steps = 0
while n != 1:
    print(n, end=" ")
    if n % 2 == 0:
        n = n // 2
    else:
        n = 3 * n + 1
    steps += 1
print(n)
print(f"{steps} steps")
```
```python
Reading the loop
The condition: n != 1 - the loop ends when n becomes 1, however long that takes
Two updates: exactly one of the two branches changes n on every pass
The last 1: printed after the loop, because the body never sees n == 1
n // 2, not n / 2: keep n an int, or 3.0 appears in the output
```

## Slide 19
Exercise 4: the run
`collatz.py`
```python
n = int(input("n: "))

steps = 0
while n != 1:
    print(n, end=" ")
    if n % 2 == 0:
        n = n // 2
    else:
        n = 3 * n + 1
    steps += 1
print(n)
print(f"{steps} steps")
```
`python collatz.py`
```python
n: 6
6 3 10 5 16 8 4 2 1
8 steps
```

## Slide 20
Exercise 5: Patterns
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: read a size n and print two patterns with a while loop inside a while loop.
A hollow square: stars on the border, spaces inside
A checkerboard: # and . alternating, every row shifted by one
Each cell is one print(..., end=""); one bare print() ends a row
```python
terminal
```
```python
n: 5
*****   #.#.#
*   *   .#.#.
*   *   #.#.#
*   *   .#.#.
*****   #.#.#
```
Think about
Which cells are on the border? Think about i and j, not about the picture
On the checkerboard, what do all the # cells have in common? Add i and j

## Slide 21
Exercise 5: the hollow square
`hollow_square.py`
```python
n = int(input("n: "))

i = 0
while i < n:
    j = 0
    while j < n:
        on_row = i == 0 or i == n - 1
        on_col = j == 0 or j == n - 1
        if on_row or on_col:
            print("*", end="")
        else:
            print(" ", end="")
        j += 1
    print()
    i += 1
```
```python
A cell is a pair (i, j)
The visit: two loops reach every cell once, row by row; j = 0 sits inside the outer loop, so every row starts at column 0
The border: first or last row, or first or last column - two booleans, joined by or
The row: end="" keeps the cells on one line; the bare print() ends it
The updates: j += 1 is the last line of the inner body, i += 1 the last line of the outer one
Try n = 1 and n = 2: every cell is on the border
```

## Slide 22
Exercise 5: the run
`hollow_square.py`
```python
n = int(input("n: "))

i = 0
while i < n:
    j = 0
    while j < n:
        on_row = i == 0 or i == n - 1
        on_col = j == 0 or j == n - 1
        if on_row or on_col:
            print("*", end="")
        else:
            print(" ", end="")
        j += 1
    print()
    i += 1
```
`python hollow_square.py`
```python
n: 5
*****
*   *
*   *
*   *
*****
```

## Slide 23
Exercise 5: the checkerboard
`checkerboard.py`
```python
n = int(input("n: "))

i = 0
while i < n:
    j = 0
    while j < n:
        if (i + j) % 2 == 0:
            print("#", end="")
        else:
            print(".", end="")
        j += 1
    print()
    i += 1
```
```python
Parity of i + j
Same skeleton: two loops, one if per cell, one bare print() per row
The test: a # where i + j is even - one step in any direction flips the parity
Why it works: neighbours differ by one in i or in j, never in both
Your turn: swap the two characters without touching the condition
```

## Slide 24
Exercise 5: the run
`checkerboard.py`
```python
n = int(input("n: "))

i = 0
while i < n:
    j = 0
    while j < n:
        if (i + j) % 2 == 0:
            print("#", end="")
        else:
            print(".", end="")
        j += 1
    print()
    i += 1
```
`python checkerboard.py`
```python
n: 5
#.#.#
.#.#.
#.#.#
.#.#.
#.#.#
```

## Slide 25
Exercise 6: Statistics until -1
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
HIGH · 12 MIN ON YOUR OWN
Task: read non-negative numbers until -1 is entered. Report what came in.
Print how many numbers there were, their sum, their average (2 digits), the smallest and the largest
If -1 was the very first thing typed, print 'No numbers were entered.' and nothing else
Lecture 2-1's smallest.py found the minimum; keep its shape and add the other four answers
```python
terminal
```
```python
Number (-1 to finish): 8
Number (-1 to finish): 3
Number (-1 to finish): -1
Count: 2
Sum: 11
Average: 5.5
Smallest: 3
Largest: 8
```
Think about
The first number seeds smallest and largest: read it before the loop
Four accumulators, initialised once; the average divides by count, so guard the empty case

## Slide 26
The idea: seed, then stream
The numbers arrive one at a time and the program does not know how many. One value ends the stream; the rest is bookkeeping.
```python
1 · Seed - read the first number before the loop; it is the smallest and the largest so far
2 · Test - the loop runs while the number is not the sentinel: while x != END
3 · Account - count it, add it, and move smallest and largest if it beats them
4 · Next - the last line of the body reads the next number; the header tests it
5 · Report - after the loop: nothing was entered, or the five answers
```
In pseudocode
read x
count = 0, total = 0
smallest = x, largest = x
while x is not -1:
      count it, add it
      smallest? largest?
      read the next x
if count is 0: say so
else: print the five answers

## Slide 27
Exercise 6: the loop (1 of 2)
```python
stats.py (lines 1-16)
```
```python
END = -1

x = int(input("Number (-1 to finish): "))
count = 0
total = 0
smallest = x
largest = x

while x != END:
    count += 1
    total += x
    if x < smallest:
        smallest = x
    if x > largest:
        largest = x
    x = int(input("Number (-1 to finish): "))
```
```python
Discover
A named sentinel: END = -1 says what the number means; the header reads while x != END
The seed: smallest and largest start as the first number, not as 0
Two independent ifs: a number can be the new smallest or the new largest, and the first one is both
The read is last: handle the current x, then fetch the next; the header tests it
```

## Slide 28
Exercise 6: the report (2 of 2)
```python
stats.py (lines 18-26)
```
```python
if count == 0:
    print("No numbers were entered.")
else:
    print(f"Count: {count}")
    print(f"Sum: {total}")
    print(f"Average: {round(total / count, 2)}")
    print(f"Smallest: {smallest}")
    print(f"Largest: {largest}")
```
Act
The guard: count == 0 means -1 came first; the else never divides by zero
Five lines, five answers: f-strings with the accumulators, round() for the average only
`python stats.py`
```python
Number (-1 to finish): 8
Number (-1 to finish): 3
Number (-1 to finish): 9
Number (-1 to finish): -1
Count: 3
Sum: 20
Average: 6.67
Smallest: 3
Largest: 9
```

## Slide 29
Exercise 6, expansion: a text sentinel
`stats_text.py`
```python
text = input("Number (done to finish): ")
count = 0
total = 0

while text != "done":
    x = int(text)
    count += 1
    total += x
    text = input("Number (done to finish): ")

if count == 0:
    print("No numbers were entered.")
else:
    print(f"Count: {count}")
    print(f"Average: {round(total / count, 2)}")
```
```python
When -1 is a legitimate value
Read text, not a number: the line stays a string until the loop has checked it
The sentinel is a word: while text != "done" - a string comparison, as in lecture 1-2; no number can collide with it
Cast inside the body: int(text) runs only for real numbers, never for the sentinel
```
`python stats_text.py`
```python
Number (done to finish): 8
Number (done to finish): -1
Number (done to finish): done
Count: 2
Average: 3.5
```

## Slide 30
Extra 1: Digits of any length
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
EXTRA
Task: recitation 1 took a four-digit number apart. Do it for any length, with a loop.
Read a non-negative integer. Print how many digits it has, their sum, the number backwards, and whether it is a palindrome
Only //, %, * and + inside the loop - no strings
Check your answer on 0 and on 10 before you trust it
```python
terminal
```
```python
Number: 4913
Digits: 4
Sum: 17
Backwards: 3194
Palindrome: False
```
```python
Think about
n % 10 is the last digit, n // 10 drops it (lecture 2-1)
Backwards: backwards * 10 + digit, last digit first
The loop never runs for 0 - how many digits does 0 have?
```

## Slide 31
Extra 1: one solution
`digits_loop.py`
```python
n = int(input("Number: "))
original = n
digits = 0
total = 0
backwards = 0
while n > 0:
    digit = n % 10
    digits += 1
    total += digit
    backwards = backwards * 10 + digit
    n = n // 10
if original == 0:
    digits = 1
print(f"Digits: {digits}")
print(f"Sum: {total}")
print(f"Backwards: {backwards}")
print(f"Palindrome: {original == backwards}")
```
```python
Four accumulators, one loop
Keep the original: n is destroyed by the loop, so a copy is kept for the palindrome test
Peel and push: % 10 takes the last digit, // 10 drops it, * 10 + digit builds the mirror image
The zero guard: the loop never runs for 0, so digits would stay 0; one if fixes the count
10 backwards is 1: the leading zero cannot be stored in a number - correct, and worth saying
```
`python digits_loop.py`
```python
Number: 12321
Digits: 5
Sum: 9
Backwards: 12321
Palindrome: True
```

## Slide 32
Extra 1: the run
`digits_loop.py`
```python
n = int(input("Number: "))
original = n
digits = 0
total = 0
backwards = 0
while n > 0:
    digit = n % 10
    digits += 1
    total += digit
    backwards = backwards * 10 + digit
    n = n // 10
if original == 0:
    digits = 1
print(f"Digits: {digits}")
print(f"Sum: {total}")
print(f"Backwards: {backwards}")
print(f"Palindrome: {original == backwards}")
```
`python digits_loop.py`
```python
Number: 4913
Digits: 4
Sum: 17
Backwards: 3194
Palindrome: False
```

## Slide 33
Recitation summary
Warm-up
Conditions
while
Nested loops
Sentinel
Extra
Wrap-up
What we practised
Order in an elif chain
Most specific first, or make every test exclusive.
Guard before you compute
Test a, test d, then take the root - never the other way round.
while True and break
Exit from the middle, where the answer is known.
Seed, then stream
Read the first value before the loop; the last line of the body reads the next.
Tools we used
Booleans
the six comparisons, and, or, not, chained comparisons, bool()
Conditions
if, elif, else, nested if, the conditional expression, guards
Loops
while, +=, break, while True, a loop inside a loop, end=""
Patterns
accumulator, running minimum and maximum, sentinel, a trace table

## Slide 34
Self practice
AT HOME
Write a program for each of these.
A diamond
Read n and print a diamond of stars with 2n - 1 rows: 1 star, then 3, ..., 2n - 1, then back down. Two while loops and abs() do it.
Fizz and buzz
Print the numbers 1 to 50 with a while loop, but replace multiples of 3 by Fizz, multiples of 5 by Buzz, and multiples of both by FizzBuzz.
Doubling time
Read an amount and a yearly interest rate in percent. How many years until the amount has doubled? A loop that grows the amount until it passes the target.
Leap years
Read two years and print every leap year between them, one per line, with the boolean of lecture 1-2 inside a while loop. Count them too.

## Slide 35
PYTHON COURSE · WEEK 3 · RECITATION 3
Next: for loops, binary and strings
range, numeral systems, indexing, slicing, and methods

## From `checkerboard.py`

### `checkerboard.py`
```python
n = int(input("n: "))

i = 0
while i < n:
    j = 0
    while j < n:
        if (i + j) % 2 == 0:
            print("#", end="")
        else:
            print(".", end="")
        j += 1
    print()
    i += 1
```

## From `collatz.py`

### `collatz.py`
```python
n = int(input("n: "))

steps = 0
while n != 1:
    print(n, end=" ")
    if n % 2 == 0:
        n = n // 2
    else:
        n = 3 * n + 1
    steps += 1
print(n)
print(f"{steps} steps")
```

## From `computer_guesses.py`

### `computer_guesses.py`
```python
low = 1
high = 100
rounds = 0
while True:
    guess = (low + high) // 2
    rounds += 1
    answer = input(f"Is it {guess}? (h/l/c) ")
    if answer == "c":
        print(f"Got it in {rounds} rounds")
        break
    elif answer == "h":
        low = guess + 1
    else:
        high = guess - 1
```

## From `digits_loop.py`

### `digits_loop.py`
```python
n = int(input("Number: "))
original = n
digits = 0
total = 0
backwards = 0
while n > 0:
    digit = n % 10
    digits += 1
    total += digit
    backwards = backwards * 10 + digit
    n = n // 10
if original == 0:
    digits = 1
print(f"Digits: {digits}")
print(f"Sum: {total}")
print(f"Backwards: {backwards}")
print(f"Palindrome: {original == backwards}")
```

## From `from_base.py`

### `from_base.py`
```python
text = input("digits: ")
base = int(input("base: "))

value = 0
valid = True
for ch in text:
    digit = int(ch)
    if digit >= base:
        valid = False
        break
    value = value * base + digit
if valid:
    print(value)
else:
    print("not a valid number in that base")
```

## From `guess.py`

### `guess.py`
```python
import random
secret = int(random.random() * 100) + 1
tries = 0
while True:
    guess = int(input("Guess: "))
    if guess < 1 or guess > 100:
        print("Between 1 and 100, please")
    else:
        tries += 1
        if guess < secret:
            print("Higher")
        elif guess > secret:
            print("Lower")
        else:
            print(f"Correct in {tries} tries")
            break
```

## From `hollow_square.py`

### `hollow_square.py`
```python
n = int(input("n: "))

i = 0
while i < n:
    j = 0
    while j < n:
        on_row = i == 0 or i == n - 1
        on_col = j == 0 or j == n - 1
        if on_row or on_col:
            print("*", end="")
        else:
            print(" ", end="")
        j += 1
    print()
    i += 1
```

## From `longest_chain.py`

### `longest_chain.py`
```python
best_start = 1
best_steps = 0
for start in range(1, 100):
    n = start
    steps = 0
    while n != 1:
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
        steps += 1
    if steps > best_steps:
        best_steps = steps
        best_start = start
print(f"{best_start} takes {best_steps} steps")
```

## From `monte_carlo_pi.py`

### `monte_carlo_pi.py`
```python
import random
import math

for n in [100, 1000, 10000, 100000]:
    hits = 0
    for i in range(n):
        x = 2 * random.random() - 1
        y = 2 * random.random() - 1
        if x * x + y * y <= 1:
            hits += 1
    estimate = 4 * hits / n
    print(f"N = {n}: {round(estimate, 4)}")
print(f"math.pi: {round(math.pi, 4)}")
```

## From `quadratic.py`

### `quadratic.py`
```python
import math
a = float(input("a: "))
b = float(input("b: "))
c = float(input("c: "))
if a == 0:
    if b == 0:
        print("Not an equation")
    else:
        print(f"One root: {round(-c / b, 2)}")
else:
    d = b * b - 4 * a * c
    if d < 0:
        print("No real roots")
    elif d == 0:
        print(f"One root: {round(-b / (2 * a), 2)}")
    else:
        root = math.sqrt(d)
        print(f"x1 = {round((-b + root) / (2 * a), 2)}")
        print(f"x2 = {round((-b - root) / (2 * a), 2)}")
```

## From `sevens.py`

### `sevens.py`
```python
import random

N = 10000
sevens = 0
for i in range(N):
    first = int(random.random() * 6) + 1
    second = int(random.random() * 6) + 1
    if first + second == 7:
        sevens += 1

print(f"Sevens: {sevens} of {N}")
print(f"Share: {round(sevens / N, 3)}")
print(f"Expected: {round(1 / 6, 3)}")
```

## From `stats.py`

### `stats.py`
```python
END = -1

x = int(input("Number (-1 to finish): "))
count = 0
total = 0
smallest = x
largest = x

while x != END:
    count += 1
    total += x
    if x < smallest:
        smallest = x
    if x > largest:
        largest = x
    x = int(input("Number (-1 to finish): "))

if count == 0:
    print("No numbers were entered.")
else:
    print(f"Count: {count}")
    print(f"Sum: {total}")
    print(f"Average: {round(total / count, 2)}")
    print(f"Smallest: {smallest}")
    print(f"Largest: {largest}")
```

## From `stats_text.py`

### `stats_text.py`
```python
text = input("Number (done to finish): ")
count = 0
total = 0

while text != "done":
    x = int(text)
    count += 1
    total += x
    text = input("Number (done to finish): ")

if count == 0:
    print("No numbers were entered.")
else:
    print(f"Count: {count}")
    print(f"Average: {round(total / count, 2)}")
```

## From `ticket.py`

### `ticket.py`
```python
age = int(input("Age: "))

if age < 5:
    price = 0
elif age < 18:
    price = 20
elif age < 65:
    price = 40
else:
    price = 25

msg = f"Price: {price}"
print("Free" if price == 0 else msg)
```

## From `ticket_alice.py`

### `ticket_alice.py`
```python
age = int(input("Age: "))

if age < 65:
    price = 40
elif age < 18:
    price = 20
elif age < 5:
    price = 0
else:
    price = 25

msg = f"Price: {price}"
print("Free" if price == 0 else msg)
```

## From `to_base.py`

### `to_base.py`
```python
n = int(input("n: "))
base = int(input("base: "))

digits = ""
if n == 0:
    digits = "0"
while n > 0:
    digits = str(n % base) + digits
    n = n // base
print(digits)
```

## From `warmup_booleans.py`

### `warmup_booleans.py`
```python
x = 7
print(x > 5 and x < 10)
print(not x == 7)
print(x % 2 == 0 or x % 3 == 0)
print(5 <= x <= 7)
print(x == 7.0, x == "7")
print(0.1 + 0.2 == 0.3)
print(abs(0.1 + 0.2 - 0.3) < 1e-9)
print(type(x > 5))
```

## From `warmup_loops_1.py`

### `warmup_loops_1.py`
```python
# A
i = 0
while i < 5:
    print(i)
    i += 1

# B
i = 0
while i <= 5:
    print(i)
    i += 1
```

## From `warmup_loops_2.py`

### `warmup_loops_2.py`
```python
# C
i = 0
while i < 5:
    print(i)
i += 1

# D
i = 1
total = 0
while i < 4:
    total = 0
    total += i
    i += 1
print(total)
```

## From `warmup_range.py`

### `warmup_range.py`
```python
for i in range(2, 11, 3):
    print(i, end=" ")
print()
for i in range(5, 0, -2):
    print(i, end=" ")
print()
for ch in "abc":
    print(ch * 2, end=" ")
print()
for i in range(3, 3):
    print("never")
print("done")
```


---

# Recitation, week 3: Strings and approximation

## From `recitation 3.pptx`

## Slide 1
```python
s[::-1]
```
PYTHON COURSE · WEEK 3 · RECITATION 3
Recitation 3
for loops and strings

## Slide 2
Recitation overview
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
1
Predictions
range, slicing, and the immutability trap
2
Text tools
a username, run-length encoding, a password check
3
Monte Carlo
darts and pi: throw, test, count
4
Ciphers
Vigenere, built on Caesar

## Slide 3
Warm-up: range
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
WARM-UP · 2 MIN
Four loops with for. Write the four lines they print.
`warmup_range.py`
```python
for i in range(2, 11, 3):
    print(i, end=" ")
print()
for i in range(5, 0, -2):
    print(i, end=" ")
print()
for ch in "abc":
    print(ch * 2, end=" ")
print()
for i in range(3, 3):
    print("never")
print("done")
```
```python
The answers
2 5 8
5 3 1
aa bb cc
done (the empty range runs 0 times)
```

## Slide 4
Warm-up: slicing
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
WARM-UP · 4 MIN
One string, eight lines. Write the output of each before we run it.
`warmup_slicing.py`
```python
s = "recitation"
print(s[0], s[-1])
print(s[2:5])
print(s[:3] + s[3:])
print(s[::-1])
print(s[::3])
print(len(s), s[len(s) - 1])
print("cit" in s, "tac" in s)
print(s[10])
```
```python
The answers
r n
cit
recitation
noitaticer
ritn
10 n
True False
IndexError - one past the end
```

## Slide 5
Warm-up: methods and the trap
WARM-UP · 4 MIN
Methods return a new string. Which line forgets that?
`warmup_methods.py`
```python
s = "  Hello, World  "
print(s.strip())
print(s.lower().count("l"))
print(s.find("World"))
print(s.replace("l", "L"))
t = s.strip()
t.upper()
print(t)
print("Zebra" < "apple", "a" < "b")
print(s.isalpha(), "abc".isalpha())
```
```python
The answers
Hello, World
3
9
  HeLLo, WorLd  
Hello, World  (the trap)
True True
False True
```

## Slide 6
Exercise 1: Username and e-mail
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
EASY · 7 MIN ON YOUR OWN
Task: read a full name, 'First Last', and build the university username and e-mail.
The username is the first letter of the first name plus the whole last name, in lowercase
The e-mail is the username followed by @runi.ac.il; the initials are 'D.G.'
Extra spaces at the ends of the input must not matter
```python
terminal
```
```python
Full name:   David German 
Username: dgerman
E-mail: dgerman@runi.ac.il
Initials: D.G.
```
```python
Think about
.find(" ") locates the space; slices take the two halves
.strip() first, .lower() and .upper() where needed
```

## Slide 7
Exercise 1: one solution
`username.py`
```python
full = input("Full name: ").strip()

space = full.find(" ")
first = full[:space]
last = full[space + 1:]

username = (first[0] + last).lower()
print(f"Username: {username}")
print(f"E-mail: {username}@runi.ac.il")
print(f"Initials: {first[0]}.{last[0]}.")
```
```python
Find the seam, cut, assemble
strip() first: the input promise is kept before anything else looks at the text
The seam: find(" ") gives the position of the space; [:space] and [space + 1:] are the halves
Build, then lower: parentheses, so .lower() applies to the whole username
Initials: first[0] and last[0] are strings of length 1, joined with dots in an f-string
```

## Slide 8
Exercise 1: the run
`username.py`
```python
full = input("Full name: ").strip()

space = full.find(" ")
first = full[:space]
last = full[space + 1:]

username = (first[0] + last).lower()
print(f"Username: {username}")
print(f"E-mail: {username}@runi.ac.il")
print(f"Initials: {first[0]}.{last[0]}.")
```
`python username.py`
```python
Full name:   David German 
Username: dgerman
E-mail: dgerman@runi.ac.il
Initials: D.G.
```

## Slide 9
Exercise 2: Run-length encoding
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: compress a string by replacing every run of equal characters with the character and its length.
```python
aaabbc becomes a3b2c1; xyz becomes x1y1z1; an empty string stays empty
Then decode: a3b2c1 becomes aaabbc again (counts are single digits)
Walk the positions, not the characters: a run ends where s[i] differs from s[i - 1]
```
```python
terminal
```
```python
Text: aaabbc
Encoded: a3b2c1

Code: a3b2c1
Decoded: aaabbc
```
```python
Think about
Encoding: a counter for the current run, and a result string that grows
Decoding: positions 0, 2, 4, ... hold characters; 1, 3, 5, ... hold counts: range(0, len(code), 2)
```

## Slide 10
The idea: a run ends at a change
aaabbc has three runs. Count a run until the next character differs, then write it down.
```python
1 · Start - the first character opens a run: current = s[0], count = 1
2 · Compare - for each position from 1: same as current? count it. Different? write current and count, start a new run
3 · Finish - after the loop, the last run is still open: write it too
4 · Edge - the empty string has no s[0]: handle it before the loop
```
In pseudocode
result = empty; if s is empty, stop
current = s[0], count = 1
for i from 1 to the end:
      same as current? count += 1
      else: write current and count,
                current = s[i], count = 1
write the last run

## Slide 11
Exercise 2: encoding
`rle_encode.py`
```python
s = input("Text: ")

result = ""
if len(s) > 0:
    current = s[0]
    count = 1
    for i in range(1, len(s)):
        if s[i] == current:
            count += 1
        else:
            result += current + str(count)
            current = s[i]
            count = 1
    result += current + str(count)
print(f"Encoded: {result}")
```
```python
Reading the loop
Positions from 1: s[i] is compared with the run that is open, not with s[i - 1] - same thing, one variable
Two accumulators: result grows a piece at a time; count restarts at 1 whenever a run closes
The last line of the if-block: the last run is written after the loop, always
str(count): a number cannot be joined to a string without it
```

## Slide 12
Exercise 2: the run
`rle_encode.py`
```python
s = input("Text: ")

result = ""
if len(s) > 0:
    current = s[0]
    count = 1
    for i in range(1, len(s)):
        if s[i] == current:
            count += 1
        else:
            result += current + str(count)
            current = s[i]
            count = 1
    result += current + str(count)
print(f"Encoded: {result}")
```
`python rle_encode.py`
```python
Text: aaabbc
Encoded: a3b2c1
```

## Slide 13
Exercise 2: decoding
`rle_decode.py`
```python
code = input("Code: ")

text = ""
for i in range(0, len(code), 2):
    ch = code[i]
    count = int(code[i + 1])
    text += ch * count
print(f"Decoded: {text}")
```
```python
Two positions at a time
range(0, len(code), 2): the step visits 0, 2, 4, ... - the character positions
The count is the next position: code[i + 1], turned into a number with int()
The * operator from week 1: "a" * 3 is aaa
A promise: counts have one digit; a4b12 would need the digits gathered until a letter appears
```
`python rle_decode.py`
```python
Code: a3b2c1
Decoded: aaabbc
```

## Slide 14
Exercise 3: Strong password
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: read a password and check it against five rules. Print every rule it breaks, or 'Strong'.
```python
At least 8 characters; at least one digit; at least one uppercase and one lowercase letter; no spaces
One pass over the characters with isdigit(), isupper(), islower() and flags
Then: the password must not contain the username (one more line, with in)
```
```python
terminal
```
```python
Password: pw 7
too short
no uppercase letter
contains a space

Password: Reichman2026
Strong
```
Think about
A flag per rule: False at first, True once the loop sees the evidence
Decide after the loop: it discovers, the code after it acts

## Slide 15
Exercise 3: the loop (1 of 2)
```python
password.py (lines 1-12)
```
```python
password = input("Password: ")

has_digit = False
has_upper = False
has_lower = False
for ch in password:
    if ch.isdigit():
        has_digit = True
    if ch.isupper():
        has_upper = True
    if ch.islower():
        has_lower = True
```
```python
Discover
Three flags, one loop: each character can switch a flag on; nothing ever switches one off
Independent ifs, not elif: three separate questions about the same character
Flags start False before the loop - inside it they would be reset on every pass
Length and the space need no loop: len() and in answer them in one call each
```

## Slide 16
Exercise 3: the report (2 of 2)
```python
password.py (lines 14-28)
```
```python
problems = ""
if len(password) < 8:
    problems += "too short\n"
if not has_digit:
    problems += "no digit\n"
if not has_upper:
    problems += "no uppercase letter\n"
if not has_lower:
    problems += "no lowercase letter\n"
if " " in password:
    problems += "contains a space\n"

if problems == "":
    print("Strong")
else:
    print(problems, end="")
```
```python
Act
Five independent ifs: a password can break several rules at once, and every broken rule is reported
A string accumulator: problems collects one line per rule, each ending in \n
The empty string means strong: nothing was added, so nothing was wrong
print(problems, end=""): the newlines are already in the text
```

## Slide 17
Exercise 3: the run
```python
password.py (lines 14-28)
```
```python
problems = ""
if len(password) < 8:
    problems += "too short\n"
if not has_digit:
    problems += "no digit\n"
if not has_upper:
    problems += "no uppercase letter\n"
if not has_lower:
    problems += "no lowercase letter\n"
if " " in password:
    problems += "contains a space\n"

if problems == "":
    print("Strong")
else:
    print(problems, end="")
```
```python
python password.py (lines 14-28)
```
```python
Password: pw 7
too short
no uppercase letter
contains a space
```

## Slide 18
continue: when to reach for it
```python
The password loop had no continue. Where would one help?
A loop that skips - continue jumps to the next pass; the rest of the body is skipped
Clearer than if-else - several reasons to skip before a long body
Not clearer - a plain if around two lines does the same job
break is different - it leaves the loop for good; continue leaves one pass
```
Try it:
rewrite the vowel-removal loop from lecture 3-1 with continue, and decide which version reads better.

## Slide 19
Exercise 4: Darts and pi
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: throw N random points into the square [-1, 1) x [-1, 1). Count how many land inside the unit circle.
The circle covers pi/4 of the square, so 4 * inside / N is an estimate of pi
Print the estimate for N = 100, 1000, 10000 and 100000 and compare with math.pi
Lecture 2-1's random point in the circle is one dart; now throw N of them
```python
terminal
```
```python
N = 100: 3.24
N = 1000: 3.152
N = 10000: 3.1384
N = 100000: 3.1416
math.pi: 3.1416
```
```python
Think about
A point (x, y) is inside the circle when x * x + y * y <= 1
for n in [100, 1000, 10000, 100000]: walks the four sizes
The accumulator: count the hits
```

## Slide 20
The idea: area as probability
A random point in the square lands inside the circle with probability pi / 4. Count how often it does.
```python
1 · Throw - x = 2 * random.random() - 1, the same for y
2 · Test - inside when x * x + y * y <= 1
3 · Count - hits += 1 for every point inside
4 · Estimate - hits / n is about pi / 4, so pi is about 4 * hits / n
5 · Repeat - more darts, better estimate; the error shrinks slowly
```
In pseudocode
for each size n:
      hits = 0
      repeat n times:
            throw a random point
            if it is inside: hits += 1
      print 4 * hits / n

## Slide 21
Exercise 4: one solution
`monte_carlo_pi.py`
```python
import random
import math

for n in [100, 1000, 10000, 100000]:
    hits = 0
    for i in range(n):
        x = 2 * random.random() - 1
        y = 2 * random.random() - 1
        if x * x + y * y <= 1:
            hits += 1
    estimate = 4 * hits / n
    print(f"N = {n}: {round(estimate, 4)}")
print(f"math.pi: {round(math.pi, 4)}")
```
```python
Reading the program
Two loops: the outer picks a size, the inner throws that many darts
Reset per size: hits = 0 sits inside the outer loop
A fresh point per dart: both random calls are inside the inner loop
The estimate uses /: a float, printed rounded to 4 digits
```

## Slide 22
Exercise 4: the run
`monte_carlo_pi.py`
```python
import random
import math

for n in [100, 1000, 10000, 100000]:
    hits = 0
    for i in range(n):
        x = 2 * random.random() - 1
        y = 2 * random.random() - 1
        if x * x + y * y <= 1:
            hits += 1
    estimate = 4 * hits / n
    print(f"N = {n}: {round(estimate, 4)}")
print(f"math.pi: {round(math.pi, 4)}")
```
```python
python monte_carlo_pi.py (one run)
```
```python
N = 100: 3.24
N = 1000: 3.152
N = 10000: 3.1384
N = 100000: 3.1416
math.pi: 3.1416
```

## Slide 23
Exercise 4, expansion: how often is it 7?
`sevens.py`
```python
import random

N = 10000
sevens = 0
for i in range(N):
    first = int(random.random() * 6) + 1
    second = int(random.random() * 6) + 1
    if first + second == 7:
        sevens += 1

print(f"Sevens: {sevens} of {N}")
print(f"Share: {round(sevens / N, 3)}")
print(f"Expected: {round(1 / 6, 3)}")
```
Recitation 1's question, answered
Two dice, ten thousand times: the same three-part shape - throw, test, count
Expected: 6 of the 36 combinations add up to 7, so about one roll in six
Your turn: count how often the two dice are equal, and how often the total is 2
```python
python sevens.py (one run)
```
```python
Sevens: 1687 of 10000
Share: 0.169
Expected: 0.167
```

## Slide 24
Exercise 5: The Vigenere cipher
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
HIGH · 12 MIN ON YOUR OWN
Task: Caesar with a key word. Each letter is shifted by its own key letter, and the key repeats.
Key lemon: shifts 11, 4, 12, 14, 13 - the alphabet positions of l, e, m, o, n
attack at dawn with key lemon becomes lxfopv ef rnhr
Only lowercase letters are shifted and use a key letter; the rest is copied
```python
terminal
```
```python
Message: attack at dawn
Key: lemon
lxfopv ef rnhr
```
```python
Think about
Start from the lecture's caesar.py: the shift is now ord(key[j]) - ord("a")
j counts the key letter used so far; it wraps with % len(key) and advances only on letters
```

## Slide 25
Exercise 5: one solution
`vigenere.py`
```python
text = input("Message: ")
key = input("Key: ")

result = ""
j = 0
for ch in text:
    if ch.islower():
        shift = ord(key[j]) - ord("a")
        position = ord(ch) - ord("a")
        position = (position + shift) % 26
        result += chr(position + ord("a"))
        j = (j + 1) % len(key)
    else:
        result += ch
print(result)
```
```python
Caesar, with a moving shift
The shift: ord(key[j]) - ord("a") is the position of the key letter, 0 to 25
The same four lines as Caesar: position, add, wrap with % 26, back to a letter
j: advances only inside the if, so spaces do not consume key letters; % len(key) wraps it
Decryption: subtract the shift instead - (position - shift) % 26 - and the message comes back
```

## Slide 26
Exercise 5: the run
`vigenere.py`
```python
text = input("Message: ")
key = input("Key: ")

result = ""
j = 0
for ch in text:
    if ch.islower():
        shift = ord(key[j]) - ord("a")
        position = ord(ch) - ord("a")
        position = (position + shift) % 26
        result += chr(position + ord("a"))
        j = (j + 1) % len(key)
    else:
        result += ch
print(result)
```
`python vigenere.py`
```python
Message: attack at dawn
Key: lemon
lxfopv ef rnhr
```

## Slide 27
Exercise 5, expansion: both directions
`vigenere_both.py`
```python
text = input("Message: ")
key = input("Key: ")
mode = input("e to encrypt, d to decrypt: ")
sign = -1 if mode == "d" else 1
result = ""
j = 0
for ch in text:
    if ch.islower():
        shift = ord(key[j]) - ord("a")
        pos = ord(ch) - ord("a")
        pos = (pos + sign * shift) % 26
        result += chr(pos + ord("a"))
        j = (j + 1) % len(key)
    else:
        result += ch
print(result)
```
```python
One program, two directions
A mode and a sign: the conditional expression turns d into -1 and anything else into 1
Negative shifts are safe: % 26 always lands in 0 to 25, as with Caesar's shift -3
Round trip: decrypt lxfopv ef rnhr with lemon, and attack at dawn comes back
```

## Slide 28
Extra 1: Any base
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
EXTRA
Task: generalise the two binary conversions of lecture 2-2 to any base from 2 to 10.
to_base: read a number n >= 0 and a base; print n written in that base (26 in base 3 is 222)
from_base: read a string of digits and a base; print its value (222 in base 3 is 26)
Handle n = 0, and stop with a message if a digit is too big for the base
```python
terminal
```
```python
n: 26
base: 3
222

digits: 222
base: 3
26
```
```python
Think about
In base 2 the loop used % 2 and // 2. What do they become?
Reading back: value = value * base + int(ch) for each character
```

## Slide 29
Extra 1: to any base
`to_base.py`
```python
n = int(input("n: "))
base = int(input("base: "))

digits = ""
if n == 0:
    digits = "0"
while n > 0:
    digits = str(n % base) + digits
    n = n // base
print(digits)
```
```python
Nothing depended on 2
% base peels off the last digit, // base drops it
Last digit first: each new digit is put in front of the ones found so far
Zero: the loop never runs, so the if before it supplies the single digit 0
Sanity check: base 10 must print the number unchanged
```

## Slide 30
Extra 1: the run
`to_base.py`
```python
n = int(input("n: "))
base = int(input("base: "))

digits = ""
if n == 0:
    digits = "0"
while n > 0:
    digits = str(n % base) + digits
    n = n // base
print(digits)
```
`python to_base.py`
```python
n: 26
base: 3
222
```

## Slide 31
Extra 1: from any base
`from_base.py`
```python
text = input("digits: ")
base = int(input("base: "))

value = 0
valid = True
for ch in text:
    digit = int(ch)
    if digit >= base:
        valid = False
        break
    value = value * base + digit
if valid:
    print(value)
else:
    print("not a valid number in that base")
```
```python
Horner, with a guard
Left to right: value * base + digit - everything so far is worth base times more, plus this digit
The guard: a digit that is too big for the base makes the number invalid
Flag and break: the loop discovers, the code after the loop acts (lecture 2-2)
A letter still crashes int(ch) - lecture 3-1's `isdigit()` is the guard to add
```

## Slide 32
Extra 1: the run
`from_base.py`
```python
text = input("digits: ")
base = int(input("base: "))

value = 0
valid = True
for ch in text:
    digit = int(ch)
    if digit >= base:
        valid = False
        break
    value = value * base + digit
if valid:
    print(value)
else:
    print("not a valid number in that base")
```
`python from_base.py`
```python
digits: 222
base: 3
26
```

## Slide 33
Extra 2: The clean palindrome
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
EXTRA
Task: is a sentence a palindrome if case, spaces and punctuation are ignored?
```python
'Rise to vote, sir' and 'A man, a plan, a canal: Panama' both count
Build a cleaned copy with only the letters, in lowercase; then one comparison
Only letters: isalpha() decides, character by character
```
```python
terminal
```
```python
Sentence: Rise to vote, sir
Cleaned: risetovotesir
Palindrome: True
```
```python
Think about
The accumulator for strings: cleaned += ch
word == word[::-1] is the whole test (lecture 3-1)
```

## Slide 34
Extra 2: one solution
`clean_palindrome.py`
```python
sentence = input("Sentence: ")

cleaned = ""
for ch in sentence.lower():
    if ch.isalpha():
        cleaned += ch

print(f"Cleaned: {cleaned}")
print(f"Palindrome: {cleaned == cleaned[::-1]}")
```
```python
Filter, then test
Lowercase once: the loop walks sentence.lower(), a new string
The filter: isalpha() keeps letters only; digits and punctuation never reach cleaned
The test: cleaned == cleaned[::-1], evaluated inside the f-string
Try: 'Was it a car or a cat I saw?' and your own name
```
`python clean_palindrome.py`
```python
Sentence: Rise to vote, sir
Cleaned: risetovotesir
Palindrome: True
```

## Slide 35
Recitation summary
Warm-up
Text tools
Passwords
Monte Carlo
Ciphers
Extra
Wrap-up
What we practised
Start in, stop out
range(start, stop, step) - and a loop that runs zero times is not an error.
Throw, test, count
Two loops, a counter reset per size: the share of hits estimates a probability.
Find the seam, cut, assemble
find() gives a position; slices take the pieces; + and f-strings rebuild.
Discover, then act
Flags are set inside the loop and read after it; loops over positions when a character must meet its neighbour.
Tools we used
Loops
for, range(start, stop, step), for ch in s, nested for, end=""
Strings
len, s[i], s[a:b:c], in, ==, ord, chr, +=, * and the empty string
Methods
strip, lower, upper, find, replace, count, isalpha, isdigit, isupper, islower
Patterns
accumulator, flags, index loops with a step, continue, % and // peel digits off

## Slide 36
Self practice
AT HOME
Write a program for each of these.
Count the doubles
Count how many times a letter is immediately followed by the same letter: 'bookkeeper' has three.
The middle
Print the middle character of a word, or the middle two if its length is even. Test with lengths 1 to 4.
Title case by hand
Capitalise the first letter of every word in a sentence without using title() or split(): the character after a space is a word start.
The longest chain
Which start below 100 takes the most steps to reach 1 in the 3n + 1 game of recitation 2? A while inside a for, and a running maximum that remembers the start.

## Slide 37
PYTHON COURSE · WEEK 4 · RECITATION 4
Next: Approximation and functions
bisection, Newton, def, return, and modules

## From `clean_palindrome.py`

### `clean_palindrome.py`
```python
sentence = input("Sentence: ")

cleaned = ""
for ch in sentence.lower():
    if ch.isalpha():
        cleaned += ch

print(f"Cleaned: {cleaned}")
print(f"Palindrome: {cleaned == cleaned[::-1]}")
```

## From `cube_root.py`

### `cube_root.py`
```python
x = float(input("x: "))
epsilon = 0.000001
low = 0.0
high = 1.0 if x < 1 else x
guess = (low + high) / 2
steps = 0
while abs(guess ** 3 - x) >= epsilon:
    if guess ** 3 < x:
        low = guess
    else:
        high = guess
    guess = (low + high) / 2
    steps += 1
root = round(guess, 6)
print(f"cube root: {root} in {steps} steps")
```

## From `fixed_point.py`

### `fixed_point.py`
```python
import math
epsilon = 0.000001
low = 0.0
high = 1.0
guess = (low + high) / 2
steps = 0
while abs(math.cos(guess) - guess) >= epsilon:
    if math.cos(guess) - guess > 0:
        low = guess
    else:
        high = guess
    guess = (low + high) / 2
    steps += 1
answer = round(guess, 6)
print(f"cos(x) = x: {answer} in {steps} steps")
```

## From `from_base.py`

### `from_base.py`
```python
text = input("digits: ")
base = int(input("base: "))

value = 0
valid = True
for ch in text:
    digit = int(ch)
    if digit >= base:
        valid = False
        break
    value = value * base + digit
if valid:
    print(value)
else:
    print("not a valid number in that base")
```

## From `monte_carlo_pi.py`

### `monte_carlo_pi.py`
```python
import random
import math

for n in [100, 1000, 10000, 100000]:
    hits = 0
    for i in range(n):
        x = 2 * random.random() - 1
        y = 2 * random.random() - 1
        if x * x + y * y <= 1:
            hits += 1
    estimate = 4 * hits / n
    print(f"N = {n}: {round(estimate, 4)}")
print(f"math.pi: {round(math.pi, 4)}")
```

## From `password.py`

### `password.py`
```python
password = input("Password: ")

has_digit = False
has_upper = False
has_lower = False
for ch in password:
    if ch.isdigit():
        has_digit = True
    if ch.isupper():
        has_upper = True
    if ch.islower():
        has_lower = True

problems = ""
if len(password) < 8:
    problems += "too short\n"
if not has_digit:
    problems += "no digit\n"
if not has_upper:
    problems += "no uppercase letter\n"
if not has_lower:
    problems += "no lowercase letter\n"
if " " in password:
    problems += "contains a space\n"

if problems == "":
    print("Strong")
else:
    print(problems, end="")
```

## From `rle_decode.py`

### `rle_decode.py`
```python
code = input("Code: ")

text = ""
for i in range(0, len(code), 2):
    ch = code[i]
    count = int(code[i + 1])
    text += ch * count
print(f"Decoded: {text}")
```

## From `rle_encode.py`

### `rle_encode.py`
```python
s = input("Text: ")

result = ""
if len(s) > 0:
    current = s[0]
    count = 1
    for i in range(1, len(s)):
        if s[i] == current:
            count += 1
        else:
            result += current + str(count)
            current = s[i]
            count = 1
    result += current + str(count)
print(f"Encoded: {result}")
```

## From `sevens.py`

### `sevens.py`
```python
import random

N = 10000
sevens = 0
for i in range(N):
    first = int(random.random() * 6) + 1
    second = int(random.random() * 6) + 1
    if first + second == 7:
        sevens += 1

print(f"Sevens: {sevens} of {N}")
print(f"Share: {round(sevens / N, 3)}")
print(f"Expected: {round(1 / 6, 3)}")
```

## From `to_base.py`

### `to_base.py`
```python
n = int(input("n: "))
base = int(input("base: "))

digits = ""
if n == 0:
    digits = "0"
while n > 0:
    digits = str(n % base) + digits
    n = n // base
print(digits)
```

## From `username.py`

### `username.py`
```python
full = input("Full name: ").strip()

space = full.find(" ")
first = full[:space]
last = full[space + 1:]

username = (first[0] + last).lower()
print(f"Username: {username}")
print(f"E-mail: {username}@runi.ac.il")
print(f"Initials: {first[0]}.{last[0]}.")
```

## From `vigenere.py`

### `vigenere.py`
```python
text = input("Message: ")
key = input("Key: ")

result = ""
j = 0
for ch in text:
    if ch.islower():
        shift = ord(key[j]) - ord("a")
        position = ord(ch) - ord("a")
        position = (position + shift) % 26
        result += chr(position + ord("a"))
        j = (j + 1) % len(key)
    else:
        result += ch
print(result)
```

## From `vigenere_both.py`

### `vigenere_both.py`
```python
text = input("Message: ")
key = input("Key: ")
mode = input("e to encrypt, d to decrypt: ")
sign = -1 if mode == "d" else 1
result = ""
j = 0
for ch in text:
    if ch.islower():
        shift = ord(key[j]) - ord("a")
        pos = ord(ch) - ord("a")
        pos = (pos + sign * shift) % 26
        result += chr(pos + ord("a"))
        j = (j + 1) % len(key)
    else:
        result += ch
print(result)
```

## From `warmup_methods.py`

### `warmup_methods.py`
```python
s = "  Hello, World  "
print(s.strip())
print(s.lower().count("l"))
print(s.find("World"))
print(s.replace("l", "L"))
t = s.strip()
t.upper()
print(t)
print("Zebra" < "apple", "a" < "b")
print(s.isalpha(), "abc".isalpha())
```

## From `warmup_range.py`

### `warmup_range.py`
```python
for i in range(2, 11, 3):
    print(i, end=" ")
print()
for i in range(5, 0, -2):
    print(i, end=" ")
print()
for ch in "abc":
    print(ch * 2, end=" ")
print()
for i in range(3, 3):
    print("never")
print("done")
```

## From `warmup_slicing.py`

### `warmup_slicing.py`
```python
s = "recitation"
print(s[0], s[-1])
print(s[2:5])
print(s[:3] + s[3:])
print(s[::-1])
print(s[::3])
print(len(s), s[len(s) - 1])
print("cit" in s, "tac" in s)
print(s[10])
```


---

# Recitation, week 4: Approximation and functions

## From `recitation 4.pptx`

## Slide 1
```python
def
```
PYTHON COURSE · WEEK 4 · RECITATION 4
Recitation 4
Approximation and functions

## Slide 2
Recitation overview
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
1
Predictions
None, local names, and three passes of bisection
2
Functions
small, named, tested in the REPL
3
Roots
lecture 3-2's loops, one function away
4
Design
a date, built top-down; Newton, with a trace

## Slide 3
Warm-up: functions
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
WARM-UP · 4 MIN
Four printed lines. Which call prints which, and what is b?
`warmup_functions.py`
```python
def double(x):
    return 2 * x
def shout(word):
    print(word.upper())

a = double(4)
b = shout("hi")
print(a, b)
print(double(double(3)))
x = 10
def change():
    x = 5
change()
print(x)
```
The answers
HI   (printed during the call to shout)
8 None
12
10

## Slide 4
Warm-up: bisection by hand
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
WARM-UP · 4 MIN
Lecture 3-2's bisection with x = 10. Fill in low, high and g after the first three passes.
`warmup_bisection.py`
```python
# Bisection (lecture 3-2), for x = 10
x = 10
epsilon = 0.01
low = 1.0
high = x
g = (low + high) / 2
steps = 0
while abs(g * g - x) >= epsilon:
    if g * g < x:
        low = g
    else:
        high = g
    g = (low + high) / 2
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```
```python
The answers
start   low 1.0  high 10.0  g 5.5
pass 1  5.5 too big   -> high 5.5   g 3.25
pass 2  3.25 too big  -> high 3.25  g 2.125
pass 3  2.125 too small -> low 2.125 g 2.6875
the run: 3.1621 in 8 steps
sequential search: about 21,600 steps
```

## Slide 5
Exercise 1: Three small functions
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
EASY · 8 MIN ON YOUR OWN
Task: three small functions, each with a docstring, tested in the REPL.
```python
is_leap(year): True for a leap year - lecture 1-2's rule, as a function
digit_sum(n): the sum of the digits of n - recitation 2's loop, as a function
count_vowels(text): how many of a, e, i, o, u the text contains, in either case
Save as small_functions.py; import and call in the REPL
```
```python
the REPL
```
```python
>>> import small_functions as sf
>>> sf.is_leap(1900)
False
>>> sf.digit_sum(4913)
17
>>> sf.count_vowels("Reichman")
3
```
```python
Think about
return a value; never print inside these functions
A comparison is already a value: return it
The accumulator pattern: count in a loop, return after the loop
```

## Slide 6
Exercise 1: one solution
`small_functions.py`
```python
def is_leap(year):
    """Return True when year is a leap year."""
    by_400 = year % 400 == 0
    by_4 = year % 4 == 0 and year % 100 != 0
    return by_400 or by_4


def digit_sum(n):
    """Return the sum of the digits of n (n >= 0)."""
    total = 0
    while n > 0:
        total += n % 10
        n = n // 10
    return total


def count_vowels(text):
    """Return how many vowels text contains."""
    count = 0
    for ch in text.lower():
        if ch in "aeiou":
            count += 1
    return count
```
```python
Three shapes of function
A one-liner: the boolean is the value, so return the comparison itself
A loop that empties its input: n is a local name; the caller's number is untouched
An accumulator: count in a loop, return after the loop; return inside the loop would stop at the first vowel
Docstrings: the first line of the body, in triple quotes, says what comes back; help(sf.digit_sum) reads it
```
```python
the REPL
```
```python
>>> sf.is_leap(2000)
True
>>> sf.digit_sum(0)
0
>>> sf.count_vowels("xyz")
0
```

## Slide 7
Exercise 2: Roots, as functions
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: lecture 3-2 found a square root by bisection. Change the function, keep the loop, give it a name.
```python
cube_root(x, epsilon=1e-6): bracket 0 to x if x >= 1, else 0 to 1; stop when |g³ - x| < epsilon; return g
solve_cos(epsilon=1e-6): the g in [0, 1] with cos(g) = g; math.cos is the only new tool
Both in roots.py; call each with the default and with a keyword argument
```
```python
the REPL
```
```python
>>> import roots
>>> roots.cube_root(27)
3.000000022351742
>>> roots.cube_root(2, epsilon=0.1)
1.25
>>> roots.solve_cos()
0.7390851974487305
```
```python
Think about
Which half still contains the answer? For cos(g) - g: positive means the answer is to the right
epsilon as a parameter with a default, as in lecture 4-1's my_sqrt
No print, no input: the caller decides what to show
```

## Slide 8
Exercise 2: the cube root
```python
roots.py (part 1)
```
```python
"""Roots by approximation, as functions."""
import math


def cube_root(x, epsilon=1e-6):
    """Return the cube root of x >= 0, by bisection."""
    low = 0.0
    high = 1.0 if x < 1 else x
    g = (low + high) / 2
    while abs(g ** 3 - x) >= epsilon:
        if g ** 3 < x:
            low = g
        else:
            high = g
        g = (low + high) / 2
    return g
```
```python
The lecture's loop, one function away
The function: g ** 3 - x in the condition and in the update, where the lecture had g * g - x
The bracket: a conditional expression picks 0 to x or 0 to 1 - the answer must be inside from the start
epsilon has a default: cube_root(27) uses 1e-6; cube_root(2, epsilon=0.1) is deliberately sloppy
```
```python
the REPL
```
```python
>>> import roots
>>> roots.cube_root(27)
3.000000022351742
>>> roots.cube_root(2, epsilon=0.1)
1.25
```

## Slide 9
Exercise 2: cos(x) = x
```python
roots.py (part 2)
```
```python
def solve_cos(epsilon=1e-6):
    """Return the g in [0, 1] with cos(g) = g."""
    low = 0.0
    high = 1.0
    g = (low + high) / 2
    while abs(math.cos(g) - g) >= epsilon:
        if math.cos(g) - g > 0:
            low = g
        else:
            high = g
        g = (low + high) / 2
    return g
```
```python
An equation with no formula
The function: math.cos(g) - g is zero exactly where cos(x) = x
The sign decides: positive at 0, negative at 1, so a positive midpoint means the answer is to the right
No x: the equation is fixed, so epsilon is the only parameter - and it has a default
Keyword arguments: solve_cos(epsilon=0.01) says what the 0.01 is; solve_cos(0.01) works too
```
```python
the REPL
```
```python
>>> roots.solve_cos()
0.7390851974487305
>>> roots.solve_cos(epsilon=0.01)
0.734375
>>> round(roots.solve_cos(), 4)
0.7391
```

## Slide 10
Exercise 3: Design before code
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: read a day, a month and a year. Is it a real date? If it is, which day of the year is it?
First the design: name the functions, give each a signature and a docstring
Then stubs, so the program runs end to end with wrong answers
Then the bodies, one at a time, each tested in the REPL
February has 29 days in a leap year - exercise 1 already knows which years those are
```python
terminal
```
```python
Day: 29
Month: 2
Year: 2024
Day 60 of 2024

Day: 31
Month: 4
Year: 2026
Not a valid date
```
Think about
A function per question: leap year? days in this month? is the date real? which day of the year?
The day of the year is a sum over the months before it: a loop that calls a function

## Slide 11
The idea: the pieces, then the diagram
Ask what main needs to know, and name a function for each answer.
1 · is_leap(year) - exercise 1, unchanged
2 · days_in(month, year) - 28, 29, 30 or 31; it asks is_leap about February
3 · is_valid_date(day, month, year) - the month is 1 to 12 and the day fits the month
4 · day_of_year(day, month, year) - the days of the months before, plus the day
5 · main - reads three numbers, asks, prints; the only part that prints
The design, written down
main calls is_valid_date and day_of_year
is_valid_date calls days_in
day_of_year calls days_in, in a loop
days_in calls is_leap

every arrow points down; only main prints

## Slide 12
Exercise 3: the stubs
```python
date_design.py (the four stubs)
```
```python
def is_leap(year):
    """Return True for a leap year."""
    return False


def days_in(month, year):
    """Return the days in month (1-12) of year."""
    return 30


def is_valid_date(day, month, year):
    """Return True when the date exists."""
    return True


def day_of_year(day, month, year):
    """Return the day number in the year, 1 to 366."""
    return 0
```
It runs, and it is wrong
Real names, parameters and docstrings - and a placeholder body each
The program runs end to end: the shape is checked before any hard part is written
Day 0 of 2026: wrong, and expected - a stub promises nothing but the shape
Next: fill in one body, run, fill in the next - is_leap first, because days_in needs it
`python date_design.py`
```python
Day: 24
Month: 10
Year: 2026
Day 0 of 2026
```

## Slide 13
Exercise 3: the bodies (1 of 2)
```python
date.py (lines 2-21)
```
```python
def is_leap(year):
    """Return True for a leap year."""
    by_400 = year % 400 == 0
    by_4 = year % 4 == 0 and year % 100 != 0
    return by_400 or by_4


def days_in(month, year):
    """Return the days in month (1-12) of year."""
    if month == 2:
        return 29 if is_leap(year) else 28
    if month == 4 or month == 6 or month == 9 or month == 11:
        return 30
    return 31


def is_valid_date(day, month, year):
    """Return True when the date exists."""
    if month < 1 or month > 12:
        return False
    return 1 <= day <= days_in(month, year)
```
Three bodies, each one job
is_leap: exercise 1, with the two halves of the rule named before they are combined
days_in: three cases with early returns; February asks is_leap, and a conditional expression picks 28 or 29
is_valid_date: a guard on the month first, so days_in is never asked about month 13
Nothing prints: the functions answer; main prints

## Slide 14
Exercise 3: the bodies (2 of 2)
```python
date.py (lines 24-39)
```
```python
def day_of_year(day, month, year):
    """Return the day number in the year, 1 to 366."""
    total = 0
    for m in range(1, month):
        total += days_in(m, year)
    return total + day


day = int(input("Day: "))
month = int(input("Month: "))
year = int(input("Year: "))
if is_valid_date(day, month, year):
    print(f"Day {day_of_year(day, month, year)} of {year}")
else:
    print("Not a valid date")
```
```python
A loop that calls a function
day_of_year: an accumulator over range(1, month) - the months before - plus the day
main is unchanged: the same seven lines as on the stubs slide - the design held
Two calls in main: the guard first, then the answer; both read like the task
```
`python date.py`
```python
Day: 29
Month: 2
Year: 2024
Day 60 of 2024

Day: 24
Month: 10
Year: 2026
Day 297 of 2026
```

## Slide 15
Exercise 4: Newton, with a trace
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
HIGH · 12 MIN ON YOUR OWN
Task: lecture 3-2's Newton found a square root in 3 steps. Do it for the cube root, and watch it work.
```python
cube_root_newton(x, epsilon=1e-6, trace=False): f(g) = g³ - x and f'(g) = 3g², so the next guess is g - (g³ - x) / (3g²)
Start from x / 2 when x > 1, else from 1.0; stop when |g³ - x| < epsilon
trace=True prints the guess after every step; the function still returns g
Count the steps for 27 and for 2 - against bisection's 26 and 20
```
```python
the REPL
```
```python
>>> roots.cube_root_newton(27, trace=True)
step 1: 9.049382716049383
step 2: 6.142823558176272
step 3: 4.333725614685509
step 4: 3.3683535855517652
step 5: 3.0388137235951382
step 6: 3.0004936436555805
step 7: 3.000000081210202
step 8: 3.000000000000002
3.000000000000002
```
Think about
Two defaults, so three ways to call: positional, by keyword, or not at all
A flag may change what is printed, never what is returned

## Slide 16
Exercise 4: one solution
```python
roots.py (part 3)
```
```python
def cube_root_newton(x, epsilon=1e-6, trace=False):
    """Return the cube root of x > 0, by Newton."""
    g = x / 2 if x > 1 else 1.0
    steps = 0
    while abs(g ** 3 - x) >= epsilon:
        g = g - (g ** 3 - x) / (3 * g ** 2)
        steps += 1
        if trace:
            print(f"step {steps}: {g}")
    return g
```
```python
The rule, with one f
The update: g - (g ** 3 - x) / (3 * g ** 2) - the tangent crosses zero there
The start: x / 2 above 1, else 1.0 - never 0, which the update divides by
trace: a parameter with a default of False; the print lives inside if trace:
Two defaults: cube_root_newton(27), (27, trace=True) and (2, 1e-9) are all valid calls
```
```python
the REPL
```
```python
>>> roots.cube_root_newton(2, trace=True)
step 1: 1.3333333333333333
step 2: 1.2638888888888888
step 3: 1.259933493449977
step 4: 1.2599210500177698
1.2599210500177698
```

## Slide 17
Exercise 5: A module and its user
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
MID · 6 MIN ON YOUR OWN
Task: roots.py is a library. Write use_roots.py: a second file that imports it and prints a report.
The cube roots of 27 and 2, the sloppy cube root of 2 (epsilon 0.1), the solution of cos(x) = x, and Newton's cube root of 27
Rounded to 4 digits, one line each - the rounding happens in the user, not in the library
Give roots.py a module docstring, and read one function back with help()
```python
terminal
```
```python
$ python use_roots.py
cube root of 27: 3.0
cube root of 2: 1.2599
sloppy: 1.25
cos(x) = x at 0.7391
newton: 3.0
```
```python
Think about
import roots, then roots.cube_root(27) - module name, dot, function name
The library returns values; the user decides what to show
Run from the folder that holds both files
```

## Slide 18
Exercise 5: the user
`use_roots.py`
```python
import roots

print("cube root of 27:", round(roots.cube_root(27), 4))
print("cube root of 2:", round(roots.cube_root(2), 4))
print("sloppy:", round(roots.cube_root(2, epsilon=0.1), 4))
print("cos(x) = x at", round(roots.solve_cos(), 4))
print("newton:", round(roots.cube_root_newton(27), 4))
```
```python
The caller sees names and promises
import roots, then roots.cube_root(27): the file name without .py, from the same folder; module name, dot, function
The report knows what, not how: nothing about brackets, epsilon or loops appears here
round() in the user: the library returns the full float; the caller chooses the digits
```
`python use_roots.py`
```python
cube root of 27: 3.0
cube root of 2: 1.2599
sloppy: 1.25
cos(x) = x at 0.7391
newton: 3.0
```

## Slide 19
Extra 1: Sequential search, as a function
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
EXTRA
Task: a big increment jumps over the answer, and lecture 3-2's loop never ends. Fix it, inside a function.
```python
sqrt_sequential(x, increment=0.0001, epsilon=0.01): step g up from 1.0 until g² is within epsilon of x (x >= 1)
The guard: stop as well when g has passed x, and return -1.0 to say the increment was too big
Call it with the defaults, with increment 0.01, with increment 0.7, and with all three arguments
```
```python
terminal
```
```python
$ python sqrt_sequential.py
3.9988
4.0
-1.0
1.4139
```
Think about
Two reasons to stop, joined with and; one if after the loop decides which one it was
A returned -1.0 is a signal the caller must test for - say so in the docstring

## Slide 20
Extra 1: one solution
`sqrt_sequential.py`
```python
def sqrt_sequential(x, increment=0.0001, epsilon=0.01):
    """Return a g with g * g near x, stepping up from 1.0;
    -1.0 when the increment jumps over the answer."""
    g = 1.0
    while abs(g * g - x) >= epsilon and g <= x:
        g = g + increment
    if g > x:
        return -1.0
    return g


print(round(sqrt_sequential(16), 4))
print(round(sqrt_sequential(16, increment=0.01), 4))
print(sqrt_sequential(16, increment=0.7))
print(round(sqrt_sequential(2, 0.0001, 0.001), 4))
```
```python
Two ways to stop
The condition: not close enough and g <= x - the second half is the whole fix
After the loop: g > x means the guard fired; the function reports it with -1.0 instead of a root
Two defaults, and a docstring that says both: what comes back normally, and what comes back on failure
```
`python sqrt_sequential.py`
```python
3.9988
4.0
-1.0
1.4139
```

## Slide 21
Recitation summary
Warm-up
Functions
Roots
Design
Newton
Extra
Wrap-up
What we practised
Guess, measure, improve, stop
Bisection needs a bracket; Newton needs the slope; both need a tolerance.
A function per job
One job, a good name, a docstring, tested alone in the REPL.
Design, stubs, bodies
Name the pieces, make it run, then fill in one body at a time - bottom of the diagram first.
A flag changes what is printed, never what is returned
And a library never prints at all: the caller decides.
Tools we used
Approximation
abs(), round(), epsilon, a bracket, the Newton update g - f(g) / f'(g), step counts
Functions
def, return, None, local names, default values, keyword arguments, docstrings, help()
Modules
import roots, roots.cube_root(27), a module docstring, running from the right folder
Patterns
early return, a loop that calls a function, a sentinel value for failure

## Slide 22
Self practice
AT HOME
Write a program for each of these.
gcd
gcd(a, b) returns the greatest common divisor by Euclid's rule: while b is not 0, replace (a, b) by (b, a % b). Test it on 48 and 18.
power
power(x, n) returns x to the n with a loop and multiplication only; compare with ** on ten values, and decide what n = 0 should return.
Perfect numbers
divisor_sum(n) returns the sum of the divisors of n below n; is_perfect(n) uses it. Print the perfect numbers below 10000 from a loop in main.
Newton for cos(x) = x
f(g) = cos(g) - g has slope -sin(g) - 1. Write newton_cos(epsilon=1e-6, trace=False) and count its steps against solve_cos.

## Slide 23
PYTHON COURSE · WEEK 5 · RECITATION 5
Next: Lists, tuples and tables
mutate or return, records, comprehensions, and boards

## From `warmup_functions.py`

### `warmup_functions.py`
```python
def double(x):
    return 2 * x
def shout(word):
    print(word.upper())

a = double(4)
b = shout("hi")
print(a, b)
print(double(double(3)))
x = 10
def change():
    x = 5
change()
print(x)
```

## From `warmup_bisection.py`

### `warmup_bisection.py`
```python
# Bisection (lecture 3-2), for x = 10
x = 10
epsilon = 0.01
low = 1.0
high = x
g = (low + high) / 2
steps = 0
while abs(g * g - x) >= epsilon:
    if g * g < x:
        low = g
    else:
        high = g
    g = (low + high) / 2
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```

## From `small_functions.py`

### `small_functions.py`
```python
def is_leap(year):
    """Return True when year is a leap year."""
    by_400 = year % 400 == 0
    by_4 = year % 4 == 0 and year % 100 != 0
    return by_400 or by_4


def digit_sum(n):
    """Return the sum of the digits of n (n >= 0)."""
    total = 0
    while n > 0:
        total += n % 10
        n = n // 10
    return total


def count_vowels(text):
    """Return how many vowels text contains."""
    count = 0
    for ch in text.lower():
        if ch in "aeiou":
            count += 1
    return count
```

## From `roots.py`

### `roots.py`
```python
"""Roots by approximation, as functions."""
import math


def cube_root(x, epsilon=1e-6):
    """Return the cube root of x >= 0, by bisection."""
    low = 0.0
    high = 1.0 if x < 1 else x
    g = (low + high) / 2
    while abs(g ** 3 - x) >= epsilon:
        if g ** 3 < x:
            low = g
        else:
            high = g
        g = (low + high) / 2
    return g


def solve_cos(epsilon=1e-6):
    """Return the g in [0, 1] with cos(g) = g."""
    low = 0.0
    high = 1.0
    g = (low + high) / 2
    while abs(math.cos(g) - g) >= epsilon:
        if math.cos(g) - g > 0:
            low = g
        else:
            high = g
        g = (low + high) / 2
    return g


def cube_root_newton(x, epsilon=1e-6, trace=False):
    """Return the cube root of x > 0, by Newton."""
    g = x / 2 if x > 1 else 1.0
    steps = 0
    while abs(g ** 3 - x) >= epsilon:
        g = g - (g ** 3 - x) / (3 * g ** 2)
        steps += 1
        if trace:
            print(f"step {steps}: {g}")
    return g
```

## From `date_design.py`

### `date_design.py`
```python
# The design first: names, parameters, promises
def is_leap(year):
    """Return True for a leap year."""
    return False


def days_in(month, year):
    """Return the days in month (1-12) of year."""
    return 30


def is_valid_date(day, month, year):
    """Return True when the date exists."""
    return True


def day_of_year(day, month, year):
    """Return the day number in the year, 1 to 366."""
    return 0


day = int(input("Day: "))
month = int(input("Month: "))
year = int(input("Year: "))
if is_valid_date(day, month, year):
    print(f"Day {day_of_year(day, month, year)} of {year}")
else:
    print("Not a valid date")
```

## From `date.py`

### `date.py`
```python
# The same design, with the bodies filled in
def is_leap(year):
    """Return True for a leap year."""
    by_400 = year % 400 == 0
    by_4 = year % 4 == 0 and year % 100 != 0
    return by_400 or by_4


def days_in(month, year):
    """Return the days in month (1-12) of year."""
    if month == 2:
        return 29 if is_leap(year) else 28
    if month == 4 or month == 6 or month == 9 or month == 11:
        return 30
    return 31


def is_valid_date(day, month, year):
    """Return True when the date exists."""
    if month < 1 or month > 12:
        return False
    return 1 <= day <= days_in(month, year)


def day_of_year(day, month, year):
    """Return the day number in the year, 1 to 366."""
    total = 0
    for m in range(1, month):
        total += days_in(m, year)
    return total + day


day = int(input("Day: "))
month = int(input("Month: "))
year = int(input("Year: "))
if is_valid_date(day, month, year):
    print(f"Day {day_of_year(day, month, year)} of {year}")
else:
    print("Not a valid date")
```

## From `use_roots.py`

### `use_roots.py`
```python
import roots

print("cube root of 27:", round(roots.cube_root(27), 4))
print("cube root of 2:", round(roots.cube_root(2), 4))
print("sloppy:", round(roots.cube_root(2, epsilon=0.1), 4))
print("cos(x) = x at", round(roots.solve_cos(), 4))
print("newton:", round(roots.cube_root_newton(27), 4))
```

## From `sqrt_sequential.py`

### `sqrt_sequential.py`
```python
def sqrt_sequential(x, increment=0.0001, epsilon=0.01):
    """Return a g with g * g near x, stepping up from 1.0;
    -1.0 when the increment jumps over the answer."""
    g = 1.0
    while abs(g * g - x) >= epsilon and g <= x:
        g = g + increment
    if g > x:
        return -1.0
    return g


print(round(sqrt_sequential(16), 4))
print(round(sqrt_sequential(16, increment=0.01), 4))
print(sqrt_sequential(16, increment=0.7))
print(round(sqrt_sequential(2, 0.0001, 0.001), 4))
```


---

# Recitation, week 5: Tables, dictionaries and sets

## From `recitation 5.pptx`

## Slide 1
```python
[:]
```
PYTHON COURSE · WEEK 5 · RECITATION 5
Recitation 5
Lists, tuples and tables

## Slide 2
Recitation overview
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
1
Predictions
aliasing, None, comprehensions, and the grid trap
2
One-liners
loops to comprehensions, pairs, and zip
3
Lists and records
mutate or return; a grade book from tuples
4
Boards
tic-tac-toe, in four functions

## Slide 3
Warm-up: lists
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
WARM-UP · 4 MIN
Six printed lines. Two of them are traps from lecture 4-2 - which two?
`warmup_lists.py`
```python
a = [1, 2, 3]
b = a
b.append(4)
print(a)
c = a[:]
c[0] = 99
print(a, c)
print(a.sort())
print(a)
t = (1, 2)
x, y = t
print(y, x)
print([1, 2] + [3], [0] * 3)
```
The answers
[1, 2, 3, 4]   (b is a second name, not a copy)
[1, 2, 3, 4] [99, 2, 3, 4]   (a slice is a copy)
None   (sort changes a and returns nothing)
[1, 2, 3, 4]
2 1
[1, 2, 3] [0, 0, 0]

## Slide 4
Warm-up: comprehensions and grids
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
WARM-UP · 4 MIN
Six printed lines. One of them is the most common 2D-list bug there is.
`warmup_grids.py`
```python
nums = [3, 8, 1, 6]
print([x * 2 for x in nums])
print([x for x in nums if x > 2])
words = ["a", "bb", "c"]
print(len([w for w in words if len(w) == 1]))

grid = [[0] * 2] * 2
grid[0][0] = 7
print(grid)
rows = [[0] * 2 for _ in range(2)]
rows[0][0] = 7
print(rows)
print([row[1] for row in rows])
```
```python
The answers
[6, 16, 2, 12]
[3, 8, 6]
2
[[7, 0], [7, 0]]  (one row, two names)
[[7, 0], [0, 0]]
[0, 0]  (column 1)
```

## Slide 5
Exercise 1: Loops to comprehensions
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
EASY · 6 MIN ON YOUR OWN
Task: each of these builds a list with a loop. Rewrite it as one comprehension.
The squares of the odd numbers below 12
The lengths of the words in a list
The words longer than three letters, in uppercase
Column 2 of a table - and then: which one of the four should stay a loop?
```python
terminal
```
```python
[1, 9, 25, 49, 81, 121]
[3, 4, 2, 5, 5]
['RAIN', 'SPAIN', 'FALLS']
[4, 4, 3]
```
Think about
Read from the middle: the loop, then the value, then an if that keeps some items
A loop that prints is not building a list

## Slide 6
Exercise 1: one solution
`comprehensions.py`
```python
words = ["the", "rain", "in", "spain", "falls"]
table = [[4, 5, 4], [5, 3, 4], [3, 4, 3]]

squares = [k * k for k in range(1, 12, 2)]
lengths = [len(w) for w in words]
loud = [w.upper() for w in words if len(w) > 3]
column = [row[2] for row in table]

print(squares)
print(lengths)
print(loud)
print(column)
```
```python
Four shapes
Source: range(1, 12, 2) supplies the odd numbers - no if needed
A call in the value: len(w) for each word
Transform and filter: the value changes the item, the if keeps some
A column: row[2] from every row, in one line
```

## Slide 7
Exercise 1: the run
`comprehensions.py`
```python
words = ["the", "rain", "in", "spain", "falls"]
table = [[4, 5, 4], [5, 3, 4], [3, 4, 3]]

squares = [k * k for k in range(1, 12, 2)]
lengths = [len(w) for w in words]
loud = [w.upper() for w in words if len(w) > 3]
column = [row[2] for row in table]

print(squares)
print(lengths)
print(loud)
print(column)
```
`python comprehensions.py`
```python
[1, 9, 25, 49, 81, 121]
[3, 4, 2, 5, 5]
['RAIN', 'SPAIN', 'FALLS']
[4, 4, 3]
```

## Slide 8
Exercise 2: Pairs
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
EASY · 5 MIN ON YOUR OWN
Task: two lists. Pair the items that sit at the same position, as a list of tuples.
```python
pairs(a, b) returns [(a[0], b[0]), (a[1], b[1]), ...]
Different lengths: pair as far as the shorter list goes
Without zip. If you know it, do not use it yet - a loop over positions, or a comprehension
```
```python
the REPL
```
```python
>>> names = ["dana", "ron"]
>>> grades = [88, 95]
>>> pairs(names, grades)
[('dana', 88), ('ron', 95)]
>>> pairs([1, 2, 3], ["a", "b"])
[(1, 'a'), (2, 'b')]
```
```python
Think about
Position i of both lists: a[i] and b[i] - a loop over range(len(a))
A tuple is built with parentheses: (a[i], b[i])
```

## Slide 9
Exercise 2: one solution
`pairs.py`
```python
def pairs(a, b):
    """Pair a[i] with b[i]; the shorter wins."""
    result = []
    for i in range(min(len(a), len(b))):
        result.append((a[i], b[i]))
    return result

names = ["dana", "ron", "omer"]
grades = [88, 95, 51]
for name, grade in pairs(names, grades):
    print(name, grade)
print(pairs([1, 2, 3], ["a", "b"]))
```
```python
Reading it
Positions, not items: range(...) because the same i must reach both lists
The shorter wins: min(len(a), len(b)) keeps b[i] inside b
Double parentheses: append((a[i], b[i])) - the inner pair packs the tuple
Unpacking the result: for name, grade in pairs(...) reads like the records of lecture 4-2
```

## Slide 10
Exercise 2: the run
`pairs.py`
```python
def pairs(a, b):
    """Pair a[i] with b[i]; the shorter wins."""
    result = []
    for i in range(min(len(a), len(b))):
        result.append((a[i], b[i]))
    return result

names = ["dana", "ron", "omer"]
grades = [88, 95, 51]
for name, grade in pairs(names, grades):
    print(name, grade)
print(pairs([1, 2, 3], ["a", "b"]))
```
`python pairs.py`
```python
dana 88
ron 95
omer 51
[(1, 'a'), (2, 'b')]
```

## Slide 11
Meet zip
```python
Python has this function built in. Think of a zipper, not a zip file.
zip(a, b) pairs the items at matching positions
It stops at the shorter list, like our min()
Lazy: list(zip(a, b)) shows the pairs; a for loop walks them
for name, grade in zip(names, grades): - no index in sight
Several lists: zip(a, b, c) gives triples
```
Rule of thumb:
walking two lists side by side? zip. Needing the position number itself? range(len(...)).

## Slide 12
Exercise 2, with zip
`pairs_zip.py`
```python
names = ["dana", "ron", "omer"]
grades = [88, 95, 51]

print(zip(names, grades))
print(list(zip(names, grades)))

for name, grade in zip(names, grades):
    print(name, grade)

print(list(zip([1, 2, 3], ["a", "b"])))
```
```python
The same task, by name
One call: zip(names, grades) replaces the loop, the index and the min()
Lazy: the first print shows a zip object, not the pairs; list() collects them
Unpacking in the header: the pairs come out one at a time, and name, grade takes each apart
The shorter wins: [1, 2, 3] with ['a', 'b'] gives two pairs, as pairs() did
```

## Slide 13
Exercise 2, with zip: the run
`pairs_zip.py`
```python
names = ["dana", "ron", "omer"]
grades = [88, 95, 51]

print(zip(names, grades))
print(list(zip(names, grades)))

for name, grade in zip(names, grades):
    print(name, grade)

print(list(zip([1, 2, 3], ["a", "b"])))
```
`python pairs_zip.py`
```python
<zip object at 0x...>
[('dana', 88), ('ron', 95), ('omer', 51)]
dana 88
ron 95
omer 51
[(1, 'a'), (2, 'b')]
```

## Slide 14
Exercise 3: Mutate or return?
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
MID · 10 MIN ON YOUR OWN
Task: remove the negative numbers from a list - twice, in the two ways a function can do it.
```python
remove_negatives(nums) changes the list it is given and returns None
without_negatives(nums) leaves its argument alone and returns a new list
Test both on the same list and print it after each call. What is different?
```
```python
the REPL
```
```python
>>> a = [3, -1, 4, -5, 9]
>>> b = without_negatives(a)
>>> b, a
([3, 4, 9], [3, -1, 4, -5, 9])
>>> remove_negatives(a)
>>> a
[3, 4, 9]
```
```python
Think about
Removing inside a for skips items: use a while with an index and pop(i)
The new-list version is the kept-list pattern
```

## Slide 15
Exercise 3: one solution
`negatives.py`
```python
def remove_negatives(nums):
    """Remove the negatives, in place."""
    i = 0
    while i < len(nums):
        if nums[i] < 0:
            nums.pop(i)
        else:
            i += 1

def without_negatives(nums):
    """Return a new list, negatives dropped."""
    kept = []
    for x in nums:
        if x >= 0:
            kept.append(x)
    return kept
```
```python
Two contracts
In place: no return - the parameter is a second name for the caller's list
The index advances only when nothing was removed: after pop(i) the next item is already at i
New list: the argument is never touched; the kept list is built and returned
Never both: changing the argument and returning a result confuses every caller
```

## Slide 16
Noa's version does both. What goes wrong?
It mutates and returns. Predict the three prints.
`noa.py`
```python
def cleaned(nums):
    i = 0
    while i < len(nums):
        if nums[i] < 0:
            nums.pop(i)
        else:
            i += 1
    return nums
```
`using_noa.py`
```python
from noa import cleaned

scores = [3, -1, 4, -5, 9]
good = cleaned(scores)
print(good)
print(scores)
good.append(100)
print(scores)
```
```python
[3, 4, 9], then [3, 4, 9] again - scores changed, which the name never suggested. Then [3, 4, 9, 100]: good and scores are one list.
The rule: mutate and return None, or build and return new - never both.
```

## Slide 17
Exercise 4: The grade book
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
HIGH · 12 MIN ON YOUR OWN
Task: a class is a list of (name, grade) tuples. Write the report functions.
```python
top_student(students): the record with the highest grade
failing(students, pass_mark): names below pass_mark; default 56
curve(students, points): new records with points added, capped at 100
add_student(students, name, grade): adds a record, in place
```
```python
the REPL
```
```python
>>> top_student(students)
('Ron Cohen', 95)
>>> failing(students)
['Omer Katz']
>>> curve(students, 10)[1]
('Ron Cohen', 100)
```
```python
Think about
Unpack in the for header: for name, grade in students:
A tuple cannot change: curve builds a new one per student
```

## Slide 18
Exercise 4: the class, and the top student
```python
gradebook.py (part 1)
```
```python
students = [("Dana Levi", 88),
            ("Ron Cohen", 95),
            ("Omer Katz", 51),
            ("Yael Bar", 73)]

def top_student(students):
    """Return the record with the top grade."""
    best = students[0]
    for record in students:
        if record[1] > best[1]:
            best = record
    return best
```
```python
Records in, a record out
The class: a list of tuples, one tuple per student - the shape from lecture 4-2
Running maximum over records: best is a whole tuple; record[1] is the grade inside it
Returns the record, not the grade: the caller can unpack name and grade from it
Empty class: students[0] raises IndexError - a promise to state in the docstring
```

## Slide 19
Exercise 4: failing and curve
```python
gradebook.py (part 2)
```
```python
def failing(students, pass_mark=56):
    """Return the names below pass_mark."""
    names = []
    for name, grade in students:
        if grade < pass_mark:
            names.append(name)
    return names

def curve(students, points):
    """New records, points added, max 100."""
    curved = []
    for name, grade in students:
        new_grade = min(grade + points, 100)
        curved.append((name, new_grade))
    return curved
```
```python
Two builders
Unpacking in the header: for name, grade in students takes each tuple apart
A default: pass_mark=56 makes the second argument optional - failing(students) and failing(students, 80) both work
curve builds: a new list, and a new tuple per student - tuples cannot change, so none is
min(grade + points, 100): the cap in one call, with the built-in from lecture 4-2
```

## Slide 20
Exercise 4: add_student, and the report
```python
gradebook.py (part 3)
```
```python
def add_student(students, name, grade):
    """Add one record, in place."""
    students.append((name, grade))

add_student(students, "Noa Peretz", 64)
name, grade = top_student(students)
print(f"Top: {name} with {grade}")
print(f"Failing: {failing(students)}")
print(f"Curved: {curve(students, 10)}")
```
```python
One mutator, then main
add_student mutates: append on the caller's list, no return - the other contract
Unpacking the answer: name, grade = top_student(students) takes the returned tuple apart
The report calls the functions by name; nothing about loops appears here
Next week: looking up one student by name is what a dictionary is for
```

## Slide 21
Exercise 4: the run
```python
gradebook.py (part 3)
```
```python
def add_student(students, name, grade):
    """Add one record, in place."""
    students.append((name, grade))

add_student(students, "Noa Peretz", 64)
name, grade = top_student(students)
print(f"Top: {name} with {grade}")
print(f"Failing: {failing(students)}")
print(f"Curved: {curve(students, 10)}")
```
```python
python gradebook.py (wrapped)
```
```python
Top: Ron Cohen with 95
Failing: ['Omer Katz']
Curved: [('Dana Levi', 98),
  ('Ron Cohen', 100),
  ('Omer Katz', 61),
  ('Yael Bar', 83),
  ('Noa Peretz', 74)]
```

## Slide 22
Exercise 5: Tic-tac-toe
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
MID · 12 MIN ON YOUR OWN
Task: the board is a 3 x 3 list of lists. Write the four functions a game needs.
```python
make_board(): a fresh 3 x 3 board of dots
show(board): one row per line
place(board, r, c, mark): writes the mark if the cell is free; returns True or False
winner(board): X, O or None - three in a row, column or diagonal
```
```python
terminal
```
```python
. . .
. X .
O . .

place(board, 1, 1, "O") -> False

winner -> X
```
```python
Think about
A column: [board[r][c] for r in range(3)]
A line wins when its three cells are equal - and not dots
```

## Slide 23
Exercise 5: the board, show and place
```python
tictactoe.py (part 1)
```
```python
def make_board():
    """Return a 3 x 3 board of dots."""
    return [["."] * 3 for _ in range(3)]

def show(board):
    """Print the board, one row per line."""
    for row in board:
        print(" ".join(row))

def place(board, r, c, mark):
    """Write mark at (r, c) if free."""
    if board[r][c] != ".":
        return False
    board[r][c] = mark
    return True
```
```python
Three small functions
make_board: a comprehension builds three separate rows; [["."] * 3] * 3 would build one row three times
show: " ".join(row) glues one row's three strings; a loop prints the rows
place: a guard, then the write; the boolean tells the caller whether the move happened
place mutates and returns a bool: a yes-or-no answer about what it did, not the board
```

## Slide 24
Exercise 5: the winner
```python
tictactoe.py (part 2)
```
```python
def winner(board):
    """Return X, O, or None."""
    lines = list(board)
    for i in range(3):
        lines.append([row[i] for row in board])
    diag = [board[i][i] for i in range(3)]
    anti = [board[i][2 - i] for i in range(3)]
    lines += [diag, anti]
    for line in lines:
        first = line[0]
        if first != "." and line == [first] * 3:
            return first
    return None
```
```python
Gather the lines, then test each
Eight lines as lists of three cells: list(board) copies the three rows; columns and diagonals are comprehensions
The diagonals: board[i][i] and board[i][2 - i] - the index arithmetic is the whole trick
The test: not a dot, and all three equal - line == [first] * 3
Two kinds of return: a mark as soon as a line is found, None after the loop
```

## Slide 25
Exercise 5: a scripted game
```python
tictactoe.py (part 3)
```
```python
board = make_board()
moves = [(1, 1, "X"), (2, 0, "O"), (0, 0, "X"),
         (1, 1, "O"), (2, 2, "X")]
for r, c, mark in moves:
    ok = place(board, r, c, mark)
    if not ok:
        print(mark, "cannot play at", (r, c))
show(board)
print("winner:", winner(board))
```
```python
Using the four functions
Moves as tuples: (row, column, mark), unpacked in the for header; (r, c) is printed as one
The refused move: O tries the centre, which X holds; place returns False and nothing changes
The diagonal: X at (0, 0), (1, 1), (2, 2) wins
Your turn: replace the list of moves with input() calls and a loop until someone wins
```

## Slide 26
Exercise 5: the run
```python
tictactoe.py (part 3)
```
```python
board = make_board()
moves = [(1, 1, "X"), (2, 0, "O"), (0, 0, "X"),
         (1, 1, "O"), (2, 2, "X")]
for r, c, mark in moves:
    ok = place(board, r, c, mark)
    if not ok:
        print(mark, "cannot play at", (r, c))
show(board)
print("winner:", winner(board))
```
`python tictactoe.py`
```python
O cannot play at (1, 1)
X . .
. X .
O . X
winner: X
```

## Slide 27
Extra 1: Minesweeper numbers
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
EXTRA
Task: a field is a grid of * (a mine) and . (empty). Replace every dot with the number of mines around it.
```python
Around means the eight neighbours; at the edges and corners there are fewer
around(field, r, c): how many mines touch cell (r, c)
numbers(field): a new grid of strings, mines kept, dots replaced by digits
```
```python
the field, and its numbers
```
```python
*...    *100
....    2210
.*..    1*10
....    1110
```
```python
Think about
Neighbours: dr and dc from -1 to 1, in two loops
Count a neighbour only if its row and column are inside the grid
```

## Slide 28
Extra 1: counting around a cell
```python
mines.py (part 1)
```
```python
def around(field, r, c):
    """Count the mines touching cell (r, c)."""
    n = len(field)
    m = len(field[0])
    count = 0
    for dr in [-1, 0, 1]:
        for dc in [-1, 0, 1]:
            nr = r + dr
            nc = c + dc
            inside = 0 <= nr < n and 0 <= nc < m
            if inside and field[nr][nc] == "*":
                count += 1
    return count
```
```python
Eight neighbours, with bounds
The offsets: dr and dc from -1 to 1 give nine positions; the cell itself is a dot, so it never counts
inside: one chained comparison per axis, joined with and
Order matters: inside and ... tests the bounds before the index is used
field[-1] would not crash - it is the last row; the bounds check keeps the edge honest
```

## Slide 29
Extra 1: the whole field
```python
mines.py (part 2)
```
```python
def numbers(field):
    """Dots replaced by mine counts."""
    result = []
    for r in range(len(field)):
        row = ""
        for c in range(len(field[r])):
            if field[r][c] == "*":
                row += "*"
            else:
                row += str(around(field, r, c))
        result.append(row)
    return result

field = ["*...", "....", ".*..", "...."]
for row in numbers(field):
    print(row)
```
```python
Visit every cell, build a new grid
Strings as rows: field[r][c] is one character
Two accumulators: a string per row, a list for the rows; the field itself is never changed
around only for dots: the if keeps the mines
str(...): a count is a number, a row is text
```

## Slide 30
Extra 1: the run
```python
mines.py (part 2)
```
```python
def numbers(field):
    """Dots replaced by mine counts."""
    result = []
    for r in range(len(field)):
        row = ""
        for c in range(len(field[r])):
            if field[r][c] == "*":
                row += "*"
            else:
                row += str(around(field, r, c))
        result.append(row)
    return result

field = ["*...", "....", ".*..", "...."]
for row in numbers(field):
    print(row)
```
`python mines.py`
```python
*100
2210
1*10
1110
```

## Slide 31
Extra 2: Permutations
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
EXTRA
Task: a permutation of n holds every number from 0 to n - 1 exactly once.
```python
is_permutation(per): True for [2, 0, 1]; False for [2, 2, 0], [2, 3, 0], [0, 1, 5]
inverse(per): undoes per - if per sends 0 to 2, the inverse sends 2 to 0
Check: reorder with per, then with inverse(per), gives the list back
```
```python
the REPL
```
```python
>>> is_permutation([2, 0, 1])
True
>>> is_permutation([2, 2, 0])
False
>>> inverse([2, 0, 1])
[1, 2, 0]
```
```python
Think about
[False] * n remembers which numbers were seen
Out of range first: a value must be a valid index before it is used as one
```

## Slide 32
Extra 2: is it a permutation?
```python
permutations.py (part 1)
```
```python
def is_permutation(per):
    """True if per holds each of 0..n-1 once."""
    n = len(per)
    seen = [False] * n
    for value in per:
        if value < 0 or value >= n:
            return False
        if seen[value]:
            return False
        seen[value] = True
    return True
```
```python
A list as memory
seen: one slot per value; the value itself is the index - index-as-data, from the lecture
Two early returns: out of range, or seen before - either settles the answer
Order matters: the range check comes first, so seen[value] is only read with a valid index
A missing value is never checked: n slots, n values, no repeat - nothing can be missing
```

## Slide 33
Extra 2: the inverse
```python
permutations.py (part 2)
```
```python
def inverse(per):
    """Return the permutation undoing per."""
    inv = [0] * len(per)
    for i in range(len(per)):
        inv[per[i]] = i
    return inv
```
```python
Write at the destination
inv[per[i]] = i: per says where position i goes; the inverse records, there, where it came from
A list of the right size first: [0] * len(per), then every slot is overwritten
Trace [2, 0, 1]: 0 goes to 2, so inv[2] = 0; 1 goes to 0, so inv[0] = 1; 2 goes to 1 - giving [1, 2, 0]
A promise: with a list that is not a permutation, the result is wrong or an IndexError
```
```python
the REPL
```
```python
>>> inverse([2, 0, 1])
[1, 2, 0]
>>> is_permutation([2, 3, 0])
False
```

## Slide 34
Recitation summary
Warm-up
Comprehensions
Lists
Records
Boards
Extra
Wrap-up
What we practised
Read from the middle
A comprehension: the loop, then the value, then the if.
Mutate or return
Change the argument and return None, or build and return new - never both.
Records
A list of tuples; unpack in the for header; carry a whole tuple in a maximum.
Separate rows
Build a grid with a comprehension; [[x] * m] * n is one row repeated.
Tools we used
Lists
append, pop(i), [x] * n, in, not in, slicing copies, len, sum, min, max, sorted
Tuples
packing, unpacking, (name, grade) records, min(a, b) for a cap
Tables
board[r][c], rows as lists or strings, bounds checks, join to print
zip
zip(a, b) pairs matching positions, stops at the shorter; list(zip(...))

## Slide 35
Self practice
AT HOME
Write a program for each of these.
Rotate
rotate(nums, k) returns a new list with the last k items moved to the front: [1, 2, 3, 4, 5] by 2 gives [4, 5, 1, 2, 3]. Slices do all the work.
Merge
merge(a, b) returns one sorted list from two sorted lists, walking both with an index - never using sort or sorted.
Symmetric
is_symmetric(m) returns True when a square matrix equals its transpose - with two loops, and then in one line with the lecture's transpose.
A module of text tools
textstats.py: word_count, longest_word and unique_words (the distinct words, in order of first appearance), each a few lines over text.lower().split(); use them from a second file.

## Slide 36
PYTHON COURSE · WEEK 6 · RECITATION 6
Next: Dictionaries, sets and files
counting by key, membership, and text from a file

## From `anagrams.py`

### `anagrams.py`
```python
def anagram_groups(words):
    """Return sorted letters -> words."""
    groups = {}
    for word in words:
        key = "".join(sorted(word))
        if key not in groups:
            groups[key] = []
        groups[key].append(word)
    return groups

words = ["listen", "silent", "enlist",
         "google", "banana", "inlets", "elgoog"]
for group in anagram_groups(words).values():
    if len(group) > 1:
        print(" ".join(group))
```

## From `comprehensions.py`

### `comprehensions.py`
```python
words = ["the", "rain", "in", "spain", "falls"]
table = [[4, 5, 4], [5, 3, 4], [3, 4, 3]]

squares = [k * k for k in range(1, 12, 2)]
lengths = [len(w) for w in words]
loud = [w.upper() for w in words if len(w) > 3]
column = [row[2] for row in table]

print(squares)
print(lengths)
print(loud)
print(column)
```

## From `enrolments.py`

### `enrolments.py`
```python
enrolled = {
    "dana": {"python", "calculus", "physics"},
    "ron": {"python", "calculus"},
    "omer": {"python", "art"},
    "yael": {"art", "python"},
}
courses = ["python", "calculus", "physics",
           "art", "history"]

both = []
for name, taken in enrolled.items():
    if {"python", "calculus"} <= taken:
        both.append(name)
print("both:", sorted(both))

union = set()
for taken in enrolled.values():
    union |= taken
print("nobody:", sorted(set(courses) - union))

names = sorted(enrolled)
best = 0
for i in range(len(names)):
    for j in range(i + 1, len(names)):
        a, b = names[i], names[j]
        shared = len(enrolled[a] & enrolled[b])
        if shared > best:
            best = shared
            pair = (a, b)
print("most shared:", pair[0], pair[1], best)

for i in range(len(names)):
    for j in range(i + 1, len(names)):
        a, b = names[i], names[j]
        if enrolled[a] == enrolled[b]:
            print("same:", a, b)
```

## From `gradebook.py`

### `gradebook.py`
```python
students = [("Dana Levi", 88),
            ("Ron Cohen", 95),
            ("Omer Katz", 51),
            ("Yael Bar", 73)]

def top_student(students):
    """Return the record with the top grade."""
    best = students[0]
    for record in students:
        if record[1] > best[1]:
            best = record
    return best

def failing(students, pass_mark=56):
    """Return the names below pass_mark."""
    names = []
    for name, grade in students:
        if grade < pass_mark:
            names.append(name)
    return names

def curve(students, points):
    """New records, points added, max 100."""
    curved = []
    for name, grade in students:
        new_grade = min(grade + points, 100)
        curved.append((name, new_grade))
    return curved

def add_student(students, name, grade):
    """Add one record, in place."""
    students.append((name, grade))

add_student(students, "Noa Peretz", 64)
name, grade = top_student(students)
print(f"Top: {name} with {grade}")
print(f"Failing: {failing(students)}")
print(f"Curved: {curve(students, 10)}")
```

## From `letters.py`

### `letters.py`
```python
def letter_counts(text):
    """Return a dict of letter -> count."""
    counts = {}
    for ch in text.lower():
        if ch.isalpha():
            counts[ch] = counts.get(ch, 0) + 1
    return counts

text = input("text: ")
counts = letter_counts(text)
for letter in sorted(counts):
    print(letter, counts[letter])
best = ""
for letter, count in counts.items():
    if best == "" or count > counts[best]:
        best = letter
print("most frequent:", best)
```

## From `mines.py`

### `mines.py`
```python
def around(field, r, c):
    """Count the mines touching cell (r, c)."""
    n = len(field)
    m = len(field[0])
    count = 0
    for dr in [-1, 0, 1]:
        for dc in [-1, 0, 1]:
            nr = r + dr
            nc = c + dc
            inside = 0 <= nr < n and 0 <= nc < m
            if inside and field[nr][nc] == "*":
                count += 1
    return count

def numbers(field):
    """Dots replaced by mine counts."""
    result = []
    for r in range(len(field)):
        row = ""
        for c in range(len(field[r])):
            if field[r][c] == "*":
                row += "*"
            else:
                row += str(around(field, r, c))
        result.append(row)
    return result

field = ["*...", "....", ".*..", "...."]
for row in numbers(field):
    print(row)
```

## From `negatives.py`

### `negatives.py`
```python
def remove_negatives(nums):
    """Remove the negatives, in place."""
    i = 0
    while i < len(nums):
        if nums[i] < 0:
            nums.pop(i)
        else:
            i += 1

def without_negatives(nums):
    """Return a new list, negatives dropped."""
    kept = []
    for x in nums:
        if x >= 0:
            kept.append(x)
    return kept
```

## From `noa.py`

### `noa.py`
```python
def cleaned(nums):
    i = 0
    while i < len(nums):
        if nums[i] < 0:
            nums.pop(i)
        else:
            i += 1
    return nums
```

## From `pairs.py`

### `pairs.py`
```python
def pairs(a, b):
    """Pair a[i] with b[i]; the shorter wins."""
    result = []
    for i in range(min(len(a), len(b))):
        result.append((a[i], b[i]))
    return result

names = ["dana", "ron", "omer"]
grades = [88, 95, 51]
for name, grade in pairs(names, grades):
    print(name, grade)
print(pairs([1, 2, 3], ["a", "b"]))
```

## From `pairs_zip.py`

### `pairs_zip.py`
```python
names = ["dana", "ron", "omer"]
grades = [88, 95, 51]

print(zip(names, grades))
print(list(zip(names, grades)))

for name, grade in zip(names, grades):
    print(name, grade)

print(list(zip([1, 2, 3], ["a", "b"])))
```

## From `permutations.py`

### `permutations.py`
```python
def is_permutation(per):
    """True if per holds each of 0..n-1 once."""
    n = len(per)
    seen = [False] * n
    for value in per:
        if value < 0 or value >= n:
            return False
        if seen[value]:
            return False
        seen[value] = True
    return True

def inverse(per):
    """Return the permutation undoing per."""
    inv = [0] * len(per)
    for i in range(len(per)):
        inv[per[i]] = i
    return inv
```

## From `positions.py`

### `positions.py`
```python
def positions(text):
    """Return word -> list of its positions."""
    where = {}
    words = text.lower().split()
    for i in range(len(words)):
        w = words[i]
        if w not in where:
            where[w] = []
        where[w].append(i)
    return where

text = "the cat saw the dog"
print(positions(text))
```

## From `tictactoe.py`

### `tictactoe.py`
```python
def make_board():
    """Return a 3 x 3 board of dots."""
    return [["."] * 3 for _ in range(3)]

def show(board):
    """Print the board, one row per line."""
    for row in board:
        print(" ".join(row))

def place(board, r, c, mark):
    """Write mark at (r, c) if free."""
    if board[r][c] != ".":
        return False
    board[r][c] = mark
    return True

def winner(board):
    """Return X, O, or None."""
    lines = list(board)
    for i in range(3):
        lines.append([row[i] for row in board])
    diag = [board[i][i] for i in range(3)]
    anti = [board[i][2 - i] for i in range(3)]
    lines += [diag, anti]
    for line in lines:
        first = line[0]
        if first != "." and line == [first] * 3:
            return first
    return None

board = make_board()
moves = [(1, 1, "X"), (2, 0, "O"), (0, 0, "X"),
         (1, 1, "O"), (2, 2, "X")]
for r, c, mark in moves:
    ok = place(board, r, c, mark)
    if not ok:
        print(mark, "cannot play at", (r, c))
show(board)
print("winner:", winner(board))
```

## From `using_noa.py`

### `using_noa.py`
```python
from noa import cleaned

scores = [3, -1, 4, -5, 9]
good = cleaned(scores)
print(good)
print(scores)
good.append(100)
print(scores)
```

## From `warmup_dicts.py`

### `warmup_dicts.py`
```python
d = {"a": 1, "b": 2}
d["c"] = 3
d["a"] = 10
print(d)
print("b" in d, 2 in d)
print(d.get("z", 0))
print(len(d), sorted(d))
print(sum(d.values()))
s = set("banana")
print(len(s), sorted(s))
print({1, 2, 3} & {2, 3, 4}, {1, 2} <= {1, 2, 3})
print(d["z"])
```

## From `warmup_grids.py`

### `warmup_grids.py`
```python
nums = [3, 8, 1, 6]
print([x * 2 for x in nums])
print([x for x in nums if x > 2])
words = ["a", "bb", "c"]
print(len([w for w in words if len(w) == 1]))

grid = [[0] * 2] * 2
grid[0][0] = 7
print(grid)
rows = [[0] * 2 for _ in range(2)]
rows[0][0] = 7
print(rows)
print([row[1] for row in rows])
```

## From `warmup_lists.py`

### `warmup_lists.py`
```python
a = [1, 2, 3]
b = a
b.append(4)
print(a)
c = a[:]
c[0] = 99
print(a, c)
print(a.sort())
print(a)
t = (1, 2)
x, y = t
print(y, x)
print([1, 2] + [3], [0] * 3)
```
