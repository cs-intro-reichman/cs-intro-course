# Lecture 3-1: Strings (week 3)

## Slide 1
PYTHON COURSE · WEEK 3 · LECTURE 1
Strings
Indexing, slicing, immutability and methods

## Slide 2
Lecture overview
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples
1
A string
characters in a row, numbered from 0
2
Indexing and slicing
one character, or a piece
3
Immutability
every change builds a new string
4
Methods
upper, strip, find, replace — and the cipher

## Slide 3
Writing a string
Single or double quotes: the result is the same.
`quotes.py`
```python
a = "double quotes"
b = 'single quotes'
c = "it's fine inside double quotes"
d = 'and "quotes" inside single ones'
```
PEP 8 has no preference. Be consistent.
```python
Escape sequences
\n : A new line.
\" and \' : A quote that does not end the string.
\\ : One backslash.
```
`print.py`
```python
print("I don't like\nthe word \"no\"")
```
```python
\
```
```python
n
```
typed
```python
?
```
stored
As how many characters?
```python
terminal
```
```python
I don't like
the word "no"
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 4
A string is a sequence of characters
Every character in the sequence has a position (index), starting with 0.
```python
A
```
```python
s
```
```python
␣
```
```python
e
```
```python
a
```
```python
s
```
```python
y
```
```python
␣
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
7
```
```python
len(s) = 8
```
```python
last position = len(s) - 1 = 7
```
`len.py`
```python
print(len(s))      # 8
print(len("Hi"))   # 2
print(len(""))     # 0
```
```python
↵
```
```python
len("\n") = 1
```
```python
A new built-in function: len
len(s) : The number of characters, as an int.
Same family: print, input, int, str: the name, then the value in parentheses.
Spaces count: A string holds exactly what is between the quotes.
Last position: len(s) - 1, since positions start at 0.
```
Each character is itself a number — later in this lecture.

## Slide 5
Direct iteration over strings
A for loop iterates over any sequence, including strings. 
`letters.py`
```python
for ch in "binary":
    print(ch)
```
```python
output
```
```python
b
i
n
a
r
y
```
```python
b
```
```python
i
```
```python
n
```
```python
a
```
```python
r
```
```python
y
```
One character at a time, in order.
```python
Already known
Direct iteration: for ch in s visits every character from left to right (Lecture 2-2).
Limitations: Does not allow picking a specific index (e.g. the 5th or last character) or iterating in a custom order.
```

## Slide 6
The questions we ask about text
Before the tools: what do we actually want to ask?
```python
A
```
```python
A
```
```python
T
```
```python
T
```
```python
T
```
```python
G
```
```python
C
```
```python
A
```
```python
T
```
```python
T
```
```python
C
```
```python
dna = "AATTTGCATTC"
```
What is at
position 4?
Does "TGC" appear anywhere?
What are the last three bases?
How many times does "T" appear?
Where does "G" first appear?
Are these two
sequences equal?
Do they match if we ignore case?
Does "C?T" appear, 
if ? is any base?

## Slide 7
Indexing
```python
s[i] is the character at position i.
```
`index.py`
```python
s = "Python"
print(s[0])    # P
print(s[5])    # n
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
IndexError
```
What comes back
A string of length 1: There is no separate character type.
```python
One past the end
Valid indices: 0 to len(s) - 1.
s[len(s)]: Raises an IndexError.
```
```python
s[0]
```
```python
P
```
a string of length 1
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 8
Negative indices
A negative index counts from the end, starting at -1.
`negative.py`
```python
s = "Python"
print(s[-1])   # n
print(s[-2])   # o
print(s[-6])   # P
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
-6
```
```python
-5
```
```python
-4
```
```python
-3
```
```python
-2
```
```python
-1
```
```python
Why negative indices?
s[-1]: The last character, in the usual form.
s[len(s) - 1]: The same character, longer to write and easier to get wrong.
No -0: Index 0 is always the first character.
```
Two numbering systems, one row of boxes.

## Slide 9
Example: is it a palindrome?
Task: Given a string, check if it is a palindrome (reads the same forwards and backwards).
The idea: compare the first and last characters, then move inward.
`palindrome_idx.py`
```python
word = input("Enter a word: ")
palindrome = True
for i in range(len(word) // 2):
    if word[i] != word[-1 - i]:
        palindrome = False
        break
if palindrome:
    print(word, "is a palindrome")
else:
    print(word, "is not a palindrome")
```
```python
r
```
```python
a
```
```python
c
```
```python
e
```
```python
c
```
```python
a
```
```python
r
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
-7
```
```python
-6
```
```python
-5
```
```python
-4
```
```python
-3
```
```python
-2
```
```python
-1
```
```python
e
```
```python
0 ↔ -1
```
```python
1 ↔ -2
```
```python
2 ↔ -3
```
```python
How it works
Pairs: word[i] and word[-1 - i].
Half the word: The middle has no partner.
Mismatch: break stops the loop.
```

## Slide 10
Slicing: s[start:stop]
Creates a new string from start up to, but not including, stop.
`slice.py`
```python
s = "As easy "
print(s[1:5])   # s ea
print(s[0:2])   # As
```
```python
A
```
```python
s
```
```python
␣
```
```python
e
```
```python
a
```
```python
s
```
```python
y
```
```python
␣
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
7
```
```python
5 - 1 = 4 characters
```
```python
s
```
```python
␣
```
```python
e
```
```python
a
```
A new string, four characters long.
```python
The half-open convention
As in range(): Stop is excluded.
Length: s[a:b] has b - a characters.
A copy: s is unchanged.
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 11
Omitting a bound
No start: from the beginning. No stop: to the end.
`bounds.py`
```python
s = "Python"
print(s[:3])    # Pyt
print(s[3:])    # hon
print(s[:])     # Python
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
k = 3
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
Nothing lost, nothing duplicated.
```python
Splitting at k
s[:k] + s[k:]: Equals s for any k.
s[-3:]: The last three characters.
```

## Slide 12
The step: s[start:stop:step]
The third number sets the stride.
`step.py`
```python
s = "abcdefgh"
print(s[0:8:2])   # aceg
print(s[::2])     # aceg
print(s[::-1])    # hgfedcba
```
```python
The step
Default: 1 - every character.
Step 2: Every second character.
Step -1: Walks backwards: s[::-1] reverses s.
```
```python
s[::2]
```
```python
a
```
```python
b
```
```python
c
```
```python
d
```
```python
e
```
```python
f
```
```python
g
```
```python
h
```
```python
a
```
```python
c
```
```python
e
```
```python
g
```
```python
s[::-1]
```
```python
a
```
```python
b
```
```python
c
```
```python
d
```
```python
e
```
```python
f
```
```python
g
```
```python
h
```
```python
h
```
```python
g
```
```python
f
```
```python
e
```
```python
d
```
```python
c
```
```python
b
```
```python
a
```

## Slide 13
Strings are immutable
What does this program print?
`immutable.py`
```python
s = "Python"
s[0] = "J"
print(s)
```
```python
terminal
```
```python
TypeError: 'str' object does not support item assignment
```
```python
s
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
TypeError
```
```python
Why
Immutable: A string cannot be changed after it is created.
Like int, float, bool : None of them can be changed.
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 14
Every change produces a new string.
`fixed.py`
```python
s = "Python"
print(id(s))
s = "J" + s[1:]
print(id(s))
print(s)
```
```python
terminal
```
```python
9644448
140243618509296
Jython
```
```python
s
```
```python
J
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
old
new
```python
What id shows
id(x) : Identifies the object x refers to.
Different id : A different object: a new string.
```
Strings are immutable

## Slide 15
How text is stored
Inside a computer everything is binary. So how is text stored?
what you see
what is stored
what the
hardware holds
```python
H
```
```python
i
```
```python
72
```
```python
105
```
```python
1001000
```
```python
1101001
```
```python
ש
```
```python
ל
```
```python
ו
```
```python
ם
```
```python
1513
```
```python
1500
```
```python
1493
```
```python
1501
```
```python
"שלום"
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
Text is numbers,
with a lookup
table on top.
Character sets
Character set: A table - every character gets a number.
ASCII (1963): 128 codes, English only.
Unicode: Every writing system. Starts with ASCII.
Python: Strings are Unicode. Hebrew works like English.
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 16
Crossing between the two: ord and chr
Two built-in functions, one in each direction.
`ord_chr.py`
```python
print(ord("A"))     # 65
print(ord("א"))     # 1488
print(chr(97))      # 'a'
print(chr(1488))    # 'א'

print(chr(ord("a") + 1))    # 'b'
print(ord("e") - ord("a"))  # 4
```
chr(ord(c)) is always c.
```python
a
```
```python
97
```
```python
ord →
```
```python
← chr
```
```python
a
```
```python
97
```
```python
0
```
```python
b
```
```python
98
```
```python
1
```
```python
c
```
```python
99
```
```python
2
```
```python
d
```
```python
100
```
```python
3
```
```python
e
```
```python
101
```
```python
4
```
```python
…
```
```python
…
```
```python
…
```
```python
x
```
```python
120
```
```python
23
```
```python
y
```
```python
121
```
```python
24
```
```python
z
```
```python
122
```
```python
25
```
code
position
Letters are numbered consecutively.
ord(ch) - ord("a") gives the position, 0 to 25.

## Slide 17
String operators we already know
Some are new today; some you have used since lecture 1-2.
```python
+
```
concatenation
```python
*
```
repetition
```python
[ ]
```
indexing
```python
[ : : ]
```
slicing
`operators.py`
```python
s = "Python"
print("ab" + "cd")      # abcd
print("ab" * 3)         # ababab
print(s[0], s[-1])      # P n
print(s[1:5])           # ytho
```
The new ones today: in, not in and the comparisons.
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 18
Membership: in & not in
```python
The in operator answers the question: Is one string inside another? 
Boolean operators: the result is True or False, as in lecture 1-2.
```
`membership.py`
```python
print("y" in "Python")       # True
print("z" in "Python")       # False
print("tho" in "Python")     # True
print("q" not in "Python")   # True
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
"tho" matches, so the result is True.
```python
in
```
```python
not in
```

## Slide 19
Class exercise
Task: Given a string, count how many vowels it contains.
```python
Two different types of in
in as a part of a for header: Part of the loop syntax.
in an a part of an expression: An operator that returns True or False.
```
`vowels.py`
```python
word = input("Enter a string:")
count = 0
for ch in word:        # loop syntax
    if ch in "aeiou":  # operator
         count += 1
```
```python
2
```
```python
1
```

## Slide 20
Comparing strings
Character by character, from the left. The result is True or False.
`compare.py`
```python
name = input("Name: ")
if name == "Omer":
    print("Hello!")
print("apple" < "banana")   # True
print("car" < "cart")      # True
```
```python
a
```
```python
p
```
```python
p
```
```python
l
```
```python
e
```
```python
b
```
```python
a
```
```python
n
```
```python
a
```
```python
n
```
```python
a
```
Decided at the first difference: a before b.
```python
c
```
```python
a
```
```python
r
```
```python
c
```
```python
a
```
```python
r
```
```python
t
```
A prefix comes first: "car" < "cart".
Comparison operators:
```python
==
```
equal
```python
!=
```
not equal
```python
<
```
less
```python
<=
```
less
or equal
```python
>
```
greater
```python
>=
```
greater
or equal

## Slide 21
Why capitals come first
Characters are compared by their codes.
`compare.py`
```python
print("Zebra" < "apple")    # True
```
```python
Z
```
```python
e
```
```python
b
```
```python
r
```
```python
a
```
```python
90
```
```python
101
```
```python
98
```
```python
114
```
```python
97
```
```python
a
```
```python
p
```
```python
p
```
```python
l
```
```python
e
```
```python
97
```
```python
112
```
```python
112
```
```python
108
```
```python
101
```
```python
90 < 97
```
```python
Upper and lower case
Codes: A–Z: 65–90. a–z: 97–122.
Result: Capitals sort before lowercase.
Not a dictionary: "Alphabetical" can surprise you.
```
Open question
How do we compare while ignoring case?

## Slide 22
The empty string
"" is a string of length 0.
`empty.py`
```python
name = input("Name: ")
if name:
    print("Hello,", name)
else:
    print("You didn't type anything.")
```
```python
len = 0
```
```python
H
```
```python
i
```
```python
len = 2
```
```python
When it appears
From input(): The user pressed Enter without typing.
In a condition: "" is False; any other string is True.
Short form: if name: means 
  if name != "":
```

## Slide 23
String methods
A method is an action called directly on a value.
`method.py`
```python
s = "Python"
print(s.upper())    # PYTHON
print(s.lower())    # python
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
.upper()
```
s.upper(): returns a copy of s in uppercase
```python
What is a method ?
Bound to objects: A method is a function tied directly to a specific data type (like strings)
Dot syntax (.): value.method(), asking the value to perform an action using its own data.
Parentheses: Required to call it.
Coming up: How methods differ from functions.
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
.lower()
```
s.lower(): returns a copy of s in lowercase
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 24
Common string methods
The first seven return a string or a number; the last four return a bool.
method
what it does
example
```python
.upper()
```
Returns a copy with every letter made a capital.
```python
"Hello".upper()   # "HELLO"
```
```python
.lower()
```
Returns a copy with every letter made small.
```python
"Hello".lower()   # "hello"
```
```python
.strip()
```
Returns a copy without the spaces at the two ends.
```python
"  hi  ".strip()  # "hi"
```
```python
.replace(old, new)
```
Returns a copy with every old swapped for new.
```python
"all".replace("l","L")  # "aLL"
```
```python
.count(sub)
```
Counts how many times sub appears (an int).
```python
"Hello".count("l")  # 2
```
```python
.find(sub)
```
Position where sub first appears, or -1 if absent.
```python
"Hello".find("z")  # -1
```
```python
.index(sub)
```
Same as find, but stops the program if sub is absent.
```python
"Hello".index("l")  # 2
```
```python
.islower()
```
True if every letter is small (and there is a letter).
```python
"abc".islower()  # True
```
```python
.isupper()
```
True if every letter is a capital.
```python
"ABC".isupper()  # True
```
```python
.isdigit()
```
True if every character is a digit 0-9.
```python
"2026".isdigit()  # True
```
```python
.isalpha()
```
True if every character is a letter.
```python
"Hi5".isalpha()  # False
```

## Slide 25
Functions vs. methods
Both take inputs and return a result. They differ in where they live.
```python
a
```
```python
b
```
```python
c
```
```python
len
```
```python
a
```
```python
b
```
```python
c
```
```python
.upper()
```
function
method
how it is called
```python
len(s)
```
```python
s.upper()
```
where it lives
on its own
inside a type
works on
often many types
only its own type
Function: the value goes inside. Method: before the dot.
```python
Rule of thumb (A tendency, not a law)
Many types: Usually a function: len, print, str.
One type: Usually a method: .upper() is only for strings.
```

## Slide 26
A method belongs to its data type
Python enforces where a method lives.
`errors.py`
```python
x = 5
x.upper()     # AttributeError
upper("hi")   # NameError
```
`arguments.py`
```python
s = "Hello"
s.count("l")          # 2
s.replace("l", "L")   # 'HeLLo'
```
The value before the dot is the first input.
```python
5
```
```python
int
```
!
```python
'int' object has no attribute 'upper'
```
An int has no such tool.
```python
upper
```
```python
name 'upper' is not defined
```
No such function.
```python
H
```
```python
e
```
```python
l
```
```python
l
```
```python
o
```
```python
.count()
```
```python
"l"
```
the value acted on
the argument

## Slide 27
The immutability trap
Predict the output
`trap.py`
```python
s = "  hello  "
s.strip()
print(s)
```
```python
Discarded
The new string is built and dropped.
s is unchanged.
```
```python
Kept
s = s.strip() rebinds s to the result.
```
Why?
As mentioned earlier, string is immutable, so it cannot be changed.
```python
# result discarded
# "  hello  "
```
```python
s = s.strip()
print(s)
```
```python
# result kept
# "hello"
```

## Slide 28
Counting a character, revisited
The same count, as a loop and as a method.
`count_loop.py`
```python
count = 0
for ch in word:
    if ch == target:
        count += 1
```
`count_method.py`
```python
count = word.count(target)
```
Both are correct.
```python
Loop or method?
.count(): How many times a substring appears.
The loop: Handles any condition you can write.
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 29
Removing the vowels
Task: Given a string, print it without any vowels. 
The idea: Using the accumulator pattern on strings.
`vowels.py`
```python
word = input("Enter a word: ")
result = ""
for ch in word:
    if ch not in "aeiou":
        result += ch
print(result)
```
example gives xmpl.
```python
e
```
```python
x
```
```python
a
```
```python
m
```
```python
p
```
```python
l
```
```python
e
```
```python
not in "aeiou"
```
```python
x
```
```python
m
```
```python
p
```
```python
l
```
Vowels are skipped; the rest are appended.
```python
The accumulator, for strings
1 · Initialize: result = ""
2 · Update: result += ch
3 · Use: print(result)
```

## Slide 30
continue: skipping one iteration
```python
break leaves the loop. continue leaves the current pass.
```
`vowels_if.py`
```python
for ch in word:
    if ch not in "aeiou":
        result += ch
```
`vowels_continue.py`
```python
for ch in word:
    if ch in "aeiou":
        continue
    result += ch
```
```python
for ch in word:
```
```python
if ch in "aeiou":
```
```python
    continue
```
```python
result += ch
```
the loop ends normally
```python
break
```
```python
continue
```
```python
break vs. continue
break: Exits the loop.
continue: Skips to the next item.
When to use it: Many cases to skip, or a long body. Otherwise a plain if is clearer.
```

## Slide 31
Palindrome recognition: revisited
`palindrome.py`
```python
word = input("Enter a word: ")
if word == word[::-1]:
    print(word, "is a palindrome")
else:
    print(word, "is not a palindrome")
```
```python
One line
word[::-1]: The word reversed.
==: Compares it with the original.
```
```python
r
```
```python
a
```
```python
c
```
```python
e
```
```python
c
```
```python
a
```
```python
r
```
```python
r
```
```python
a
```
```python
c
```
```python
e
```
```python
c
```
```python
a
```
```python
r
```
racecar: every pair matches.
```python
s
```
```python
e
```
```python
a
```
```python
s
```
```python
s
```
```python
a
```
```python
e
```
```python
s
```
seas: the second pair differs.
Task: Given a string, check if it is a palindrome (reads the same forwards and backwards).
The idea: reverse the input string and compare to the original.
word
Reversed word
word
Reversed word

## Slide 32
Class exercise: the Caesar cipher
Shift every lowercase letter a fixed number of places.
```python
terminal
```
```python
Message: hello, world
Shift: 3
khoor, zruog
```
Five questions, in pairs
1
Loop and build a new string?
2
```python
Is ch a lowercase letter?
```
3
Letter → position 0 to 25?
4
Shift, wrapping from z to a?
5
Position → letter?
```python
a
```
```python
d
```
```python
b
```
```python
e
```
```python
c
```
```python
f
```
```python
d
```
```python
g
```
```python
e
```
```python
h
```
```python
f
```
```python
i
```
```python
g
```
```python
j
```
```python
h
```
```python
k
```
```python
i
```
```python
l
```
```python
j
```
```python
m
```
```python
k
```
```python
n
```
```python
l
```
```python
o
```
```python
m
```
```python
p
```
```python
n
```
```python
q
```
```python
o
```
```python
r
```
```python
p
```
```python
s
```
```python
q
```
```python
t
```
```python
r
```
```python
u
```
```python
s
```
```python
v
```
```python
t
```
```python
w
```
```python
u
```
```python
x
```
```python
v
```
```python
y
```
```python
w
```
```python
z
```
```python
x
```
```python
a
```
```python
y
```
```python
b
```
```python
z
```
```python
c
```
outer: plain
inner: shift 3
```python
x
```
```python
23
```
```python
26
```
```python
0
```
```python
a
```
Test first: xyz with shift 3 must give abc.

## Slide 33
The Caesar cipher: one solution
`caesar.py`
```python
text = input("Message: ")
shift = int(input("Shift: "))
result = ""
for ch in text:
    if ch.islower():
        position = ord(ch) - ord("a")
        position = (position + shift) % 26
        result += chr(position + ord("a"))
    else:
        result += ch
print(result)
```
1
2
3
4
5
```python
Decryption
Shift -3: Run it on khoor, zruog: the original comes back.
Why: -3 % 26 is 23. % keeps the result in 0 to 25.
```
```python
If you finish early
Uppercase: A second branch, with ord("A").
ROT13: Shift 13, twice, gives the original. Why?
```

## Slide 34
Lecture summary
```python
Strings as sequences
A sequence
Numbered from 0. len(s) counts it.
Slicing and Indexing
s[i], s[start:stop:step]
Immutability
Every "change" builds a new string.
Unicode
Characters are numbers.
```
```python
Working with strings
Functions 
  len, id, ord, chr
Operators
[], [::], in, not in and comparison operators.
Methods
upper, lower, strip, find, replace, count…
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 35
Self practice
Write a program for each of these.
```python
Initials
Read a first and last name and print the initials. Use .find() to locate the space.
```
Palindrome, the hard way
Ignore case, spaces and punctuation, so "Rise to vote, sir" counts.
Count the doubles
Count how many times a letter is followed by the same letter.
The middle
Print the middle character of a word — or the middle two, if its length is even.

## Slide 36
PYTHON COURSE · WEEK 3 · LECTURE 2
Next: Lists and Tuples
Sequences that can be changed


---

# Lecture 3-2: Approximation algorithms (week 3)

## Slide 1: Approximation Algorithms
√
PYTHON COURSE · WEEK 4 · LECTURE 1
Approximation Algorithms
Computing approximate answers
Reichman University

## Slide 2: Why approximate?
Why approximate?
Some answers cannot be computed exactly.
Square roots: √2 = 1.41421356…, with endless digits
Equations: x = cos(x) has a solution, but no formula for it
Floats: a fixed number of digits, so results are rounded

## Slide 3: What “close enough” means
What “close enough” means
Guess: g, the current estimate
Tolerance: ε, the allowed error
Stopping rule: stop when |g · g − x| < ε
The answer: a number g with g · g close to x

## Slide 4: The problem
The problem
Input and output.
Input: a number x ≥ 0, and a tolerance ε > 0
Output: a number g such that |g · g − x| < ε

## Slide 5: Three algorithms, one problem
Three algorithms, one problem
Same problem, three methods, different running times.
Sequential search
try every candidate
Bisection
halve the interval
Newton–Raphson
follow the tangent
From about 30,000 steps down to 3.

## Slide 6: Sequential search
Sequential search
Goal: find √16. Try g = 1.0, 1.25, 1.5, … until g · g is close to 16.
1.0
2.0
3.0
4.0
start: g = 1.0
stop when |g · g − 16| < ε
Every step costs one multiplication and one comparison.

## Slide 7: Sequential search: the idea
Sequential search: the idea
In pseudocode
set g to 1.0
while g · g is not close enough:
increase g by increment
report g
Two parameters
epsilon: how close is close enough
increment: how big a step to take

The rest of the algorithm is fixed.

## Slide 8: Sequential search: the program
Sequential search: the program
```python
python sqrt_sequential.py
3.9988 in 29988 steps
```
`sqrt_sequential.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon:
    g = g + increment
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```
[LIVE] the file is in “week 4 code / sqrt_sequential.py”.

## Slide 9: Reading the loop
Reading the loop
`sqrt_sequential.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon:
    g = g + increment
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```
epsilon
The allowed error (accuracy).
increment
The step size (speed).
The condition
Loop while the error is too big.

## Slide 10: Sequential search: running time
Sequential search: running time
Accuracy: smaller ε, more accurate answer
Speed: smaller increment, slower program
Cost: fewer than x / increment iterations
In numbers: x = 16 → 29,988 steps; x = 105 → 92,465

## Slide 11: Sequential search: a bug
Sequential search: a bug
Big increment: g jumps past the answer
Infinite loop: the condition stays true forever
The fix: stop once g has passed x
This bug is hard to find.
The program does not crash and prints nothing wrong. It just never stops, and no line is marked as the error.

## Slide 12: Sequential search: bug fixed
Sequential search: bug fixed
`sqrt_sequential_fixed.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon and g <= x:
    g = g + increment
    steps = steps + 1
if g > x:
    print("Use a smaller increment")
else:
    print(f"{round(g, 4)} in {steps} steps")
```
[LIVE] the file is in “week 4 code / sqrt_sequential_fixed.py”.

## Slide 13: Three algorithms, one problem
Three algorithms, one problem
Same problem, three methods, different running times.
Sequential search
try every candidate
Bisection
halve the interval
Newton–Raphson
follow the tangent
From about 30,000 steps down to 3.

## Slide 14: Bisection search
Bisection search
Split the interval in two; keep the half that contains the answer.
g = 8.5
itr 0
g = 4.75
itr 1
g = 2.875
itr 2
the answer, 4
Each step halves the interval.

## Slide 15: Bisection: the idea
Bisection: the idea
In pseudocode
set low to 1.0 and high to x
set g to the midpoint
while g · g is not close enough:
too small? move low up to g
too big? move high down to g
set g to the new midpoint
report g
An assumption
We need two numbers that the answer lies between.

For x ≥ 1, √x is between 1 and x.

For x < 1 this does not hold (an exercise).

## Slide 16: Bisection: the program
Bisection: the program
```python
python sqrt_bisection.py
3.9993 in 11 steps
```
`sqrt_bisection.py`
```python
# Square root of x by bisection (x >= 1)
x = 16
epsilon = 0.01
low = 1.0
high = x
g = (low + high) / 2
steps = 0
while abs(g * g - x) >= epsilon:
    if g * g < x:
        low = g
    else:
        high = g
    g = (low + high) / 2
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```
[LIVE] the file is in “week 4 code / sqrt_bisection.py”.

## Slide 17: Bisection: running time
Bisection: running time
Each iteration halves the search interval.
iteration 0   space = x
iteration 1   space = x / 2
iteration 2   space = x / 4
iteration 3   space = x / 8
iteration k   space = x / 2ᵏ
So k is about log₂(x / ε).
For x = 16 and ε = 0.01: 11 steps. For an x 100 times bigger: about 7 more steps.

## Slide 18: Three algorithms, one problem
Three algorithms, one problem
Same problem, three methods, different running times.
Sequential search
try every candidate
Bisection
halve the interval
Newton–Raphson
follow the tangent
From about 30,000 steps down to 3.

## Slide 19: Newton–Raphson: the idea
Newton–Raphson: the idea
Follow tangent lines down to the solution of f(g) = 0.
g
f(g) = g · g − 16
g₀ = 8
g₁ = 5
g₂ = 4.1
Isaac Newton
(1643–1727)

## Slide 20: Newton–Raphson: convergence
Newton–Raphson: convergence
Every step roughly squares the error.
x = 16, first guess 8
step 0: g = 8,  err 48
step 1: g = 5,  err 9
step 2: g = 4.1,  err 0.81
step 3: g = 4.0012,  err 0.0098
3 steps.
Sequential search needed 29,988 steps and bisection 11, for the same x and ε.

## Slide 21: Newton–Raphson: the formula
Newton–Raphson: the formula
The rule: if g is near a solution of f(x) = 0, g − f(g) / f′(g) is nearer
For √x: f(g) = g · g − x, so f′(g) = 2 · g
The next guess: g − (g · g − x) / (2 · g)
Calculus: the derivative, tangent, convergence and limit grew out of such questions

## Slide 22: Newton–Raphson: why the formula works
Newton–Raphson: why the formula works
The next guess is where the tangent line crosses zero.
The tangent line at gₙ:
L(g) = f(gₙ) + f′(gₙ) · (g − gₙ)

The next guess gₙ₊₁ is where L is 0:
0 = f(gₙ) + f′(gₙ) · (gₙ₊₁ − gₙ)

Solve for gₙ₊₁:
gₙ₊₁ = gₙ − f(gₙ) / f′(gₙ)
gₙ
gₙ₊₁
(gₙ, f(gₙ))

## Slide 23: Newton–Raphson: an example
Newton–Raphson: an example
Find √719, the same as solving x · x − 719 = 0.
The rule for √719
f(x) = x · x − 719
f′(x) = 2 · x

If g is close to √719, then
g − (g · g − 719) / (2 · g)
is closer.
Algorithm
ε = 0.01
g = 719 / 2
while |g · g − 719| > ε:
g = g − (g · g − 719) / (2 · g)
report g

## Slide 24: Newton–Raphson: the program
Newton–Raphson: the program
```python
python sqrt_newton.py
step 1: 5.0
step 2: 4.1
step 3: 4.001219512195122
4.0012 in 3 steps
```
`sqrt_newton.py`
```python
# Square root of x by Newton-Raphson
x = 16
epsilon = 0.01
g = x / 2
steps = 0
while abs(g * g - x) > epsilon:
    g = g - (g * g - x) / (2 * g)
    steps = steps + 1
    print(f"step {steps}: {g}")
print(f"{round(g, 4)} in {steps} steps")
```
[LIVE] the file is in “week 4 code / sqrt_newton.py”.
```python
with x = 105
step 1: 27.25
step 2: 15.551605504587156
step 3: 11.151659989960418
step 4: 10.283649283522411
step 5: 10.247016247636102
10.247 in 5 steps
```

## Slide 25: Three algorithms compared
Three algorithms compared
Same problem, same ε.
Sequential search
Works for any function
Steps up by a fixed increment
Needs nothing but arithmetic
About x / increment steps (linear)
x = 16 → 29,988 steps
Hangs if increment is too large
Bisection
Works for monotonic functions
Halves an interval holding the answer
Needs a bracket to start from
About log₂(x / ε) steps (logarithmic)
x = 16 → 11 steps
Always finishes
Newton–Raphson
Works for continuous, differentiable functions
Follows the tangent to the next guess
Needs the slope of the function
Squares the error each step (the fastest)
x = 16 → 3 steps
A bad first guess can fail

## Slide 26: Beyond square roots
Beyond square roots
Root finding: all three solve f(x) = 0
The pattern: guess, measure error, improve, stop
The trade-off: more assumptions, fewer steps
Used in: optimization, machine learning, graphics, simulation


---

# Week 3 code files

The code files shown in the week 3 lectures.

### `sqrt_bisection.py`
```python
# Square root of x by bisection (x >= 1)
x = 16
epsilon = 0.01
low = 1.0
high = x
g = (low + high) / 2
steps = 0
while abs(g * g - x) >= epsilon:
    if g * g < x:
        low = g
    else:
        high = g
    g = (low + high) / 2
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```

### `sqrt_newton.py`
```python
# Square root of x by Newton-Raphson
x = 16
epsilon = 0.01
g = x / 2
steps = 0
while abs(g * g - x) > epsilon:
    g = g - (g * g - x) / (2 * g)
    steps = steps + 1
    print(f"step {steps}: {g}")
print(f"{round(g, 4)} in {steps} steps")
```

### `sqrt_sequential.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon:
    g = g + increment
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```

### `sqrt_sequential_fixed.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon and g <= x:
    g = g + increment
    steps = steps + 1
if g > x:
    print("Use a smaller increment")
else:
    print(f"{round(g, 4)} in {steps} steps")
```

### `two_roots_bad.py`
```python
# Two square roots: the same loop, twice
epsilon = 0.01
a = 16
g = a / 2
while abs(g * g - a) > epsilon:
    g = g - (g * g - a) / (2 * g)
print(f"root of {a} is about {round(g, 4)}")
b = 105
g = b / 2
while abs(g * g - b) > epsilon:
    g = g - (g * g - b) / (2 * g)
print(f"root of {b} is about {round(g, 4)}")
```


---

# Lecture 4-1: Functions (week 4)

## Slide 1: Functions
f
PYTHON COURSE · WEEK 4 · LECTURE 2
Functions
Naming and reusing code
Reichman University

## Slide 2: The big picture
The big picture
Each layer uses the one below it.
any program you may want to write
functions
conditionals and loops
variables and expressions
values and types
Today: functions.

## Slide 3: The same loop, twice
The same loop, twice
`two_roots_bad.py`
```python
# Two square roots: the same loop, twice
epsilon = 0.01
a = 16
g = a / 2
while abs(g * g - a) > epsilon:
    g = g - (g * g - a) / (2 * g)
print(f"root of {a} is about {round(g, 4)}")
b = 105
g = b / 2
while abs(g * g - b) > epsilon:
    g = g - (g * g - b) / (2 * g)
print(f"root of {b} is about {round(g, 4)}")
```
the file is in “week 4 code / two_roots_bad.py”.

## Slide 4: Why functions
Why functions
Write once: the loop is in one place
Fix once: a fix applies to every call
Readable: my_sqrt(16) says what it does
Reuse it: other programs can call it

## Slide 5: The same loop, named
The same loop, named
```python
python my_sqrt.py
root of 16: 4.0012
root of 105: 10.247
```
`my_sqrt.py`
```python
# The same loop, named once and reused
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```
[LIVE] the file is in “week 4 code / my_sqrt.py”.

## Slide 6: Anatomy of a function
Anatomy of a function
`my_sqrt.py`
```python
# The same loop, named once and reused
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```
def
The keyword that starts a definition.
my_sqrt
The function's name.
(x)
The parameters: the inputs.

## Slide 7: Body and return value
Body and return value
`my_sqrt.py`
```python
# The same loop, named once and reused
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```
The body
The indented block. It runs only when called.
return g
Returns a value and ends the call.
Local names
epsilon and g exist only during the call.

## Slide 8: What a function is
What a function is
Takes: zero, one or more inputs, its arguments
Does: whatever its body says, when it is called
Returns: one value; None if there is no return statement
Hides: its local names and its code from the caller

## Slide 9: A function calling a function
A function calling a function
```python
python hypot.py
4.2426
```
`hypot.py`
```python
# Distance between two points, using my_sqrt
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    return my_sqrt(dx * dx + dy * dy)

print(round(hypot(2, 1, 5, 4), 4))
```
[LIVE] the file is in “week 4 code / hypot.py”.

## Slide 10: Arguments and parameters
Arguments and parameters
Two words for the two sides of a call.
Parameters: the names in the def line
Arguments: the values at the call
Matching: each parameter gets its argument
In order: first argument to first parameter

## Slide 11: Calling a function
Calling a function
A call pauses the caller and runs the function.
main
prints the distance
hypot(2, 1, 5, 4)
computes dx, dy
calls
my_sqrt(18)
runs the loop
calls
Only one function runs at a time. The other two wait.

## Slide 12: Returning from a call
Returning from a call
return sends a value back, and the caller continues.
main
prints the distance
hypot(2, 1, 5, 4)
computes dx, dy
my_sqrt(18)
runs the loop
returns
returns
The returned value replaces the call in the caller's code.

## Slide 13: The order of events
The order of events
Step 1: main starts running
Step 2: main calls hypot and suspends
Step 3: hypot calls my_sqrt and suspends
Step 4: my_sqrt returns; hypot resumes
Step 5: hypot returns; main prints and ends

## Slide 14: Functions: the plan
Functions: the plan
Five parts.
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing with functions

## Slide 15: Calling one function two ways
Calling one function two ways
The problem: sometimes we choose epsilon, usually we do not
Bad solution: two almost identical functions
Python's solution: a default value for epsilon

## Slide 16: Default parameter values
Default parameter values
```python
python my_sqrt_default.py
1.4142156862745099
1.5
1.4142135623746899
```
`my_sqrt_default.py`
```python
# epsilon becomes a parameter, with a default
def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2))
print(my_sqrt(2, 0.5))
print(my_sqrt(2, 1e-9))
```
[LIVE] the file is in “week 4 code / my_sqrt_default.py”.

## Slide 17: Keyword arguments
Keyword arguments
By position: my_sqrt(2, 1e-9), order decides
By name: my_sqrt(x=2, epsilon=1e-9), the call says
Any order: named arguments may come in any order
Why: the call is easier to read

## Slide 18: Calling by name
Calling by name
```python
python keyword_args.py
1.4142135623746899
1.4142135623746899
1.4142135623746899
```
`keyword_args.py`
```python
# Naming the arguments at the call site
def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2, 1e-9))
print(my_sqrt(x=2, epsilon=1e-9))
print(my_sqrt(epsilon=1e-9, x=2))
```
[LIVE] the file is in “week 4 code / keyword_args.py”.

## Slide 19: Type hints
Type hints
`type_hints.py`
```python
# Type hints: what goes in, what comes out
def my_sqrt(x: float, epsilon: float = 0.001) -> float:
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2))
print(my_sqrt(2, 1e-9))
```
[LIVE] the file is in “week 4 code / type_hints.py”.
```python
Parameters
x: float says x is a float.
```
```python
Return value
-> float says it returns a float.
```
Not checked
Python does not enforce hints.
Optional
Later lectures leave them out.

## Slide 20: Functions: the plan
Functions: the plan
Five parts.
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing with functions

## Slide 21: Modularity
Modularity
Dividing a program into named pieces.
Less complexity: each piece can be understood on its own
Less duplication: fewer places for bugs
Testable: a function can be checked by itself
Shareable: two people can write two functions at once

## Slide 22: A library and its user
A library and its user
`mymath.py`
```python
"""A small library of math functions."""

def my_sqrt(x, epsilon=0.001):
    """Return a number whose square is near x."""
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    """Return the distance between two points."""
    return my_sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
```
the library: how it is done.
`main.py`
```python
# Using the library from another file
import mymath

print(mymath.my_sqrt(2))
print(mymath.hypot(2, 1, 5, 4))
```
[LIVE] the user: what is needed.

## Slide 23: Calling syntax
Calling syntax
How you call a function depends on where it is.
Same file: my_sqrt(2), just the name
Another module: mymath.my_sqrt(2)

## Slide 24: The caller's view: a black box
The caller's view: a black box
An API describes what a function does for its caller.
What it is called: the name and its parameters
What it gives back: the value, and what it means
What it assumes: the inputs it will not accept
Not how: the caller does not need the body

## Slide 25: Documenting the API
Documenting the API
```python
help(mymath.my_sqrt)
my_sqrt(x, epsilon=0.001)
    Return a number whose
    square is within
    epsilon of x.
```
`mymath.py`
```python
"""A small library of math functions."""

def my_sqrt(x, epsilon=0.001):
    """Return a number whose square is near x."""
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    """Return the distance between two points."""
    return my_sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
```
the file is in “week 4 code / mymath.py”.

## Slide 26: Stubs first, bodies later
Stubs first, bodies later
```python
python stubs.py
0.0
```
`stubs.py`
```python
# Sketch first: the real bodies come later
def hypot(x1, y1, x2, y2):
    return 0.0

def my_sqrt(x, epsilon=0.001):
    return 0.0

print(hypot(2, 1, 5, 4))
```
the file is in “week 4 code / stubs.py”.

## Slide 27: What makes a good function
What makes a good function
One job: if the name needs “and”, it is two functions
A good name: a verb phrase saying what you get back
Few parameters: many parameters suggest a bad design
A docstring: one sentence saying what it returns

## Slide 28: Functions: the plan
Functions: the plan
Five parts.
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing with functions

## Slide 29: Top-down design
Top-down design
The task: in one sentence, what must the program do?
Split it: name the pieces the task needs
Repeat: split any piece that is still too big
Stop: when every piece is one small job

## Slide 30: A decomposition diagram
A decomposition diagram
A box is a function. An arrow means “calls”.
The task
Given the three corners of a triangle, print its perimeter and say whether it has a right angle.
main
the top-level code
hypot
in mymath
3 calls
perimeter
to write
is_right
to write
my_sqrt
in mymath

## Slide 31: Design before code
Design before code
Signatures: each function's name and parameters
Docstrings: in one sentence, what does it return?
Stubs: placeholder bodies, so the program runs
Bodies last: fill in and test one at a time

## Slide 32: The design, written down
The design, written down
```python
python triangle_design.py
perimeter: 0.0
right angle: False
```
`triangle_design.py`
```python
# The design first: names, parameters, promises
import mymath

def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return 0.0

def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return False

a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```
[LIVE] the file is in “week 4 code / triangle_design.py”.

## Slide 33: Then fill in the bodies
Then fill in the bodies
```python
python triangle.py
perimeter: 12.0
right angle: True
```
`triangle.py`
```python
# The same design, with the bodies filled in
import mymath

def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return a + b + c

def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return abs(a * a + b * b - c * c) < 0.01

a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```
[LIVE] the file is in “week 4 code / triangle.py”.

## Slide 34: Your turn: decompose
Your turn: decompose
Draw the diagram first. No code yet.
The task
Read a whole number n. Print every prime number from 2 to n, and then how many primes there were.
Your steps
1. Name the functions you need.
2. Give each a signature and a docstring.
3. Draw who calls whom.

## Slide 35: Design and AI tools
Design and AI tools
AI tools can now write a function body in seconds.
What they need: a clear name, parameters and docstring
Yours to decide: what the pieces are and how they fit
How you check: test each small function by itself


---

# Lecture 4-2: Lists and tuples (week 4)

## Slide 1
PYTHON COURSE · WEEK 3 · LECTURE 2
Lists and Tuples
Sequences that can be changed

## Slide 2
1
Lists
many values under one name
2
Mutability
a list can be changed - a new idea
3
The toolbox
operators, methods and functions
4
Tuples
a sequence that cannot change
Lecture overview
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 3
Why lists 
`many_vars.py`
```python
sale0 = 24
sale1 = 37
sale2 = 22
sale3 = 40
sale4 = 32
sale5 = 36
```
The problem: Managing 86 variables
Unmanageable Code: Handling 86 distinct variable names is repetitive and error-prone
Dynamic Changes: Opening or closing a branch requires manually re-editing the code (adding or removing variables).
No Iteration: A numbered sequence of variables (sale0, sale1, sale2...) is not a sequence that a computer can easily iterate through with a loop.
How would you compute the total sales?
How would you find the best branch?
How would you count those above average?
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 4
A list
A sequence of values - One name, many values, square brackets, commas between.
`first_list.py`
```python
sales = [24, 37, 22, 40, 32, 36]

print(sales)        # the whole list
print(len(sales))   # 6
```
`list_kinds.py`
```python
names = ["Omer", "Dana", "Yaniv"]
mixed = ["Omer", 21, 92.5, True]
empty = []                 # len 0
```
```python
sales
```
```python
24
```
```python
37
```
```python
22
```
```python
40
```
```python
32
```
```python
36
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
"Omer"
```
```python
21
```
```python
92.5
```
```python
True
```
One picture, four types: a list holds anything.
```python
Three things to notice
len: How many items - as for a string.
print shows brackets: A list as you would type it.
Order is part of it: [24, 37] is not [37, 24].
```
```python
mixed
```

## Slide 5
A list is a sequence
Standard sequence operations apply to both strings and lists.
`sequence_ops.py`
```python
print(sales[0])      # 24
print(sales[-1])     # 36
print(sales[1:4])    # [37, 22, 40]
print(sales[::2])    # [24, 22, 32]
print(22 in sales)   # True
print(sales[6])      # IndexError
```
A slice gives a list; an index gives an item.
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
24
```
```python
37
```
```python
22
```
```python
40
```
```python
32
```
```python
36
```
```python
s = "Python"
```
```python
sales = [24, …]
```
```python
sales[1:4]
```
```python
What transfers, unchanged
Indexing: From 0; negative from the right.
Slicing: Stop excluded, with a step.
in and len : Membership and length.
Past the end: IndexError, as before.
```
```python
[ ]
```
indexing
```python
[ : : ]
```
slicing
```python
in
```
```python
not in
```
```python
s[1:4] 
```
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 6
Looping over a list
Direct vs. Indexed loop
`loop_list.py`
```python
# when you only need the values:
for sale in sales:
    print(sale)

# when you need the position too:
for i in range(len(sales)):
    print("Branch:", i, "sales:", sales[i])
```
By value when the value is all you need,
By position when the index is part of the task.
```python
24
```
```python
37
```
```python
22
```
```python
40
```
```python
32
```
```python
36
```
```python
sale
```
```python
24
```
```python
61
```
```python
83
```
```python
123
```
```python
155
```
```python
191
```
total after each pass — the accumulator, unchanged.
`total.py`
```python
total = 0
for sale in sales:
    total = total + sale
print("Total:", total)    # 191
```

## Slide 7
Concatenation and repetition
Two more operators carry over, with the same meanings.
`plus_times.py`
```python
print(sales + [50])   # one longer list
print([0] * 4)        # [0, 0, 0, 0]
print([1] + [2])      # [1, 2] — not [3]
print(sales + 50)     # TypeError
```
```python
What they mean
+ : A new, longer list - not a sum.
* : A list of a known size.
Type rule: Only a list adds to a list.
```
```python
24
```
```python
37
```
```python
+
```
```python
50
```
```python
=
```
```python
24
```
```python
37
```
```python
50
```
```python
0
```
```python
* 4
```
```python
0
```
```python
0
```
```python
0
```
```python
0
```
```python
+
```
concatenation
```python
*
```
repetition
What is really inside a cell? Later today.

## Slide 8
Lists are mutable
A list can be changed in place (unlike any other data type seen so far).
nums[0] =
A white board is mutable: Its content can be erased and updated directly.
An e-mail already sent is immutable: Changing it means sending a new e-mail.
The core concepts
Mutable: An object whose content can be modified in place (e.g., list).
Immutable: An object whose value cannot be changed after creation (e.g., string, int, float, bool).
`mutable.py`
```python
s = "Python"
s[0] = "J"        # TypeError

nums = [1, 2, 3]
nums[0] = 99      # no error
print(nums)       # [99, 2, 3]
```
Refused on a string. Accepted on a list — the cell simply holds something else.
1
99
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 9
Lists are mutable
Last lecture a change built a new object. Is this the same trick?
`id_same.py`
```python
nums = [1, 2, 3]
print(id(nums))   # 140234618509296
nums[0] = 99
print(id(nums))   # 140234618509296
```
The same number. The very same list.
```python
s
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
J
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
A string: the name is moved to a new object.
```python
nums
```
```python
99
```
```python
2
```
```python
3
```
```python
id: unchanged
```
A list: the name never moves. The boxes change.

## Slide 10
Class exercise - squares
Task: Given a list of numbers, replace every item with its square.
```python
my_list = [4, 2, 5, 7]
for num in my_list:
    num = num ** 2
print(my_list)
```
```python
4
```
```python
2
```
```python
5
```
```python
7
```
```python
num
```
```python
16
```
`squares_fixed.py`
```python
my_list = [4, 2, 5, 7]
for i in range(len(my_list)):
    my_list[i] = my_list[i] ** 2
print(my_list)        # [16, 4, 25, 49]
```
```python
4
```
```python
2
```
```python
5
```
```python
7
```
`squares_broken.py`
Incorrect: The temporary loop variable (num) is squared, but the original list is unaffected.
```python
# [4, 2, 5, 7]
```
✗
Correct: Accessing elements by index allows direct modification of the list’s content.
✓
```python
16
```

## Slide 11
Lists are dynamic
Lists allow you to add and remove elements dynamically
`grow.py`
```python
guests = ["Omer"]
guests.append("Dana")      # add at the end
guests.insert(1, "Yael")   # add at a position
guests.remove("Omer")      # remove by value
last = guests.pop()        # remove & return last
print(guests)              # ['Yael']
```
```python
Some details
.remove(x) : Deletes only the first matching element. If x not found, raises a ValueError.
.pop() : Removes and returns last element.
	    
```
```python
"Omer"
```
```python
.append("Dana")
```
```python
"Omer"
```
```python
"Dana"
```
```python
"Omer"
```
```python
"Dana"
```
```python
0
```
```python
1
```
```python
.insert(1, "Yael")
```
```python
"Omer"
```
```python
"Yael"
```
```python
"Dana"
```
```python
0
```
```python
1
```
```python
2
```
Dana was at 1, and is now at 2: the rest shifts right.
`build_loop.py`
```python
squares = []
for i in range(5):
    squares.append(i * i)
print(squares)      # [0, 1, 4, 9, 16]
```
Accumulator pattern that creates a list

## Slide 12
The trap: changing a list while looping
Task: Given a list, remove every 2 from it.
```python
nums = [1, 2, 2, 3]
for n in nums:
    if n == 2:
        nums.remove(n)
print(nums)
```
```python
What a for loop really does
By position: Even with no index written.
remove shortens it: Under the loop.
```
```python
1
```
```python
2
```
```python
2
```
```python
3
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
1
```
position 0: 1 is not a 2.
```python
1
```
```python
2
```
```python
2
```
```python
3
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
2
```
position 1: a 2 - removed.
```python
1
```
```python
2
```
```python
3
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
2
```
shifted left: the second 2 is now at 1 - behind us.
```python
1
```
```python
2
```
```python
3
```
```python
0
```
```python
1
```
```python
2
```
position 3 is past the end - the loop stops.
The 2 at position 1 was never examined.
What went wrong ?
`remove2_bug.py`
Incorrect: one of the 2s is still in the list.
✗
```python
# [1, 2, 3]
```

## Slide 13
Two fixes — is each one right?
Same task: remove every 2.
`remove2_v1.py`
```python
nums = [1, 2, 2, 3]
kept = []
for n in nums:
    if n != 2: kept.append(n)
print(kept)
```
```python
# [1, 3]
```
✓
correct
Nothing is removed, so the list being walked never changes.
`remove2_v2.py`
```python
nums = [1, 2, 2, 3]
for n in nums[:]:   # walk a copy
    if n == 2: nums.remove(n)
print(nums)
```
```python
# [1, 3]
```
✓
correct
```python
nums[:] is a copy: the loop walks the copy, and we edit the original.
```

## Slide 14
Another fix - without a copy
Can it be done without a second copy of the list?
`remove_while.py`
```python
nums = [1, 2, 2, 3]
i = 0
while i < len(nums):
    if nums[i] == 2:
        nums.pop(i) # remove by position                    
        # do not advance i
    else: i = i + 1
```
```python
Why it works
Ours to advance: A while loop does not.
Remove, and stay: The next item slid in.
```
```python
1
```
```python
2
```
```python
2
```
```python
3
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
2
```
i = 1: a 2 — pop(1), and i stays 1.
```python
1
```
```python
2
```
```python
3
```
```python
0
```
```python
1
```
```python
2
```
```python
2
```
i = 1 again: another 2 — pop(1), i stays.
```python
1
```
```python
3
```
```python
0
```
```python
1
```
```python
3
```
i = 1: a 3 — now i becomes 2.
```python
1
```
```python
3
```
```python
0
```
```python
1
```
i = 2 = len(nums): the loop stops.
The result is [1, 3]: nothing skipped, no copy made.
.pop(i): the method from the table, with a position.

## Slide 15
Assigning lists using = operator
Predict: what is lst1, after the third line?
`alias.py`
```python
lst1 = [1, 2, 3]
lst2 = lst1
lst2.append(4)

print(lst1)
print(lst1 is lst2)
```
lst2 = lst1 gives the list labled as lst1 a second name
but doesn’t create a second list.
```python
lst1
```
```python
lst2
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
1
```
```python
2
```
```python
3
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
lst1
```
```python
lst2
```
What you might expect – but it is not what happens.
```python
# [1, 2, 3, 4]
```
```python
# True
```
✗
```python
The is operator
a is b: Are a and b the same object?
	Equivalent to id(a) == id(b).
a == b: Do a and b have same values?
```
What it really looks like: One list, two names. Either name can change it.
✓
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 16
Making a real copy
If two names is not what you want, ask for a copy.
`copy_list.py`
```python
lst1 = [1, 2, 3]
lst3 = lst1.copy()            # or list(lst1)

print(lst1 == lst3)       # True   - same values
print(lst1 is lst3)       # False  - different objects

lst3.append(5)
print(lst1)            # [1, 2, 3]
```
A slice of everything — which by definition is a new list.
```python
lst1
```
```python
1
```
```python
2
```
```python
3
```
```python
lst3
```
```python
1
```
```python
2
```
```python
3
```
```python
5
```
```python
lst1 == lst3  True
```
```python
lst1 is lst3  False
```
Equal, but not identical
Copy first: If you need the original as well.
Otherwise share: Copying a large list costs time.

## Slide 17
What is inside a cell
A cell holds a reference to a value, not the value itself.
`inside_cell.py`
```python
nums = [10, 20, 30]    # an ordinary list
x = nums[0]            # a second name
print(x is nums[0])    # True

nums[0] = 99           # re-point the cell
print(nums)            # [99, 20, 30]
print(x)               # 10  — still the 10
```
Assignment to an item changes the list, never the object it held.
```python
0
```
```python
↓
```
```python
1
```
```python
↓
```
```python
2
```
```python
nums
```
```python
10
```
```python
20
```
```python
30
```
three separate objects
```python
x
```
x is nums[0] — the same object
```python
99
```
Cell 0 now refers to a different object. The 10 is still there, unchanged — which is why x still prints 10.
```python
↓
```

## Slide 18
```python
And under the * operator
```
```python
So what does [0] * 4 actually build?
```
`star_cells.py`
```python
a = [0] * 4

print(a[0] is a[1])   # True

a[0] = 5
print(a)              # [5, 0, 0, 0]
```
Sharing is invisible while the value cannot change.
```python
↓
```
```python
↓
```
```python
↓
```
```python
↓
```
```python
a
```
```python
0
```
one object, four cells
```python
5
```
a[0] = 5 re-points one cell

## Slide 19
Why this matters
Three consequences, and one promise.
```python
Three consequences
A change through one name
is visible through every name: a feature with one shared list, a bug when you thought you had two.
Equality and identity
are different questions. == for values, is for objects.
Strings never posed this
because a string cannot be changed, so aliasing one is invisible.
```
```python
1
```
```python
2
```
```python
3
```
```python
def  ?
```
Next week: a list passed to a function can be changed by it.

## Slide 20
```python
+= and *= operators
```
In-place modification vs. Reassignment
```python
+ and * build a new list
```
```python
+= and *= modify the existing object in-place
```
`new_list.py`
```python
a = [1, 2, 3]
b = a
a = a + [4]

a = [1, 2]
b = a
a = a * 3
```
`in_place.py`
```python
a = [1, 2, 3]
b = a
a += [4]

a = [1, 2]
b = a
a *= 3
```
```python
1
```
```python
2
```
```python
3
```
```python
a
```
```python
b
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
b
```
```python
1
```
```python
2
```
```python
3
```
```python
a
```
```python
4
```
```python
1
```
```python
2
```
```python
a
```
```python
b
```
```python
1
```
```python
2
```
```python
1
```
```python
2
```
```python
1
```
```python
2
```
```python
b
```
```python
1
```
```python
2
```
```python
a
```
```python
1
```
```python
2
```
```python
1
```
```python
2
```
```python
+=
```
```python
*=
```
```python
+
```
```python
*
```

## Slide 21
Common list methods
method
what it does
example
```python
.append(x)
```
Adds x at the end of the list.
```python
a.append(4)
```
```python
.insert(i, x)
```
Puts x at position i, shifts the rest right. ; error for invalid index.
```python
a.insert(0, 9)
```
```python
.remove(x)
```
Removes the first x; error if there is none.
```python
a.remove(2)
```
```python
.pop(i)
```
Removes the item in index and returns it; error for invalid index.
When called with no parameters (.pop()) – 
Removes the last item and returns it. 
```python
last = a.pop()
first = a.pop(0)
```
```python
.index(x)
```
Position where x first appears; error if absent.
```python
a.index(3)
```
```python
.count(x)
```
How many times x appears, as an int.
```python
a.count(2)
```
```python
.sort()
```
Puts the list in order, in place.
```python
a.sort()
```
```python
.reverse()
```
Turns the list back to front, in place.
```python
a.reverse()
```
All change the list and return nothing — except .pop, .index and .count, which answer a question.
```python
.copy()
```
Creates a shallow copy of the list and returns it.
```python
b = a.copy()
```
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 22
Built-in functions that work on lists
Functions, not methods: the list goes inside the parentheses.
`builtins.py`
```python
print(len(sales))     # 6
print(sum(sales))     # 191
print(min(sales))     # 22
print(max(sales))     # 40
print(sorted(sales))  # a new list
print(sales)          # unchanged
```
```python
24
```
```python
37
```
```python
22
```
```python
40
```
```python
32
```
```python
36
```
```python
min, max and sorted work on strings too: sorted("banana") is a list of its letters, in order.
```
```python
sales
```
```python
len
```
```python
6
```
```python
sum
```
```python
191
```
```python
min
```
```python
22
```
```python
max
```
```python
40
```
```python
sorted
```
```python
22
```
```python
24
```
```python
32
```
```python
36
```
```python
37
```
```python
40
```

## Slide 23
The sort trap
```python
Methods that modify mutable objects in place, return None.
```
`sort_trap.py`
```python
nums = [3, 1, 2]
nums.sort()
print(nums)        # [1, 2, 3]
result = nums.sort()
print(result)      # None

nums = [3, 1, 2]
result = sorted(nums)
print(result)      # [1, 2, 3]
print(nums)        # [3, 1, 2]  unchanged
```
```python
.sort()
```
```python
None
```
Modified in place
```python
3
```
```python
1
```
```python
2
```
```python
sorted()
```
```python
1
```
```python
2
```
```python
3
```
Returns a new list - must be assigned
```python
In-place vs. Returning functions\methods
In-place modification: If a method modifies the original object directly, it returns None. 
New object creation: If an operation cannot or does not modify the original, it returns a new object.
General rule : Applies across all mutable data types in Python.
```
```python
1
```
```python
2
```
```python
3
```
```python
3
```
```python
1
```
```python
2
```

## Slide 24
The split method
A string method that converts a single string into a list of substrings.
`split.py`
```python
line = "Omer Dana Yaniv"
print(line.split())      # ['Omer', 'Dana', 'Yaniv']

print("24,37,22".split(","))
# ['24', '37', '22']   — on a given separator

print(list('hello'))     # one item per character
```
 Splitting options: default whitespace, explicit delimiter or char-by-char via list()
```python
"Omer"
```
```python
"Dana"
```
```python
"Yaniv"
```
Returns a list of strings
`split_cast.py`
```python
parts = "24,37,22".split(",")
total = 0
for p in parts:
    total += int(p)    # 83
```
Always returns strings; explicit type casting (e.g., int()) is required for numeric processing
```python
O
```
```python
m
```
```python
e
```
```python
r
```
```python
␣
```
```python
D
```
```python
a
```
```python
n
```
```python
a
```
```python
␣
```
```python
Y
```
```python
a
```
```python
n
```
```python
i
```
```python
v
```
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 25
The join method
A string method that concatenates a list of strings into a single string using a delimiter.
`join.py`
```python
names = ["Omer", "Dana", "Yaniv"]
print(' '.join(names))    # 'Omer Dana Yaniv'
print(', '.join(names))   # 'Omer, Dana, Yaniv'
print("-".join(["22", "09", "2026"])) # '22-09-2026'
```
```python
Read it as: "delimiter ".join(list) – use this separator to glue these items together.
```
```python
"Omer"
```
```python
"Dana"
```
```python
"Yaniv"
```
```python
The core rules
Separator syntax: .join() is called on the delimiter string, not on the list                         (e.g., " ".join(names), not names.join(" ")).
Every item must be a string: Other types raise a TypeError.
split and join: Inverse operations - cut, work, glue.
```
```python
O
```
```python
m
```
```python
e
```
```python
r
```
```python
␣
```
```python
D
```
```python
a
```
```python
n
```
```python
a
```
```python
␣
```
```python
Y
```
```python
a
```
```python
n
```
```python
i
```
```python
v
```

## Slide 26
Worked example: counting words
Task: Given a sentence, count its words and determine the longest word.
```python
The idea: .split() gives the words, len() counts them, then the maximum-pattern loop.
```
`word_count.py`
```python
sentence = input("Sentence: ")
words = sentence.split()
print("Words:", len(words))

longest = words[0]
for word in words:
    if len(word) > len(longest):
        longest = word
print("Longest:", longest)
```
```python
the
```
```python
quick
```
```python
brown
```
```python
elephant
```
```python
ran
```
```python
elephant
```
longest, after the last pass
word
len
longest
```python
the
```
```python
3
```
```python
the
```
```python
quick
```
```python
5
```
```python
quick
```
```python
brown
```
```python
5
```
```python
quick
```
```python
elephant
```
```python
8
```
```python
elephant
```
```python
ran
```
```python
3
```
```python
elephant
```
`word_count.py`
```python
sentence = input("Sentence: ")
words = sentence.split()
print("Words:", len(words))
if len(words) > 0:
    longest = words[0]
    for word in words:
        if len(word) > len(longest):
            longest = word
    print("Longest:", longest)
```
```python
What if the user typed nothing (just Enter)?
words list is empty, so words[0] raises an IndexError.
How to avoid it ?
Check if len(words) > 0 before accessing index 0.
```

## Slide 27
The sales report, finished
Task: Total, average, best branch, how many above average.
The idea: one pass to total, a second pass to count.
`sales_report.py`
```python
sales = [24, 37, 22, 40, 32, 36]
total = sum(sales)
average = total / len(sales)
best = max(sales)
best_branch = sales.index(best)
above = 0
for sale in sales:
    if sale > average: above = above + 1
```
```python
24
```
```python
37
```
```python
22
```
```python
40
```
```python
32
```
```python
36
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
average
```
```python
output
```
```python
Total: 191
Average: 31.833333333333332
Best region: 3 with 40
Regions above average: 4
```

## Slide 28
Class exercise: Reordering by a permutation
```python
Task: build a new list of the items of my_list in the order per dictates.
```
```python
The idea: per holds a permutation of the indices. Each value of per is a position in my_list.
```
`permutation.py`
```python
my_list = [100, 23, 43, 12]
per = [2, 3, 0, 1]

result = []
for i in per:
    result.append(my_list[i])

print(result)    # [43, 12, 100, 23]
```
Indirect iteration (Index-as-Data)
Values as indices: The elements of per serve as indices rather than raw data values.
Indirect lookup : The loop variable i represents a valid index used access my_list[i].
```python
Accumulator pattern: result dynamically grows from empty with .append.
```

## Slide 29
Class exercise: Collapsing repeated runs
Task: Collapse consecutive duplicate items into a single instance
```python
10
```
```python
10
```
```python
10
```
```python
5
```
```python
5
```
```python
6
```
```python
6
```
```python
6
```
```python
6
```
```python
7
```
```python
2
```
```python
2
```
```python
2
```
```python
10
```
```python
10
```
```python
10
```
```python
5
```
```python
6
```
```python
7
```
```python
2
```
```python
10
```
```python
10
```
```python
10
```
The idea: Append an item only if it differs from the last item already added.
`collapse_runs.py`
```python
list2 = [list1[0]]
for elem in list1:
    if elem != list2[-1]:
        list2.append(elem)
```
```python
Key points
list2[-1] : Accesses the last appended item.
Seeded initialization: list2 is initialized with one item (list1[0]) to safely allow list2[-1] access without raising an IndexError on an empty list. 
```

## Slide 30
A tuple
An immutable sequence of values - Round brackets, commas between, fixed once created. Provides storage for heterogeneous data.
`tuple_basics.py`
```python
point = (3, 4)
student = ("Dana Levi", 012345678"", 88)

print(point[0])      # 3
print(len(point))    # 2
print(3 in point)    # True
print(student[0:2])  # ("Data Levi", 012345678"")

point[0] = 5         # TypeError
student.append(5)      # AttributeError
```
```python
Syntax: Round brackets () instead of square [].
Functions, methods and operators: Indexing, slicing, in, len, count, +, * and other read only sequence operations.
```
```python
3
```
```python
4
```
```python
x
```
```python
y
```
```python
(3, 4)
```
```python
"Dana Levi"
```
```python
"012345678"
```
```python
88
```
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 31
string, list or tuple: how to choose?
str
list
tuple
How it is written
```python
"Hi"
```
```python
[1, 2]
```
```python
(1, 2)
```
What it holds
characters
any values 
(usually homogeneous)
any values
(usually heterogeneus)
Can be changed (Mutable)
✗
✓
✗
Methods that change it
none
```python
.append .sort ...
```
none
Indexing, slicing, in, len, for
the same
the same
the same
Its size
fixed
dynamic
fixed
Choose a list when
Homogeneous collection: Storing sequence items of the same conceptual type (e.g., branches, scores, words).
Mutability required: Add, remove or sort in-place.
Dynamic size: Collection length changes over time.
Choose a tuple when
Heterogeneous collection: Grouping fixed attributes of a single entity (e.g., (x,y) coordinates, date, student's record).
Immutability guarantee: Preventing accidental modifications.

## Slide 32
Class exercise: how immutable is immutable?
Predict the output:
`tuple_with_list.py`
```python
my_tuple = ("Bennie", 47,
            ["Bernard", "Aaliyah"])
my_tuple[2].append("Sydney")
print(my_tuple)
```
```python
The core principle: Shallow immutability
A tuple guarantees its own shape: How many items, and which objects they refer to.
It guarantees nothing about what those objects contain. If an element in a tuple is mutable (e.g., a list), the underlying object itself can still be mutated in-place.
Reassignment vs. Mutation: 
my_tuple[2].append(...) mutates the inner object (allowed).
my_tuple[2] = [] attempts to reassign the tuple’s reference (TypeError).
```
```python
# ('Bennie', 47,
```
```python
#  ['Bernard', 'Aaliyah', 'Sydney'])
```
```python
my_tuple[2] = []
```
```python
                      # TypeError
```
```python
my_tuple
```
```python
0
```
```python
1
```
```python
2
```
```python
"Bennie"
```
```python
47
```
```python
"Bernard"
```
```python
"Aaliyah"
```
```python
"Sydney"
```
```python
list
```
```python
int
```
```python
string
```

## Slide 33
Packing & unpacking
The feature that makes tuples worth their slide.
`pack-unpack.py`
```python
point = 3, 4      # packing
x, y = point      # unpacking
print(x, y)       # 3 4

# unpacking lists
data = "Elazar Haim Ruti"
name1, name2, name3 = data.split()
```
```python
3
```
```python
4
```
```python
3
```
```python
4
```
```python
point
```
packing: the comma builds one tuple
```python
3
```
```python
4
```
```python
x
```
```python
y
```
unpacking: one name per item

## Slide 34
The swap, two ways
The same exchange, with a temporary variable or with packing & unpacking.
`swap_temp.py`
```python
x, y = 3, 4

temp = x
x = y
y = temp
print(x, y)       # 4 3
```
`swap.py`
```python
3
```
```python
4
```
```python
4
```
```python
3
```
packing
```python
4
```
```python
3
```
unpacking
x
y
x
y
```python
x, y = y, x       # the swap: packing & unpacking
print(x, y)       # 4 3
```
```python
x
```
```python
y
```
```python
temp
```
```python
3
```
```python
4
```
```python
—
```
```python
x, y = 3, 4
```
```python
3
```
```python
4
```
```python
3
```
```python
temp = x
```
```python
4
```
```python
4
```
```python
3
```
```python
x = y
```
```python
4
```
```python
3
```
```python
3
```
```python
y = temp
```

## Slide 35
```python
"Yael Bar"
```
Class exercise: Parallel lists
Task: Maintain dynamic student records (name, ID, grade) through additions and deletions.
`parallel_lists.py`
```python
names = ["Dana Levi", "Ron Cohen", "Yael Bar"]
ids = ["012345678", "305128744", "211980365"]
grades = [88, 95, 73]

print(names[1], ids[1], grades[1])
# Ron Cohen 305128744 95
```
`parallel_lists.py`
```python
names.remove("Ron Cohen")   # a student leaves
print(names[1], ids[1], grades[1])
# Yael Bar 305128744 95
```
```python
"Dana Levi"
```
```python
"Ron Cohen"
```
```python
"Yael Bar"
```
```python
"012345678"
```
```python
"305128744"
```
```python
"211980365"
```
```python
88
```
```python
95
```
```python
73
```
```python
names
```
```python
ids
```
```python
grades
```
```python
"Dana Levi"
```
Structural flaws
Manual sync required: Adding or removing data requires modifying three separate lists in exact order. 
Index shift: Deleting an element from one list shifts its indices, causing complete cross-list misalignment. 
The requirement: We need a single atomic structure that binds related fields together. 
Desynchronization error: Yael Bar now pairs with Ron Cohen's ID and grade

## Slide 36
```python
"Dana Levi"
```
```python
"012345678"
```
```python
88
```
```python
0
```
```python
"Yael Bar"
```
```python
"211980365"
```
```python
73
```
```python
1
```
Class exercise: The solution - a list of tuples
`List_of_tuples.py`
```python
students = [("Dana Levi", "012345678", 88),
            ("Ron Cohen", "305128744", 95),
            ("Yael Bar", "211980365", 73)]

print(students[1])  # ('Ron Cohen ', '305128744', 95)
```
```python
"Dana Levi"
```
```python
"012345678"
```
```python
88
```
```python
0
```
```python
"Ron Cohen"
```
```python
"305128744"
```
```python
95
```
```python
1
```
```python
"Yael Bar"
```
```python
"211980365"
```
```python
73
```
```python
2
```
```python
students
```
Atomic record benefits
Encapsulation: Name, ID, and grade are coupled into a single, inseparable tuple.
Safe Operations: Adding or removing an entry affects the entire tuple, preventing partial shifts or mismatched fields.
Immutability: Tuple immutability guarantees that fields within a record cannot be accidentally mixed up.
Task: Maintain dynamic student records (name, ID, grade) through additions and deletions.
`List_of_tuples.py`
```python
students.pop(1)   # Ron Cohen leaves
print(students[1]) # ('Yael Bar ', '211980365', 73)
```

## Slide 37
Class exercise: Processing records
Task: Print the name and grade of the student with the highest score.
The idea: apply maximum finding pattern to track the top record.
`top_student.py`
```python
students = [("Dana Levi", "012345678", 88),
            ("Ron Cohen", "305128744", 95),
            ("Yael Bar", "211980365", 73)]

best = students[0]
for student in students:
    if student[2] > best[2]:
        best = student
name, sid, grade = best   # unpacking
print(name, grade)        # Ron Cohen 95
```
```python
"Dana Levi"
```
```python
"012345678"
```
```python
88
```
```python
0
```
```python
"Ron Cohen"
```
```python
"305128744"
```
```python
95
```
```python
1
```
```python
"Yael Bar"
```
```python
"211980365"
```
```python
73
```
```python
2
```
```python
students
```
```python
best
```
No shortcuts for maximum
Finding the maximum requires going through every student.

## Slide 38
Task: Find and print Ron Cohen's grade (by name).
`find_student.py`
```python
for name, sid, grade in students:
    if name == "Ron Cohen":
        print(grade)          # 95
        break
```
The goal: Access records directly by name without intermediate position searches.
Coming up in Week 5 ...
```python
"Dana Levi"
```
```python
"012345678"
```
```python
88
```
```python
0
```
```python
"Ron Cohen"
```
```python
"305128744"
```
```python
95
```
```python
1
```
```python
"Yael Bar"
```
```python
"211980365"
```
```python
73
```
```python
2
```
✗
✓
Finding a record by name – the cost
Unlike finding a maximum, accessing one student shouldn’t require looking at others.
Lists only support positional indices, forcing us to scan items sequentially.
Absent target forces an unnecessary pass through the entire list
Class exercise: Looking up a record by name
name
position
value
a middleman step we never wanted
```python
students
```

## Slide 39
Lecture summary
```python
The new ideas
A list
a mutable sequence of elements (usually homogeneous)
Lists are mutable
a[0] = x, the methods and += change the list itself.
b = a does not copy
one list, two names; a[:] copies it.
A cell holds a reference
re-points the cell, not the object.
A tuple
an immutable sequence of elements (usually heterogeneous)
```
Working with lists & tuples
```python
list
```
```python
tuple
```
Operators
```python
[], [:], in, +, *
+= and *=
```
```python
[], [:], in, +, *
+= rebinds, as on a string
```
```python
join, packing,
unpacking
```
Functions
```python
len, sum, min, max
sorted
```
```python
len, sum, min, max
sorted
```
Methods
```python
append, insert, remove
pop, sort, reverse
index, count
```
```python
index, count
```
More
```python
split, join, unpacking
```
Lists
Operators
Mutability
Aliasing
Methods & Built-ins
Strings & lists
Tuples

## Slide 40
PYTHON COURSE · WEEK 4 · LECTURE 1
Next: Functions
Naming a piece of work, and reusing it


---

# Week 4 code files

The code files shown in the week 4 lectures.

### `hypot.py`
```python
# Distance between two points, using my_sqrt
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    return my_sqrt(dx * dx + dy * dy)

print(round(hypot(2, 1, 5, 4), 4))
```

### `keyword_args.py`
```python
# Naming the arguments at the call site
def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2, 1e-9))
print(my_sqrt(x=2, epsilon=1e-9))
print(my_sqrt(epsilon=1e-9, x=2))
```

### `main.py`
```python
# Using the library from another file
import mymath

print(mymath.my_sqrt(2))
print(mymath.hypot(2, 1, 5, 4))
```

### `my_sqrt.py`
```python
# The same loop, named once and reused
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```

### `my_sqrt_default.py`
```python
# epsilon becomes a parameter, with a default
def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2))
print(my_sqrt(2, 0.5))
print(my_sqrt(2, 1e-9))
```

### `mymath.py`
```python
"""A small library of math functions."""

def my_sqrt(x, epsilon=0.001):
    """Return a number whose square is near x."""
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    """Return the distance between two points."""
    return my_sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
```

### `stubs.py`
```python
# Sketch first: the real bodies come later
def hypot(x1, y1, x2, y2):
    return 0.0

def my_sqrt(x, epsilon=0.001):
    return 0.0

print(hypot(2, 1, 5, 4))
```

### `triangle.py`
```python
# The same design, with the bodies filled in
import mymath

def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return a + b + c

def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return abs(a * a + b * b - c * c) < 0.01

a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```

### `triangle_design.py`
```python
# The design first: names, parameters, promises
import mymath

def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return 0.0

def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return False

a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```

### `type_hints.py`
```python
# Type hints: what goes in, what comes out
def my_sqrt(x: float, epsilon: float = 0.001) -> float:
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2))
print(my_sqrt(2, 1e-9))
```
