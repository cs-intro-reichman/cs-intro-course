# Lecture 3-1: Strings (week 3)

## Slide 1
INTRO TO CS COURSE · WEEK 3 · LECTURE 1
Strings
Indexing, slicing, immutability and methods

## Slide 2
Lecture overview
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples
1
Basics
characters in a row, numbered from 0
2
Indexing and slicing
one character, or a piece
3
Immutability
every change builds a new string
4
Methods
upper, strip, find, replace — and the cipher

## Slide 3
Writing a string
Single or double quotes: the result is the same.
`quotes.py`
```python
a = "double quotes"
b = 'single quotes'
c = "it's fine inside double quotes"
d = 'and "quotes" inside single ones'
```
PEP 8 has no preference. Be consistent.
```python
Escape sequences
\n : A new line.
\" and \' : A quote that does not end the string.
\\ : One backslash.
```
`print.py`
```python
print("I don't like\nthe word \"no\"")
```
```python
\
```
```python
n
```
typed
```python
?
```
stored
As how many characters?
```python
terminal
```
```python
I don't like
the word "no"
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 4
A string is a sequence of characters
Every character in the sequence has a position (index), starting with 0.
```python
A
```
```python
s
```
```python
␣
```
```python
e
```
```python
a
```
```python
s
```
```python
y
```
```python
␣
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
7
```
```python
len(s) = 8
```
```python
last position = len(s) - 1 = 7
```
`len.py`
```python
print(len(s))      # 8
print(len("Hi"))   # 2
print(len(""))     # 0
```
```python
↵
```
```python
len("\n") = 1
```
```python
A new built-in function: len
len(s) : The number of characters, as an int.
Same family: print, input, int, str: the name, then the value in parentheses.
Spaces count: A string holds exactly what is between the quotes.
Last position: len(s) - 1, since positions start at 0.
```
Each character is itself a number — later in this lecture.

## Slide 5
Direct iteration over strings
A for loop iterates over any sequence, including strings. 
`letters.py`
```python
for ch in "binary":
    print(ch)
```
```python
output
```
```python
b
i
n
a
r
y
```
```python
b
```
```python
i
```
```python
n
```
```python
a
```
```python
r
```
```python
y
```
One character at a time, in order.
```python
Already known
Direct iteration: for ch in s visits every character from left to right (Lecture 2-2).
Limitations: Does not allow picking a specific index (e.g. the 5th or last character) or iterating in a custom order.
```
```python
b
```
```python
i
```
```python
n
```
```python
a
```
```python
r
```
```python
y
```

## Slide 6
The questions we ask about text
Before the tools: what do we actually want to ask?
```python
A
```
```python
A
```
```python
T
```
```python
T
```
```python
T
```
```python
G
```
```python
C
```
```python
A
```
```python
T
```
```python
T
```
```python
C
```
```python
dna = "AATTTGCATTC"
```
What is at
position 4?
Does "TGC" appear anywhere?
What are the last three bases?
How many times does "T" appear?
Where does "G" first appear?
Are these two
sequences equal?
Do they match if we ignore case?
Does "C?T" appear, 
if ? is any base?

## Slide 7
Indexing
```python
s[i] is the character at position i.
```
`index.py`
```python
s = "Python"
print(s[0])    # P
print(s[5])    # n
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
IndexError
```
What comes back
A string of length 1: There is no separate character type.
```python
One past the end
Valid indices: 0 to len(s) - 1.
s[len(s)]: Raises an IndexError.
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples
```python
s[0]
```
```python
s[5]
```
```python
s[6]
```

## Slide 8
Negative indices
A negative index counts from the end, starting at -1.
`negative.py`
```python
s = "Python"
print(s[-1])   # n
print(s[-2])   # o
print(s[-6])   # P
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
-6
```
```python
-5
```
```python
-4
```
```python
-3
```
```python
-2
```
```python
-1
```
```python
Why negative indices?
s[-1]: The last character, in the usual form.
s[len(s) - 1]: The same character, longer to write and easier to get wrong.
No -0: Index 0 is always the first character.
```
Two numbering systems, one row of boxes.

## Slide 9
Example: is it a palindrome?
Task: Given a string, check if it is a palindrome (reads the same forwards and backwards).
The idea: compare the first and last characters, then move inward.
`palindrome_idx.py`
```python
word = input("Enter a word: ")
palindrome = True
for i in range(len(word) // 2):
    if word[i] != word[-1 - i]:
        palindrome = False
        break
if palindrome:
    print(word, "is a palindrome")
else:
    print(word, "is not a palindrome")
```
```python
r
```
```python
a
```
```python
c
```
```python
e
```
```python
c
```
```python
a
```
```python
r
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
-7
```
```python
-6
```
```python
-5
```
```python
-4
```
```python
-3
```
```python
-2
```
```python
-1
```
```python
e
```
```python
0 ↔ -1
```
```python
1 ↔ -2
```
```python
2 ↔ -3
```
```python
How it works
Pairs: word[i] and word[-1 - i].
Half the word: The middle has no partner.
Mismatch: break stops the loop.
```

## Slide 10
Slicing: s[start:stop]
Creates a new string from start up to, but not including, stop.
`slice.py`
```python
s = "As easy "
print(s[1:5])   # s ea
print(s[0:2])   # As
```
```python
A
```
```python
s
```
```python
␣
```
```python
e
```
```python
a
```
```python
s
```
```python
y
```
```python
␣
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
7
```
```python
5 - 1 = 4 characters
```
```python
s
```
```python
␣
```
```python
e
```
```python
a
```
A new string, four characters long.
```python
The half-open convention
As in range(): Stop is excluded.
Length: s[a:b] has b - a characters.
A copy: s is unchanged.
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples
```python
s[1:5]
```

## Slide 11
Omitting a bound
No start: from the beginning. No stop: to the end.
`bounds.py`
```python
s = "Python"
print(s[:3])    # Pyt
print(s[3:])    # hon
print(s[:])     # Python
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
k = 3
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
Nothing lost, nothing duplicated.
```python
Splitting at k
s[:k] + s[k:]: Equals s for any k.
s[-3:]: The last three characters.
```
```python
s[:3]
```
```python
s[3:]
```

## Slide 12
The step: s[start:stop:step]
The third number sets the stride.
`step.py`
```python
s = "abcdefgh"
print(s[0:8:2])   # aceg
print(s[::2])     # aceg
print(s[::-1])    # hgfedcba
```
```python
The step
Default: 1 - every character.
Step 2: Every second character.
Step -1: Walks backwards: s[::-1] reverses s.
```
```python
a
```
```python
b
```
```python
c
```
```python
d
```
```python
e
```
```python
f
```
```python
g
```
```python
h
```
```python
a
```
```python
c
```
```python
e
```
```python
g
```
```python
a
```
```python
b
```
```python
c
```
```python
d
```
```python
e
```
```python
f
```
```python
g
```
```python
h
```
```python
h
```
```python
g
```
```python
f
```
```python
e
```
```python
d
```
```python
c
```
```python
b
```
```python
a
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
7
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
```python
6
```
```python
7
```
```python
s[0:8:2] (same as s[::2])
```
```python
s[::-1]
```

## Slide 13
Strings are immutable
What does this program print?
`immutable.py`
```python
s = "Python"
s[0] = "J"
print(s)
```
```python
terminal
```
```python
TypeError: 'str' object does not support item assignment
```
```python
s
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
TypeError
```
```python
Why
Immutable: A string cannot be changed after it is created.
Like int, float, bool : None of them can be changed.
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples
```python
J
```

## Slide 14
Every change produces a new string.
`fixed.py`
```python
s = "Python"
print(id(s))
s = "J" + s[1:]
print(id(s))
print(s)
```
```python
terminal
```
```python
9644448
140243618509296
Jython
```
```python
s
```
```python
J
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
old
new
```python
What id shows
id(x) : Identifies the object x refers to.
Different id : A different object: a new string.
```
Strings are immutable

## Slide 15
How text is stored
Inside a computer everything is binary. So how is text stored?
what you see
what is stored
what the
hardware holds
```python
H
```
```python
i
```
```python
72
```
```python
105
```
```python
1001000
```
```python
1101001
```
```python
ש
```
```python
ל
```
```python
ו
```
```python
ם
```
```python
1513
```
```python
1500
```
```python
1493
```
```python
1501
```
```python
"שלום"
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
Text is numbers,
with a lookup
table on top.
Character sets
Character set: A table - every character gets a number.
ASCII (1963): 128 codes, English only.
Unicode: Every writing system. Starts with ASCII.
Python: Strings are Unicode. Hebrew works like English.
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 16
Crossing between the two: ord and chr
Two built-in functions, one in each direction.
`ord_chr.py`
```python
print(ord("A"))     # 65
print(ord("א"))     # 1488
print(chr(97))      # 'a'
print(chr(1488))    # 'א'

print(chr(ord("a") + 1))    # 'b'
print(ord("e") - ord("a"))  # 4
```
chr(ord(c)) is always c.
```python
a
```
```python
97
```
```python
ord →
```
```python
← chr
```
```python
a
```
```python
97
```
```python
0
```
```python
b
```
```python
98
```
```python
1
```
```python
c
```
```python
99
```
```python
2
```
```python
d
```
```python
100
```
```python
3
```
```python
e
```
```python
101
```
```python
4
```
```python
…
```
```python
…
```
```python
…
```
```python
x
```
```python
120
```
```python
23
```
```python
y
```
```python
121
```
```python
24
```
```python
z
```
```python
122
```
```python
25
```
code
position
Letters are numbered consecutively.
ord(ch) - ord("a") gives the position, 0 to 25.

## Slide 17
String operators we already know
Some are new today; some you have used since lecture 1-2.
```python
+
```
concatenation
```python
*
```
repetition
```python
[ ]
```
indexing
```python
[ : : ]
```
slicing
`operators.py`
```python
s = "Python"
print("ab" + "cd")      # abcd
print("ab" * 3)         # ababab
print(s[0], s[-1])      # P n
print(s[1:5])           # ytho
```
The new ones today: in, not in and the comparisons.
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 18
Membership: in & not in
```python
The in operator answers the question: Is one string inside another? 
Boolean operators: the result is True or False, as in lecture 1-2.
```
`membership.py`
```python
print("y" in "Python")       # True
print("z" in "Python")       # False
print("tho" in "Python")     # True
print("q" not in "Python")   # True
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
5
```
"tho" matches, so the result is True.
```python
in
```
```python
not in
```

## Slide 19
Class exercise
Task: Given a string, count how many vowels it contains.
```python
Two different types of in
in as a part of a for header: Part of the loop syntax.
in an a part of an expression: An operator that returns True or False.
```
`count_vowels.py`
```python
word = input("Enter a string:")
count = 0
for ch in word:        # loop syntax
    if ch in "aeiou":  # operator
         count += 1
```
```python
2
```
```python
1
```

## Slide 20
Comparing strings
Character by character, from the left. The result is True or False.
`compare.py`
```python
name = input("Name: ")
if name == "Omer":
    print("Hello!")
print("apple" < "banana")   # True
print("car" < "cart")      # True
```
```python
a
```
```python
p
```
```python
p
```
```python
l
```
```python
e
```
```python
b
```
```python
a
```
```python
n
```
```python
a
```
```python
n
```
```python
a
```
Decided at the first difference: a before b.
```python
c
```
```python
a
```
```python
r
```
```python
c
```
```python
a
```
```python
r
```
```python
t
```
A prefix comes first: "car" < "cart".
Comparison operators:
```python
==
```
equal
```python
!=
```
not equal
```python
<
```
less
```python
<=
```
less
or equal
```python
>
```
greater
```python
>=
```
greater
or equal

## Slide 21
Why capitals come first
Characters are compared by their codes.
`compare_case.py`
```python
print("Zebra" < "apple")    # True
```
```python
Z
```
```python
e
```
```python
b
```
```python
r
```
```python
a
```
```python
90
```
```python
101
```
```python
98
```
```python
114
```
```python
97
```
```python
a
```
```python
p
```
```python
p
```
```python
l
```
```python
e
```
```python
97
```
```python
112
```
```python
112
```
```python
108
```
```python
101
```
```python
90 < 97
```
```python
Upper and lower case
Codes: A–Z: 65–90. a–z: 97–122.
Result: Capitals sort before lowercase.
Not a dictionary: "Alphabetical" can surprise you.
```
Open question
How do we compare while ignoring case?

## Slide 22
The empty string
"" is a string of length 0.
`empty.py`
```python
name = input("Name: ")
if name:
    print("Hello,", name)
else:
    print("You didn't type anything.")
```
```python
len = 0
```
```python
H
```
```python
i
```
```python
len = 2
```
```python
When it appears
From input(): The user pressed Enter without typing.
In a condition: "" is False; any other string is True.
Short form: if name: means 
  if name != "":
```

## Slide 23
String methods
A method is an action called directly on a value.
`method.py`
```python
s = "Python"
print(s.upper())    # PYTHON
print(s.lower())    # python
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
.upper()
```
s.upper(): returns a copy of s in uppercase
```python
What is a method ?
Bound to objects: A method is a function tied directly to a specific data type (like strings)
Dot syntax (.): value.method(), asking the value to perform an action using its own data.
Parentheses: Required to call it.
Coming up: How methods differ from functions.
```
```python
P
```
```python
y
```
```python
t
```
```python
h
```
```python
o
```
```python
n
```
```python
.lower()
```
s.lower(): returns a copy of s in lowercase
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 24
Common string methods
The first seven return a string or a number
method
what it does
example
```python
.upper()
```
Returns a copy with every letter made a capital.
```python
"Hello".upper()   # "HELLO"
```
```python
.lower()
```
Returns a copy with every letter made small.
```python
"Hello".lower()   # "hello"
```
```python
.strip()
```
Returns a copy without the spaces at the two ends.
```python
"  hi  ".strip()  # "hi"
```
```python
.replace(old, new)
```
Returns a copy with every old swapped for new.
```python
"all".replace("l","L")  # "aLL"
```
```python
.count(sub)
```
Counts how many times sub appears (an int).
```python
"Hello".count("l")  # 2
```
```python
.find(sub)
```
Position where sub first appears, or -1 if absent.
```python
"Hello".find("z")  # -1
```
```python
.index(sub)
```
Same as find, but stops the program if sub is absent.
```python
"Hello".index("l")  # 2
```
```python
.islower()
```
True if every letter is small (and there is a letter).
```python
"abc".islower()  # True
```
```python
.isupper()
```
True if every letter is a capital.
```python
"ABC".isupper()  # True
```
```python
.isdigit()
```
True if every character is a digit 0-9.
```python
"2026".isdigit()  # True
```
```python
.isalpha()
```
True if every character is a letter.
```python
"Hi5".isalpha()  # False
```
; the last four return a bool.

## Slide 25
Functions vs. methods
Both take inputs and return a result. They differ in where they live.
```python
a
```
```python
b
```
```python
c
```
```python
len
```
```python
a
```
```python
b
```
```python
c
```
```python
.upper()
```
function
method
how it is called
```python
len(s)
```
```python
s.upper()
```
where it lives
on its own
inside a type
works on
often many types
only its own type
Function: the value goes inside. Method: before the dot.
```python
Rule of thumb (A tendency, not a law)
Many types: Usually a function: len, print, str.
One type: Usually a method: .upper() is only for strings.
```

## Slide 26
A method belongs to its data type
Python enforces where a method lives.
`errors.py`
```python
x = 5
x.upper()     # AttributeError
```
`arguments.py`
```python
s = "Hello"
s.count("l")          # 2
s.replace("l", "L")   # 'HeLLo'
```
The value before the dot is the first input.
```python
5
```
```python
int
```
!
```python
'int' object has no attribute 'upper'
```
An int has no such tool.
```python
upper
```
```python
name 'upper' is not defined
```
No such function.
```python
H
```
```python
e
```
```python
l
```
```python
l
```
```python
o
```
```python
.count()
```
```python
"l"
```
the value acted on
the argument
```python
upper("hi")   # NameError
```

## Slide 27
The immutability trap
Predict the output
`trap.py`
```python
s = "  hello  "
s.strip()
print(s)
```
```python
Discarded
The new string is built and dropped.
s is unchanged.
```
```python
Kept
s = s.strip() rebinds s to the result.
```
Why?
As mentioned earlier, string is immutable, so it cannot be changed.
```python
# result discarded
# "  hello  "
```
```python
s = s.strip()
print(s)
```
```python
# result kept
# "hello"
```

## Slide 28
Counting a character, revisited
The same count, as a loop and as a method.
`count_loop.py`
```python
count = 0
for ch in word:
    if ch == target:
        count += 1
```
`count_method.py`
```python
count = word.count(target)
```
Both are correct.
```python
Loop or method?
.count(): How many times a substring appears.
The loop: Handles any condition you can write.
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 29
Removing the vowels
Task: Given a string, print it without any vowels (‘a’, ‘e’, ‘i’, ‘o’, ‘u’). 
The idea: Using the accumulator pattern on strings.
`remove_vowels.py`
```python
word = input("Enter a word: ")
result = ""
for ch in word:
    if ch not in "aeiou":
        result += ch
print(result)
```
```python
e
```
```python
x
```
```python
a
```
```python
m
```
```python
p
```
```python
l
```
```python
e
```
```python
not in "aeiou"
```
```python
x
```
```python
m
```
```python
p
```
```python
l
```
Vowels are skipped; the rest are appended.
```python
The accumulator, for strings
1 · Initialize: result = ""
2 · Update: result += ch
3 · Use: print(result)
```

## Slide 30
continue: skipping one iteration
```python
continue ends the current pass and goes straight on to the next item.
```
`vowels_if.py`
```python
for ch in word:
    if ch not in "aeiou":
        result += ch
```
`vowels_continue.py`
```python
for ch in word:
    if ch in "aeiou":
        continue
    result += ch
```
```python
another ch?
```
```python
True
```
```python
ch in "aeiou"
```
```python
True
```
```python
False
```
```python
continue
```
```python
result += ch
```
```python
print(result)
```
```python
False
```
What continue does
Ends this pass. Nothing after it runs for this item.
Takes the next item. As if the pass had finished.
The loop is untouched. Only the body is skipped.
```python
Same answer as the plain if. It earns its place when there are many cases to skip, or the body is long.
```

## Slide 31
break vs. continue
```python
The same loop, with break where continue was. Predict the output.
```
`vowels_break.py`
```python
word = input()
result ="" 

for ch in word:
    if ch in "aeiou":
        break
    result += ch
print(result)
```
```python
"programming"  →  "pr"
"python"  →  "pyth"
"example"  →  ""
```
```python
another ch?
```
```python
True
```
```python
ch in "aeiou"
```
```python
True
```
```python
False
```
```python
break
```
```python
result += ch
```
```python
print(result)
```
```python
False
```
```python
Output
Everything before the first vowel. The first vowel ends the loop.
Nothing at all if the word starts with a vowel: break can end the loop before the body runs once.
With continue, every vowel is skipped and the rest is appended.
```

## Slide 32
Palindrome recognition: revisited
`palindrome.py`
```python
word = input("Enter a word: ")
if word == word[::-1]:
    print(word, "is a palindrome")
else:
    print(word, "is not a palindrome")
```
```python
One line
word[::-1]: The word reversed.
==: Compares it with the original.
```
```python
r
```
```python
a
```
```python
c
```
```python
e
```
```python
c
```
```python
a
```
```python
r
```
```python
r
```
```python
a
```
```python
c
```
```python
e
```
```python
c
```
```python
a
```
```python
r
```
Every pair matches.
```python
s
```
```python
e
```
```python
a
```
```python
s
```
```python
s
```
```python
a
```
```python
e
```
```python
s
```
The second pair differs.
Task: Given a string, check if it is a palindrome (reads the same forwards and backwards).
The idea: reverse the input string and compare to the original.
word
Reversed word
word
Reversed word

## Slide 33
Class exercise: the Caesar cipher
Task: Shift every lowercase letter of a given string a fixed number of places.
```python
terminal
```
```python
Message: hello, world
Shift: 3
khoor, zruog
```
Algorithm:
1
Initialize: Create an empty string.
2
Loop over input's characters one by one:
2,1
Check if character is a lower case letter. If it is:
Shift letter position, wrapping from 25 to 0
2.2
Append character to new string.
```python
a
```
```python
d
```
```python
b
```
```python
e
```
```python
c
```
```python
f
```
```python
d
```
```python
g
```
```python
e
```
```python
h
```
```python
f
```
```python
i
```
```python
g
```
```python
j
```
```python
h
```
```python
k
```
```python
i
```
```python
l
```
```python
j
```
```python
m
```
```python
k
```
```python
n
```
```python
l
```
```python
o
```
```python
m
```
```python
p
```
```python
n
```
```python
q
```
```python
o
```
```python
r
```
```python
p
```
```python
s
```
```python
q
```
```python
t
```
```python
r
```
```python
u
```
```python
s
```
```python
v
```
```python
t
```
```python
w
```
```python
u
```
```python
x
```
```python
v
```
```python
y
```
```python
w
```
```python
z
```
```python
x
```
```python
a
```
```python
y
```
```python
b
```
```python
z
```
```python
c
```
outer: plain
inner: shift 3
```python
x
```
```python
23
```
```python
26
```
```python
0
```
```python
a
```
Test first: xyz with shift 3 must give abc.
Convert letter to position 0 to 25
2,1.1
2,1.2
Convert back from position to letter
2,1.3

## Slide 34
The Caesar cipher: one solution
`caesar.py`
```python
text = input("Message: ")
shift = int(input("Shift: "))
result = ""
for ch in text:
    if ch.islower():
        position = ord(ch) - ord("a")
        position = (position + shift) % 26
        ch = chr(position + ord("a"))
    result += ch
print(result)
```
1
2
2.1
2.1.1
2.1.2
```python
Decryption
Shift -3: Run it on khoor, zruog: the original comes back.
Why: -3 % 26 is 23. % keeps the result in 0 to 25.
```
```python
If you finish early
Uppercase: A second branch, with ord("A").
ROT13: Shift 13, twice, gives the original. Why?
```
2.1.3
2.2

## Slide 35
Lecture summary
```python
Strings as sequences
A sequence
Numbered from 0. len(s) counts it.
Slicing and Indexing
s[i], s[start:stop:step]
Immutability
Every "change" builds a new string.
Unicode
Characters are numbers.
```
```python
Working with strings
Functions 
  len, id, ord, chr
Operators
[], [::], in, not in and comparison operators.
Methods
upper, lower, strip, find, replace, count…
```
Basics
Indexing & slicing
Immutability
Unicode
Operators
Methods
Examples

## Slide 36
Self practice
Write a program for each of these.
```python
Initials
Read a first and last name and print the initials. Use .find() to locate the space.
```
Palindrome, the hard way
Ignore case, spaces and punctuation, so "Rise to vote, sir" counts.
Count the doubles
Count how many times a letter is followed by the same letter.
The middle
Print the middle character of a word — or the middle two, if its length is even.

## Slide 37
INTRO TO CS COURSE · WEEK 3 · LECTURE 2
Next: Approximation Algorithms
When exact is impossible


---

# Lecture 3-2: Approximation algorithms (week 3)

## Slide 1: Approximation Algorithms
INTRO TO CS COURSE · WEEK 3 · LECTURE 2
Approximation Algorithms
Computing approximate answers

## Slide 2
Lecture overview
1
Why approximate
answers with no exact formula
2
Sequential search
try every candidate
3
Bisection
halve the interval
4
Newton–Raphson
follow the tangent
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots

## Slide 3: Why approximate?
Why approximate?
Some answers cannot be computed exactly.
Square roots: √2 = 1.41421356…, with endless digits
Equations: x = cos(x) has a solution, but no formula for it
Floats: a fixed number of digits, so results are rounded
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots

## Slide 4: What “close enough” means
What “close enough” means
Guess: g, the current estimate
Tolerance: ε, the allowed error
Stopping rule: stop when |g · g − x| < ε
The answer: a number g with g · g close to x
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots
Say, we would like to calculate √x:

## Slide 5: The problem
The problem
Input and output.
Input: a number x ≥ 0, and a tolerance ε > 0
Output: a number g such that |g · g − x| < ε
```python
x = 16
```
```python
ε = 0.01
```
```python
g = 3.9988
```

## Slide 6: Three algorithms, one problem
Three algorithms, one problem
Same problem, three methods, different running times.
Sequential search
try every candidate
Bisection
halve the interval
Newton–Raphson
follow the tangent
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots

## Slide 7: Sequential search
Sequential search
Goal: find √16. Try g = 1.0, 1.25, 1.5, … until g · g is close to 16.
1.0
2.0
3.0
4.0
start: g = 1.0
stop when |g · g − 16| < ε
Every step costs one multiplication and one comparison.

## Slide 8: Sequential search: the idea
Sequential search: the idea
In pseudocode
set g to 1.0
while g · g is not close enough:
increase g by increment
report g
Two parameters
epsilon: how close is close enough
increment: how big a step to take

The rest of the algorithm is fixed.

## Slide 9: Sequential search: the program
Sequential search: the program
```python
python sqrt_sequential.py
3.9988 in 29988 steps
```
`sqrt_sequential.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon:
    g = g + increment
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```
[LIVE] the file is in “week 3 code / sqrt_sequential.py”.

## Slide 10: Reading the loop
Reading the loop
`sqrt_sequential.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon:
    g = g + increment
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```
epsilon
The allowed error (accuracy).
increment
The step size (speed).
The condition
Loop while the error is too big.

## Slide 11: Sequential search: running time
Sequential search: running time
Accuracy: smaller ε, more accurate answer
Speed: smaller increment, slower program
Cost: fewer than x / increment iterations
In numbers: x = 16 → 29,988 steps; x = 105 → 92,465

## Slide 12: Sequential search: a bug
Sequential search: a bug
Big increment: g jumps past the answer
Infinite loop: the condition stays true forever
The fix: stop once g has passed x
This bug is hard to find.
The program does not crash and prints nothing wrong. It just never stops, and no line is marked as the error.

## Slide 13: Sequential search: bug fixed
Sequential search: bug fixed
`sqrt_sequential_fixed.py`
```python
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon and g <= x:
    g = g + increment
    steps = steps + 1
if g > x:
    print("Use a smaller increment")
else:
    print(f"{round(g, 4)} in {steps} steps")
```

## Slide 14: Three algorithms, one problem
Three algorithms, one problem
Same problem, three methods, different running times.
Sequential search
try every candidate
Bisection
halve the interval
Newton–Raphson
follow the tangent
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots

## Slide 15: Bisection search
Bisection search
Split the interval in two; keep the half that contains the answer.
g = 8.5
itr 0
g = 4.75
itr 1
g = 2.875
itr 2
the answer, 4
Each step halves the interval.
x = 16 · ε = 0.01  ·  stop when  |g · g − x| < ε
g · g − x = +56.25  →  keep the lower half
g · g − x = +6.56  →  keep the lower half
g · g − x = −7.73  →  keep the upper half
⋮

## Slide 16: Bisection: the idea
Bisection: the idea
In pseudocode
set low to 1.0 and high to x
set g to the midpoint
while g · g is not close enough:
too small? move low up to g
too big? move high down to g
set g to the new midpoint
report g
An assumption
We need two numbers that the answer lies between.

For x ≥ 1, √x is between 1 and x.

For x < 1 this does not hold (an exercise).

## Slide 17: Bisection: the program
Bisection: the program
```python
python sqrt_bisection.py
3.9993 in 11 steps
```
`sqrt_bisection.py`
```python
# Square root of x by bisection (x >= 1)
x = 16
epsilon = 0.01
low = 1.0
high = x
g = (low + high) / 2
steps = 0
while abs(g * g - x) >= epsilon:
    if g * g < x:
        low = g
    else:
        high = g
    g = (low + high) / 2
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")
```

## Slide 18: Bisection: running time
Bisection: running time
Each iteration halves the search interval.
iteration 0   space = x
iteration 1   space = x / 2
iteration 2   space = x / 4
iteration 3   space = x / 8
iteration k   space = x / 2ᵏ
So, in the worst case we keep looking until we get to a space of ε.
That happens when x / 2ᵏ = ε. 
To understand how many iterations we need to run to get there, we can solve for k:
log₂(x / 2ᵏ) = log₂(ε) k = log₂(x) - log₂(ε)For x = 16 and ε = 0.01: 11 steps. For an x 100 times bigger: about 7 more steps.
For x = 16 and ε = 1: 4 steps.

## Slide 19: Three algorithms, one problem
Three algorithms, one problem
Same problem, three methods, different running times.
Sequential search
try every candidate
Bisection
halve the interval
Newton–Raphson
follow the tangent
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots

## Slide 20: Newton–Raphson: the idea
Newton–Raphson: the idea
Calculating √16 is like finding a solution for the equation:
f(g) = g · g − 16 = 0
Isaac Newton
(1643–1727)

## Slide 21: Newton–Raphson: the idea
Newton–Raphson: the idea
Follow tangent lines down to the solution of f(g) = 0.
g
f(g) = g · g − 16
g₀ = 8
g₁ = 5
g₂ = 4.1

## Slide 22: Newton–Raphson: convergence
Newton–Raphson: convergence
Every step roughly squares the error.
x = 16, first guess 8
step 0: g = 8,  err 48
step 1: g = 5,  err 9
step 2: g = 4.1,  err 0.81
step 3: g = 4.0012,  err 0.0098
3 steps.
Sequential search needed 29,988 steps and bisection 11, for the same x and ε.

## Slide 23: Newton–Raphson: the formula
Newton–Raphson: the formula
```python
The rule: if g is near a solution of f(x) = 0, 				then g − f(g) / f′(g) is nearer
For √x: f(g) = g · g − x, so f′(g) = 2 · g
The next guess: g − (g · g − x) / (2 · g)
Calculus: the derivative, tangent, convergence and limit grew out of such questions
```

## Slide 24: Newton–Raphson: why the formula works
Newton–Raphson: why the formula works
The next guess is where the tangent line crosses zero.
```python
The tangent line at gₙ:
L(g) = f(gₙ) + f′(gₙ) · (g − gₙ)

The next guess gₙ₊₁ is where L is 0:
0 = f(gₙ) + f′(gₙ) · (gₙ₊₁ − gₙ)

Solve for gₙ₊₁:
gₙ₊₁ = gₙ − f(gₙ) / f′(gₙ)
```
gₙ
gₙ₊₁
(gₙ, f(gₙ))

## Slide 25: Newton–Raphson: an example
Newton–Raphson: an example
Find √719, the same as solving x · x − 719 = 0.
```python
The rule for √719
f(x) = x · x − 719
f′(x) = 2 · x

If g is close to √719, then
g − (g · g − 719) / (2 · g)
is closer.
```
Algorithm
ε = 0.01
g = 719 / 2
while |g · g − 719| > ε:
g = g − (g · g − 719) / (2 · g)
report g

## Slide 26: Newton–Raphson: the program
Newton–Raphson: the program
```python
python sqrt_newton.py
step 1: 5.0
step 2: 4.1
step 3: 4.001219512195122
4.0012 in 3 steps
```
`sqrt_newton.py`
```python
# Square root of x by Newton-Raphson
x = 16
epsilon = 0.01
g = x / 2
steps = 0
while abs(g * g - x) > epsilon:
    g = g - (g * g - x) / (2 * g)
    steps = steps + 1
    print(f"step {steps}: {g}")
print(f"{round(g, 4)} in {steps} steps")
```
```python
with x = 105
step 1: 27.25
step 2: 15.551605504587156
step 3: 11.151659989960418
step 4: 10.283649283522411
step 5: 10.247016247636102
10.247 in 5 steps
```

## Slide 27: Three algorithms compared
Three algorithms compared
Same problem, same ε.
Sequential search
Works for any function
Steps up by a fixed increment
Needs nothing but arithmetic
About x / increment steps (linear)
x = 16 → 29,988 steps
Hangs if increment is too large
Bisection
Works for monotonic functions
Halves an interval holding the answer
Needs a bracket to start from
About log₂(x / ε) steps (logarithmic)
x = 16 → 11 steps
Always finishes
Newton–Raphson
Works for continuous, differentiable functions
Follows the tangent to the next guess
Needs the slope of the function
Squares the error each step (the fastest)
x = 16 → 3 steps
A bad first guess can fail
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots

## Slide 28: Beyond square roots
Beyond square roots
Root finding: all three solve f(x) = 0
The pattern: guess, measure error, improve, stop
The trade-off: more assumptions, fewer steps
Used in: optimization, machine learning, graphics, simulation
Why approximate
The problem
Sequential search
Bisection search
Newton–Raphson
All three compared
Beyond square roots

## Slide 29: Next: Functions
INTRO TO CS COURSE · WEEK 4 · LECTURE 1
Next: Functions
Naming and reusing code


---

# Week 3 code files

The code files shown in the week 3 lectures.

### `arguments.py`
```python
# lecture 3-1 — arguments.py
s = "Hello"
s.count("l")          # 2
s.replace("l", "L")   # 'HeLLo'

# Prints nothing: both lines are values the REPL would show. .count
# answers 2 and .replace answers 'HeLLo' — and s itself is unchanged.
```

### `bounds.py`
```python
# lecture 3-1 — bounds.py
s = "Python"
print(s[:3])    # Pyt
print(s[3:])    # hon
print(s[:])     # Python

# No start means from the beginning, no stop means to the end, and s[:]
# is the whole string.
```

### `caesar.py`
```python
# lecture 3-1 — caesar.py
text = input("Message: ")
shift = int(input("Shift: "))
result = ""
for ch in text:
    if ch.islower():
        position = ord(ch) - ord("a")
        position = (position + shift) % 26
        ch = chr(position + ord("a"))
    result += ch
print(result)

# $ python caesar.py
# Message: attack at dawn
# Shift: 3
# dwwdfn dw gdzq
```

### `compare.py`
```python
# lecture 3-1 — compare.py
name = input("Name: ")
if name == "Omer":
    print("Hello!")
print("apple" < "banana")   # True
print("car" < "cart")      # True

# $ python compare.py
# Name: Omer
# Hello!
# True
# True
```

### `compare_case.py`
```python
# lecture 3-1 — compare_case.py
print("Zebra" < "apple")    # True

# A capital letter has a smaller code than any small letter, so every word
# that starts with a capital sorts before every word that starts small.
```

### `count_loop.py`
```python
# lecture 3-1 — count_loop.py
word = "Mississippi"   # sample values, so the file runs on its own
target = "s"
count = 0
for ch in word:
    if ch == target:
        count += 1
print(count)

# Counting by hand, one character at a time.
```

### `count_method.py`
```python
# lecture 3-1 — count_method.py
word = "Mississippi"   # sample values, so the file runs on its own
target = "s"
count = word.count(target)
print(count)

# The same count, in one call.
```

### `count_vowels.py`
```python
# lecture 3-1 — count_vowels.py
word = input("Enter a string:")
count = 0
for ch in word:        # loop syntax
    if ch in "aeiou":  # operator
        count += 1
print(count)

# $ python count_vowels.py
# Enter a string:example
# 3
#
# NOTE: the card on the slide stops at count += 1 and never prints the answer,
# and that last line is indented nine spaces instead of eight. Both are fixed
# here; the card wants the same two corrections.
```

### `empty.py`
```python
# lecture 3-1 — empty.py
name = input("Name: ")
if name:
    print("Hello,", name)
else:
    print("You didn't type anything.")

# $ python empty.py
# Name:
# You didn't type anything.
```

### `errors.py`
```python
# lecture 3-1 — errors.py
x = 5
x.upper()     # AttributeError
upper("hi")   # NameError

# ON PURPOSE BROKEN — this is the error demo of the slide.
# x.upper() on an int raises AttributeError, and upper("hi") raises
# NameError: there is no plain function by that name.
```

### `fixed.py`
```python
# lecture 3-1 — fixed.py
s = "Python"
print(id(s))
s = "J" + s[1:]
print(id(s))
print(s)

# The two id() values differ: s = "J" + s[1:] built a new string and
# rebound the name to it. Nothing was changed in place.
```

### `immutable.py`
```python
# lecture 3-1 — immutable.py
s = "Python"
s[0] = "J"
print(s)

# ON PURPOSE BROKEN — this is the error demo of the slide.
# s[0] = "J" raises TypeError: 'str' object does not support item
# assignment. A string cannot be changed in place.
```

### `index.py`
```python
# lecture 3-1 — index.py
s = "Python"
print(s[0])    # P
print(s[5])    # n

# s[i] is the character at position i. The valid indices are 0 to len(s) - 1.
```

### `len.py`
```python
# lecture 3-1 — len.py
s = "As easy "    # the string on this slide, so the file runs on its own
print(len(s))      # 8
print(len("Hi"))   # 2
print(len(""))     # 0

# len() counts characters, not words, and the empty string has length 0.
```

### `letters.py`
```python
# lecture 3-1 — letters.py
for ch in "binary":
    print(ch)

# for ch in s visits the characters in order, without any index.
```

### `membership.py`
```python
# lecture 3-1 — membership.py
print("y" in "Python")       # True
print("z" in "Python")       # False
print("tho" in "Python")     # True
print("q" not in "Python")   # True

# in answers True or False, and it matches a piece as well as one
# character.
```

### `method.py`
```python
# lecture 3-1 — method.py
s = "Python"
print(s.upper())    # PYTHON
print(s.lower())    # python

# A method is called on the value itself: s.upper(), not upper(s).
```

### `negative.py`
```python
# lecture 3-1 — negative.py
s = "Python"
print(s[-1])   # n
print(s[-2])   # o
print(s[-6])   # P

# A negative index counts from the end: -1 is the last character.
```

### `operators.py`
```python
# lecture 3-1 — operators.py
s = "Python"
print("ab" + "cd")      # abcd
print("ab" * 3)         # ababab
print(s[0], s[-1])      # P n
print(s[1:5])           # ytho

# + joins, * repeats, [i] picks one character and [i:j] picks a piece.
```

### `ord_chr.py`
```python
# lecture 3-1 — ord_chr.py
print(ord("A"))     # 65
print(ord("א"))     # 1488
print(chr(97))      # 'a'
print(chr(1488))    # 'א'

print(chr(ord("a") + 1))    # 'b'
print(ord("e") - ord("a"))  # 4

# ord() gives a character its code and chr() goes back.
```

### `palindrome.py`
```python
# lecture 3-1 — palindrome.py
word = input("Enter a word: ")
if word == word[::-1]:
    print(word, "is a palindrome")
else:
    print(word, "is not a palindrome")

# $ python palindrome.py
# Enter a word: racecar
# racecar is a palindrome
```

### `palindrome_idx.py`
```python
# lecture 3-1 — palindrome_idx.py
word = input("Enter a word: ")
palindrome = True
for i in range(len(word) // 2):
    if word[i] != word[-1 - i]:
        palindrome = False
        break
if palindrome:
    print(word, "is a palindrome")
else:
    print(word, "is not a palindrome")

# $ python palindrome_idx.py
# Enter a word: racecar
# racecar is a palindrome
```

### `print.py`
```python
# lecture 3-1 — print.py
print("I don't like\nthe word \"no\"")

# \n starts a new line and \" puts a double quote inside a double-quoted
# string. The file prints two lines.
```

### `quotes.py`
```python
# lecture 3-1 — quotes.py
a = "double quotes"
b = 'single quotes'
c = "it's fine inside double quotes"
d = 'and "quotes" inside single ones'

# Both quote marks make the same string. Use the other kind when the
# text itself contains one, and no escape is needed.
```

### `remove_vowels.py`
```python
# lecture 3-1 — remove_vowels.py
word = input("Enter a word: ")
result = ""
for ch in word:
    if ch not in "aeiou":
        result += ch
print(result)

# $ python remove_vowels.py
# Enter a word: example
# xmpl
```

### `slice.py`
```python
# lecture 3-1 — slice.py
s = "As easy "
print(s[1:5])   # s ea
print(s[0:2])   # As

# s[start:stop] stops one before stop, as range() does.
```

### `sqrt_bisection.py`
```python
# lecture 3-2 — sqrt_bisection.py
# Square root of x by bisection (x >= 1)
x = 16
epsilon = 0.01
low = 1.0
high = x
g = (low + high) / 2
steps = 0
while abs(g * g - x) >= epsilon:
    if g * g < x:
        low = g
    else:
        high = g
    g = (low + high) / 2
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")

# Halves the interval each pass. Far fewer steps than the walk.
```

### `sqrt_newton.py`
```python
# lecture 3-2 — sqrt_newton.py
# Square root of x by Newton-Raphson
x = 16
epsilon = 0.01
g = x / 2
steps = 0
while abs(g * g - x) > epsilon:
    g = g - (g * g - x) / (2 * g)
    steps = steps + 1
    print(f"step {steps}: {g}")
print(f"{round(g, 4)} in {steps} steps")

# Follows the tangent. Fewer steps again.
```

### `sqrt_sequential.py`
```python
# lecture 3-2 — sqrt_sequential.py
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon:
    g = g + increment
    steps = steps + 1
print(f"{round(g, 4)} in {steps} steps")

# Walks up from 1.0 in steps of 0.0001 until g * g is within epsilon
# of x.
```

### `sqrt_sequential_fixed.py`
```python
# lecture 3-2 — sqrt_sequential_fixed.py
# Square root of x by sequential search
x = 16
epsilon = 0.01
increment = 0.0001
g = 1.0
steps = 0
while abs(g * g - x) >= epsilon and g <= x:
    g = g + increment
    steps = steps + 1
if g > x:
    print("Use a smaller increment")
else:
    print(f"{round(g, 4)} in {steps} steps")

# The same search, with a guard: without g <= x the loop runs past x
# for ever when the increment is too coarse.
```

### `step.py`
```python
# lecture 3-1 — step.py
s = "abcdefgh"
print(s[0:8:2])   # aceg
print(s[::2])     # aceg
print(s[::-1])    # hgfedcba

# The third number is the stride; -1 walks the string backwards.
```

### `trap.py`
```python
# lecture 3-1 — trap.py
s = "  hello  "
s.strip()
print(s)

# s.strip() returns a new string and the program throws it away, so s is
# still "  hello  ". The fix is s = s.strip().
```

### `vowels_break.py`
```python
# lecture 3-1 — vowels_break.py
word = "programming"   # sample values, so the file runs on its own
result = ""
for ch in word:
    if ch in "aeiou":
        break
    result += ch
print(result)

# Everything before the first vowel, and nothing at all when the word opens on
# one: programming gives pr, python gives pyth, example gives the empty string.
```

### `vowels_continue.py`
```python
# lecture 3-1 — vowels_continue.py
word = "example"   # sample values, so the file runs on its own
result = ""
for ch in word:
    if ch in "aeiou":
        continue
    result += ch
print(result)

# The same result with continue: the vowel ends its pass early and
# nothing is appended.
```

### `vowels_if.py`
```python
# lecture 3-1 — vowels_if.py
word = "example"   # sample values, so the file runs on its own
result = ""
for ch in word:
    if ch not in "aeiou":
        result += ch
print(result)

# The accumulator with an if: a character is appended when it is not a
# vowel.
```


---

# Lecture 4-1: Functions (week 4)

## Slide 1: Functions
INTRO TO CS COURSE · WEEK 4 · LECTURE 1
Functions
Naming and reusing code

## Slide 2
1
Anatomy
what a function is made of
Lecture overview
2
Call and return
what happens while it runs
3
Defaults and keywords
calling it in more than one way
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 3: The big picture
The big picture
Each layer uses the one below it.
any program you may want to write
functions
conditionals and loops
variables and expressions
values and types
Today: functions.

## Slide 4: The same loop, twice
The same loop, twice
`two_roots_bad.py`
```python
# Two square roots: the same loop, twice
epsilon = 0.01
a = 16
g = a / 2
while abs(g * g - a) > epsilon:
    g = g - (g * g - a) / (2 * g)
print(f"root of {a}: {round(g, 4)}")

b = 105
g = b / 2
while abs(g * g - b) > epsilon:
    g = g - (g * g - b) / (2 * g)
print(f"root of {b}: {round(g, 4)}")
```
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design
```python
root of 16: 4.0012
root of 105: 10.247
```

## Slide 5: The same loop, named
The same loop, named
`my_sqrt.py`
```python
# The same loop, named once and reused
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```
```python
terminal
```
```python
root of 16: 4.0012
root of 105: 10.247
```
```python
Definition
```
```python
Call
```
```python
Why functions
Write once: the loop is in one place.
Fix once: a fix applies to every call.
Readable: my_sqrt(16) says what it does.
Reuse it: other programs can call it.
```

## Slide 6: Anatomy of a function
Anatomy of a function
`my_sqrt.py`
```python
# The same loop, named once and reused
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```
def
The keyword that starts a definition.
my_sqrt
The function's name.
(x)
The function’s parameter(s)
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 7: Body and return value
Body and return value
`my_sqrt.py`
```python
# The same loop, named once and reused
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```
The body
The indented block. It runs only when called.
return g
Returns a value and ends the call.
```python
Local names
epsilon and g exist only during the call.
```

## Slide 8: What a function is
What is a function?
Takes: zero, one or more inputs, its arguments
Does: whatever its body says, when it is called
Returns: one value (None if there is no return). 
Hides: its local names and its code from the caller (“encapsulation”)
16
the argument
my_sqrt
epsilon · g
local names, only while it runs
4.0012
one value back
Takes, does, returns — and hides.

## Slide 9: A function calling a function
A function calling a function
`hypot.py`
```python
# Distance between two points, using my_sqrt
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    res = my_sqrt(dx * dx + dy * dy)
    return res

print(round(hypot(2, 1, 5, 4), 4))
```
```python
terminal
```
```python
4.2426
```

## Slide 10: Arguments and parameters
Arguments and parameters
Two words for the two sides of a call.
Parameters: the names in the def line
Arguments: the values at the call
Matching: each parameter gets its argument
In order: the i-th parameter binds to the i-th argument
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design
```python
The call
hypot(2, 1, 5, 4)
```
2
1
5
4
x1
y1
x2
y2
```python
The definition
def hypot(x1, y1, x2, y2)
```
The i-th parameter binds to the i-th argument.
`hypot.py`
```python
def hypot(x1, y1, x2, y2):      # the parameters
    dx = x2 - x1
    dy = y2 - y1
    res = my_sqrt(dx * dx + dy * dy)
    return res
d = hypot(2, 1, 5, 4)           # the arguments
```
Parameters
Arguments

## Slide 11: Calling a function
Calling a function
A call pauses the caller and runs the function.
main
prints the distance
hypot(2, 1, 5, 4)
computes dx, dy
calls
my_sqrt(18)
runs the loop
calls
Only one function runs at a time. The other two wait.

## Slide 12: Returning from a call
Returning from a call
return sends a value back, and the caller continues.
main
prints the distance
hypot(2, 1, 5, 4)
computes dx, dy
my_sqrt(18)
runs the loop
returns
returns
The returned value replaces the call in the caller's code.

## Slide 13: The order of events
The order of events
Step 1: main starts running
Step 2: main calls hypot and suspends
Step 3: hypot calls my_sqrt and suspends
Step 4: my_sqrt returns; hypot resumes
Step 5: hypot returns; main prints and ends

## Slide 14: The run-time stack
The call stack
`hypot.py`
```python
# Distance between two points, using my_sqrt
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    res = my_sqrt(dx * dx + dy * dy)
    return res

print(round(hypot(2, 1, 5, 4), 4))
```
main
the program itself
hypot(2, 1, 5, 4)
x1  y1  x2  y2  ·  dx  ·  dy  ·  res
my_sqrt(18)
x  ·  epsilon  ·  g
the call stack  (grows upward)
The Call Stack (or Run-time Stack) is the memory mechanism that tracks active function calls. 
Each call gets its own isolated frame to store local variables and parameters. 
When a function returns, its frame is popped and execution resumes in the caller. 
How Python tracks active function calls and local variables

## Slide 15: Calling one function two ways
Calling one function two ways
The problem: sometimes we choose epsilon, usually we do not
Bad solution: two almost identical functions
Python's solution: a default value for epsilon
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 16: Default parameter values
Default parameter values
`my_sqrt_default.py`
```python
# epsilon becomes a parameter, with a default
def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2))
print(my_sqrt(2, 0.5))
print(my_sqrt(2, 1e-9))
```
my_sqrt(2)
epsilon = 0.001
The default steps in
my_sqrt(2, 1e-9)
epsilon = 1e-9
The caller decides
A default is a fallback, not a fixed value.
```python
terminal
```
```python
1.4142156862745099
1.5
1.4142135623746899
```

## Slide 17: Keyword arguments
Keyword arguments
```python
By position: my_sqrt(2, 1e-9), order decides
By name: my_sqrt(x=2, epsilon=1e-9), the call says
Any order: named arguments may come in any order
Mixed: my_sqrt(2, epsilon=1e-9), positional first, then named
Usual style: main inputs by position, optional ones by name
Why: the call is easier to read
```

## Slide 18: Calling by name
Calling by name
`keyword_args.py`
```python
# Naming the arguments at the call site
def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2, 1e-9))
print(my_sqrt(x=2, epsilon=1e-9))
print(my_sqrt(epsilon=1e-9, x=2))
print(my_sqrt(2, epsilon=1e-9))
```
```python
by position: my_sqrt(2, 1e-9) 
```
2
1e-9
x
epsilon
```python
by name: my_sqrt(epsilon=1e-9, x=2) 
```
1e-9
2
x
epsilon
Named arguments may arrive in any order.
```python
terminal
```
```python
1.4142135623746899
1.4142135623746899
1.4142135623746899
1.4142135623746899
```

## Slide 19: Type hints
Type hints
`type_hints.py`
```python
# Type hints: what goes in, what comes out
def my_sqrt(x: float, epsilon: float = 0.001) -> float:
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt(2))
print(my_sqrt(2, 1e-9))
```
```python
Parameters
x: float says x is a float.
```
```python
Return value
-> float says it returns a float.
```
Not checked
Python does not enforce hints.
Optional
Later lectures leave them out.

## Slide 20: Lecture summary
Lecture summary
Anatomy: def, parameters, a body, and one value out
Call and return: a call pauses the caller, and each call keeps its own frame
Defaults and keywords: one function, called in more than one way
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 21
Next: Functions, Part 2
Modules, API, and design
INTRO TO CS COURSE · WEEK 4 · LECTURE 2


---

# Lecture 4-2: Functions, part 2: modules, API and design (week 4)

## Slide 1: Functions, Part 2
INTRO TO CS COURSE · WEEK 4 · LECTURE 2
Functions, Part 2
Modules, API, and design

## Slide 2
Lecture overview
1
Modules and API
using a function someone else wrote
2
Designing with functions
splitting a task into pieces
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 3: Modularity
Modularity
Dividing a program into named pieces.
Less complexity: each piece can be understood on its own
Less duplication: fewer places for bugs
Testable: a function can be checked by itself
Shareable: two people can write two functions at once
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design
one long
program
read_input
compute
report
The same work — with names you can call.

## Slide 4: A library and its user
A library and its user
`mymath.py`
```python
"""A small library of math functions."""

def my_sqrt(x, epsilon=0.001):
    """Return a number whose square is near x."""
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    """Return the distance between two points."""
    return my_sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
```
the library: how it is done.
`main.py`
```python
# Using the library from another file
import mymath

print(mymath.my_sqrt(2))
print(mymath.hypot(2, 1, 5, 4))
```
the user: what is needed.
mymath.py
main.py
import mymath
mymath.my_sqrt(2)  →  1.4142
One file asks; the other answers.

## Slide 5: Calling syntax
Calling syntax
How you call a function depends on where it is.
```python
Same file: my_sqrt(2), just the name
Another module: mymath.my_sqrt(2)
```

## Slide 6: The caller's view: a black box
The caller's view: a black box
An API describes what a function does for its caller.
What it is called: the name and its parameters
What it gives back: the value, and what it means
What it assumes: the inputs it will not accept
Not how: the caller does not need the body.
16
input
my_sqrt
?
4.0012
output
The same machine — and the caller never opens it.

## Slide 7: Documenting the API
Documenting the API
`mymath.py`
```python
"""A small library of math functions."""

def my_sqrt(x, epsilon=0.001):
    """Return a number whose square is near x."""
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

def hypot(x1, y1, x2, y2):
    """Return the distance between two points."""
    return my_sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
```
```python
terminal
```
```python
help(mymath.my_sqrt)
my_sqrt(x, epsilon=0.001)
    Return a number whose
    square is near x.
```

## Slide 8: Functions vs. methods
Functions vs. methods
Both take inputs and return a result. They differ in where they live.
```python
a
```
```python
b
```
```python
c
```
```python
len
```
```python
a
```
```python
b
```
```python
c
```
```python
.upper()
```
function
method
how it is called
```python
len(s)
```
```python
s.upper()
```
where it lives
on its own
inside a type
works on
often many types
only its own type
Function: the value goes inside. Method: before the dot.
```python
Rule of thumb (A tendency, not a law)
Many types: Usually a function: len, print, str.
One type: Usually a method: .upper() is only for strings.
```
```python
Two dots, two meanings
mymath.  — before the dot is a module: where the function lives.
s.  — before the dot is a value: what the method works on.
Same character; one says where to look, the other what to act on.
```

## Slide 9: A method belongs to its data type
A method belongs to its data type
Python enforces where a method lives.
`errors.py`
```python
x = 5
x.upper()     # AttributeError
```
`arguments.py`
```python
s = "Hello"
s.count("l")          # 2
s.replace("l", "L")   # 'HeLLo'
```
The value before the dot is the first input.
```python
5
```
```python
int
```
!
```python
'int' object has no attribute 'upper'
```
An int has no such tool.
```python
upper
```
```python
name 'upper' is not defined
```
No such function.
```python
H
```
```python
e
```
```python
l
```
```python
l
```
```python
o
```
```python
.count()
```
```python
"l"
```
the value acted on
the argument
```python
upper("hi")   # NameError
```

## Slide 10: What makes a good function
What makes a good function
```python
One job: if the name needs “and”, it is two functions
A good name: says what it returns or does, like perimeter, is_right, print_primes
Few parameters: many parameters suggest a bad design
A docstring: one sentence saying what it returns
```
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 11: Top-down design
Top-down design
The task: in one sentence, what must the program do?
Split it: name the pieces the task needs
Repeat: split any piece that is still too big
Stop: when every piece is one small job
Number guessing game
Set up
Play a round
Finish
Pick a secret
Set max tries
Read a guess
Check guess
Show result
Offer replay

## Slide 12: A decomposition diagram
A decomposition diagram
A box is a function. An arrow means “calls”.
The task
Given the three corners of a triangle, print its perimeter and say whether it has a right angle.
main
the top-level code
hypot
in mymath
3 calls
perimeter
to write
is_right
to write
my_sqrt
in mymath

## Slide 13: Design before code
Design before code
Signatures: each function's name and parameters
Docstrings: in one sentence, what does it return?
Stubs: placeholder bodies, so the program runs
Bodies last: fill in and test one at a time
```python
def average(a, b):
```
```python
"""Return the mean of a and b."""
```
```python
avg = (a + b) / 2
```
```python
return 0.0
```
```python
body
```

## Slide 14: Stubs first, bodies later
Stubs first, bodies later
`stubs.py`
```python
# Sketch first: the real bodies come later
def hypot(x1, y1, x2, y2):
    return 0.0

def my_sqrt(x, epsilon=0.001):
    return 0.0

print(hypot(2, 1, 5, 4))
```
What is a stub?
A function with its real name and parameters, but a placeholder body (here, return 0.0).
The program already runs, so you can check how the pieces fit together, then write the real bodies one at a time.
```python
terminal
```
```python
0.0
```

## Slide 15: The design, written down
The design, written down
`triangle_design.py`
```python
# The design first: names, parameters, promises
import mymath

def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return 0.0

def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return False

a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```
```python
terminal
```
```python
perimeter: 0.0
right angle: False
```

## Slide 16: Then fill in the bodies
Then fill in the bodies
`triangle.py`
```python
# The same design, with the bodies filled in
import mymath

def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return a + b + c

def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return abs(a * a + b * b - c * c) < 0.01

a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```
```python
terminal
```
```python
perimeter: 12.0
right angle: True
```

## Slide 17: Your turn: decompose
Your turn: decompose
Draw the diagram first. No code yet.
The task
Read a whole number n. Print every prime number from 2 to n, and then how many primes there were.
Your steps
1. Name the functions you need.
2. Give each a signature and a   docstring.
3. Draw who calls whom.
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 18: Solution: the pieces
Solution: the pieces
```python
The task: read n, print the primes from 2 to n, then their count
main: reads n, tries every k from 2 to n, counts the primes
is_prime(k): one job, True if k is a prime number
Stop: is_prime needs no “and”, so it is small enough
```

## Slide 19: Solution: the diagram
Solution: the diagram
Two good designs. Every box has one job.
Design A
main
the top-level code
is_prime
to write
Design B
main
the top-level code
print_primes
to write
count_primes
to write
is_prime
to write

## Slide 20: Solution: the design, written down
Solution: the design, written down
`primes_design.py`
```python
# The design: main is written, is_prime is a stub
def is_prime(k):
    """Return True if k is a prime number."""
    return False

n = int(input())
count = 0
for k in range(2, n + 1):
    if is_prime(k):
        print(k, end=" ")
        count += 1
print()
print(f"{count} primes")
```
```python
terminal
```
```python
20

0 primes
```

## Slide 21: Solution: fill in the body
Solution: fill in the body
`primes.py`
```python
# The same design, with the body filled in
def is_prime(k):
    """Return True if k is a prime number."""
    for d in range(2, k):
        if k % d == 0:
            return False
    return True

n = int(input())
count = 0
for k in range(2, n + 1):
    if is_prime(k):
        print(k, end=" ")
        count += 1
print()
print(f"{count} primes")
```
```python
terminal
```
```python
20
2 3 5 7 11 13 17 19 
8 primes
```

## Slide 22: Checking a function with assert
Checking a function with assert
`primes_check.py`
```python
# is_prime(k) -> True or False
assert is_prime(7)
assert is_prime(2), "2 is prime"   # easy to get wrong
assert not is_prime(9)

# count_primes(n) -> a number
assert count_primes(10) == 4       # 2 3 5 7
assert count_primes(1) == 0        # none at all
print("all checks passed")
```
```python
What assert is
Syntax: assert <condition you believe is true>
Semantics: if condition is True, nothing happens and the program carries on. If it is False, the program stops, with an AssertionError.
It is possible to add an error message in case condition is False (e.g., "2 is prime" )
```
```python
terminal
```
```python
all checks passed
```
```python
terminal
```
```python
AssertionError: 2 is prime
```
```python
With return k > 2 in is_prime:
```
Verifying that your function fulfills its guarantees

## Slide 23: Design and AI tools
Design and AI tools
AI tools can now write a function body in seconds.
What they need: a clear name, parameters and docstring
Yours to decide: what the pieces are and how they fit
How you check: test each small function by itself
You design
name, parameters, docstring
AI writes
the function body
You check
test each function alone

## Slide 24: Class exercise: the Caesar cipher
Class exercise: the Caesar cipher
Task: shift every lowercase letter of a given string a fixed number of places.
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design
```python
terminal
```
```python
hello, world
3
khoor, zruog
```
Algorithm: which steps are functions?
Initialize: Create an empty string.
1
Loop over input's characters one by one:
2
Check if character is a lower case letter. If it is:
2,1
Shift letter
Convert letter to position 0 to 25
2,1.1
Shift letter position, wrapping from 25 to 0
2,1.2
Convert back from position to letter
2,1.3
Append character to new string.
2.2
```python
a
```
```python
d
```
```python
b
```
```python
e
```
```python
c
```
```python
f
```
```python
d
```
```python
g
```
```python
e
```
```python
h
```
```python
f
```
```python
i
```
```python
g
```
```python
j
```
```python
h
```
```python
k
```
```python
i
```
```python
l
```
```python
j
```
```python
m
```
```python
k
```
```python
n
```
```python
l
```
```python
o
```
```python
m
```
```python
p
```
```python
n
```
```python
q
```
```python
o
```
```python
r
```
```python
p
```
```python
s
```
```python
q
```
```python
t
```
```python
r
```
```python
u
```
```python
s
```
```python
v
```
```python
t
```
```python
w
```
```python
u
```
```python
x
```
```python
v
```
```python
y
```
```python
w
```
```python
z
```
```python
x
```
```python
a
```
```python
y
```
```python
b
```
```python
z
```
```python
c
```
outer: plain
inner: shift 3
```python
x
```
```python
23
```
```python
26
```
```python
0
```
```python
a
```
Test first: xyz with shift 3 must give abc.

## Slide 25: Solution: the pieces
Solution: the pieces
```python
main: reads the message and the shift, encrypts the message and prints the result
encrypt(text, shift): steps 1, 2, 2.1 and 2.2
shift_letter(ch, shift): steps 2.1.1 to 2.1.3
```

## Slide 26: Solution: the diagram
Solution: the diagram
One chain. A box is a function; an arrow means “calls”.
main
the top-level code
encrypt
to write
shift_letter
to write
once per character
```python
Where to stop
shift_letter does three things: 
Letter to number
Shift with the wrap.
Number back to letter.
That is one body, not three more functions - a piece stops earning a name when it is one expression.
```

## Slide 27: Solution: the design, written down
Solution: the design, written down
`caesar_design.py`
```python
# The design first: names, parameters, promises
def shift_letter(ch, shift):
    """Return ch shifted inside a..z."""
    return ch

def encrypt(text, shift=3):
    """Return text with its lowercase letters shifted."""
    return text

text = input("Message: ")
shift = int(input("Shift: "))
print(encrypt(text, shift))
```
```python
terminal
```
```python
hello, world
3
hello, world
```
What this proves
The message comes back unchanged — the stubs run, and main is already right.

## Slide 28: Solution: fill in the bodies
Solution: fill in the bodies
`caesar.py`
```python
def shift_letter(ch, shift):
    """Return ch shifted inside a..z."""
    position = ord(ch) - ord("a")
    position = (position + shift) % 26
    return chr(position + ord("a"))

def encrypt(text, shift=3):
    """Return text with its lowercase letters shifted."""
    result = ""
    for ch in text:
        if ch.islower():
            ch = shift_letter(ch, shift)
        result = result + ch
    return result

text = input("Message: ")
shift = int(input("Shift: "))
print(encrypt(text, shift))
```
```python
terminal
```
```python
hello, world
3
khoor, zruog
```
2.1
2.1.1
2.1.2
2.1.3
1
2
2.2

## Slide 29: Your turn: decryption
Your turn: decryption
A follow-up task: undo the cipher, without writing a new loop.
```python
The task: decrypt(text, shift) takes the encrypted message and the shift used to encrypt it, and returns the original.
```
The hint: Encrypt already does the work. 
```python
terminal
```
```python
khoor, zruog
3
hello, world
```
`caesar.py`
```python
def decrypt(text, shift=3):
    """Return the original message."""
    return encrypt(text, -shift)
```
-3 % 26 is 23, so the wrap holds.

## Slide 30: A function is an object
A function is an object
`function_object.py`
```python
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g

print(my_sqrt)        # <function my_sqrt at 0x...>
f = my_sqrt           # no parentheses: the function itself
print(f(16))          # 4.001219512195122
print(f is my_sqrt)   # True - one object, two names
```
```python
The name and the call
my_sqrt is the function’s name.
my_sqrt(16) is what it returns when you call it. 
f = my_sqrt binds the name f to the function’s object. 
f = my_sqrt(16) calls the function and binds the name f to the result (4.0012).
```
my_sqrt
f
one function object
Same function, two names. 
A function is a value, like any other

## Slide 31: Lecture summary
Lecture summary
Modules and API: import it, read its docstring, ignore its body
Designing with functions: top-down, stubs first, and assert each piece on its own
And a function is a value: it can be named, and next lecture it is passed as an argument to another function.
Why functions
Anatomy
Call and return
Defaults and keywords
Modules and API
Designing
A worked design

## Slide 32
Next: Lists and Tuples
Sequences that can be changed
INTRO TO CS COURSE · WEEK 5 · LECTURE 1


---

# Week 4 code files

The code files shown in the week 4 lectures.

### `arguments.py`
```python
# lecture 4-1 — arguments.py
# (this slide and its file came from lecture 3-1, where they are skipped)
s = "Hello"
s.count("l")          # 2
s.replace("l", "L")   # 'HeLLo'

# Prints nothing: both lines are values the REPL would show. .count
# answers 2 and .replace answers 'HeLLo' — and s itself is unchanged.
```

### `caesar.py`
```python
# lecture 4-1 — caesar.py
# The same design, with the bodies filled in. Each numbered step of the
# algorithm is one line, and the three steps inside `Shift letter` are the
# three lines of shift_letter.
def shift_letter(ch, shift):
    """Return ch shifted inside a..z."""
    position = ord(ch) - ord("a")       # 2.1.1  a..z  ->  0..25
    position = (position + shift) % 26  # 2.1.2  the shift, with the wrap
    return chr(position + ord("a"))     # 2.1.3  back to a letter


def encrypt(text, shift=3):
    """Return text with its lowercase letters shifted."""
    result = ""                         # 1
    for ch in text:                     # 2
        if ch.islower():                # 2.1
            ch = shift_letter(ch, shift)
        result = result + ch            # 2.2
    return result


def decrypt(text, shift=3):
    """Return the message that encrypt(text, shift) came from."""
    return encrypt(text, -shift)


text = input("Message: ")
shift = int(input("Shift: "))
print(encrypt(text, shift))

# Message: hello, world
# Shift: 3
# khoor, zruog
#
# The lowercase test lives in the loop, not in shift_letter, so the function
# does only what its name says. The price is that it assumes a lowercase
# letter: shift_letter(",", 3) answers "c", which is nonsense. Deciding what
# counts as a letter is the caller's job.
#
# decrypt is one line because encrypt already exists: -3 % 26 is 23, so the
# same modulo that wraps z to c wraps a back to x.
```

### `caesar_check.py`
```python
# lecture 4-1 — caesar_check.py
# The same functions, with the asserts that check them one at a time.
def shift_letter(ch, shift):
    """Return ch shifted inside a..z."""
    position = ord(ch) - ord("a")
    position = (position + shift) % 26
    return chr(position + ord("a"))


def encrypt(text, shift=3):
    """Return text with its lowercase letters shifted."""
    result = ""
    for ch in text:
        if ch.islower():
            ch = shift_letter(ch, shift)
        result = result + ch
    return result


def decrypt(text, shift=3):
    """Return the message that encrypt(text, shift) came from."""
    return encrypt(text, -shift)


# shift_letter(ch, shift) -> one letter. It assumes it is given one.
assert shift_letter("a", 3) == "d"
assert shift_letter("z", 3) == "c", "the wrap: 25 + 3 is 2, not 28"

# encrypt(text, shift) -> a string. Here is where a non-letter is decided.
assert encrypt("hello, world", 3) == "khoor, zruog"   # the comma and the space
assert encrypt("xyz", 3) == "abc"
assert encrypt("abc") == "def"                        # the default shift

# decrypt undoes it, whatever the shift
assert decrypt("khoor, zruog", 3) == "hello, world"
assert decrypt(encrypt("hello", 7), 7) == "hello"

print("all checks passed")

# The last one is the strongest check on the pair, and it could not be written
# at all on the flat program of lecture 3-1: it tests a property of two
# functions together, not one value.
```

### `caesar_design.py`
```python
# lecture 4-1 — caesar_design.py
# The design first: names, parameters, promises. The bodies are stubs, so the
# program already runs and main can be checked before anything is encrypted.
def shift_letter(ch, shift):
    """Return ch shifted inside a..z."""
    return ch


def encrypt(text, shift=3):
    """Return text with its lowercase letters shifted."""
    return text


text = input("Message: ")
shift = int(input("Shift: "))
print(encrypt(text, shift))

# Message: hello, world
# Shift: 3
# hello, world
#
# The message comes back unchanged, which is what a stub should do. The run
# already proves the prompts, the int() on the shift and the call are right.
```

### `errors.py`
```python
# lecture 4-1 — errors.py
# (this slide and its file came from lecture 3-1, where they are skipped)
x = 5
x.upper()     # AttributeError
upper("hi")   # NameError

# ON PURPOSE BROKEN — this is the error demo of the slide.
# x.upper() on an int raises AttributeError, and upper("hi") raises
# NameError: there is no plain function by that name. Run the lines one at
# a time; the file stops at the first of them.
```

### `function_object.py`
```python
# lecture 4-1, slide 15 — a function is a value, like any other
# my_sqrt is the deck's own function, exactly as slide 5 wrote it.

def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g


print(my_sqrt)         # <function my_sqrt at 0x...>  — the address changes
                       # every run; what matters is that it IS something

f = my_sqrt            # no parentheses: the function itself, not its answer
print(f(16))           # 4.001219512195122
print(f is my_sqrt)    # True — one object, two names

# The one character that matters:
#   f = my_sqrt       takes the function
#   f = my_sqrt(16)   takes the answer
#
# And note 4.001219512195122, not 4: this is still the my_sqrt of slide 5,
# with epsilon hard-coded at 0.01 — the approximation of lecture 3-2 is still
# an approximation. The default-parameter slide is what lets the caller
# tighten it.
```

### `hypot.py`
```python
# lecture 4-1 — hypot.py
# A function calling a function: hypot uses my_sqrt, and while my_sqrt runs
# the call to hypot is still waiting. This is the program of the call-stack
# slide.

# Distance between two points, using my_sqrt
def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g


def hypot(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    res = my_sqrt(dx * dx + dy * dy)
    return res


print(round(hypot(2, 1, 5, 4), 4))
```

### `keyword_args.py`
```python
# lecture 4-1 — keyword_args.py
# The same call, four ways. Named arguments may arrive in any order, and all
# four lines print the same number.

def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g


print(my_sqrt(2, 1e-9))
print(my_sqrt(x=2, epsilon=1e-9))
print(my_sqrt(epsilon=1e-9, x=2))
print(my_sqrt(2, epsilon=1e-9))
```

### `main.py`
```python
# lecture 4-1 — main.py
# The user side: what is needed. One file asks, the other answers.
# Run this one; mymath.py must sit beside it.

# Using the library from another file
import mymath

print(mymath.my_sqrt(2))
print(mymath.hypot(2, 1, 5, 4))

# And this is the docstring the help() slide reads:
#   help(mymath.my_sqrt)
```

### `my_sqrt.py`
```python
# lecture 4-1 — my_sqrt.py
# The same loop, named once and reused.

def my_sqrt(x):
    epsilon = 0.01
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g


print("root of 16:", round(my_sqrt(16), 4))
print("root of 105:", round(my_sqrt(105), 4))
```

### `my_sqrt_default.py`
```python
# lecture 4-1 — my_sqrt_default.py
# epsilon becomes a parameter with a default: one function, called in more
# than one way. Note the second line: a loose epsilon gives a loose answer.

def my_sqrt(x, epsilon=0.001):
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g


print(my_sqrt(2))         # 1.4142156862745099  — the default steps in
print(my_sqrt(2, 0.5))    # 1.5                 — a loose epsilon
print(my_sqrt(2, 1e-9))   # 1.4142135623746899  — the caller decides
```

### `mymath.py`
```python
"""A small library of math functions."""
# lecture 4-1 — mymath.py
# The library side: how it is done. Nothing here prints; it is imported.


def my_sqrt(x, epsilon=0.001):
    """Return a number whose square is near x."""
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g


def hypot(x1, y1, x2, y2):
    """Return the distance between two points."""
    return my_sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
```

### `primes.py`
```python
# lecture 4-1 — primes.py
# The same design, with the body filled in. Type 20 when it asks.

# The same design, with the body filled in
def is_prime(k):
    """Return True if k is a prime number."""
    for d in range(2, k):
        if k % d == 0:
            return False
    return True


n = int(input())
count = 0
for k in range(2, n + 1):
    if is_prime(k):
        print(k, end=" ")
        count += 1
print()
print(f"{count} primes")
```

### `primes_check.py`
```python
# Checking two functions with assert
# A test is one line: write down what you already know, and let Python check it.


def is_prime(k):
    """Return True if k is a prime number."""
    for d in range(2, k):
        if k % d == 0:
            return False
    return True


def count_primes(n):
    """Return how many prime numbers there are from 2 to n."""
    count = 0
    for k in range(2, n + 1):
        if is_prime(k):
            count = count + 1
    return count


# is_prime(k) -> True or False
assert is_prime(7)
assert is_prime(2), "2 is prime"   # easy to get wrong
assert not is_prime(9)

# count_primes(n) -> a number
assert count_primes(10) == 4       # 2 3 5 7
assert count_primes(1) == 0        # none at all
print("all checks passed")
```

### `primes_design.py`
```python
# lecture 4-1 — primes_design.py
# main is written, is_prime is a stub. Type 20 when it asks: it prints no
# primes at all, which is exactly what a stub that always answers False does.

# The design: main is written, is_prime is a stub
def is_prime(k):
    """Return True if k is a prime number."""
    return False


n = int(input())
count = 0
for k in range(2, n + 1):
    if is_prime(k):
        print(k, end=" ")
        count += 1
print()
print(f"{count} primes")
```

### `stubs.py`
```python
# lecture 4-1 — stubs.py
# Sketch first: real names and parameters, placeholder bodies. The program
# already runs, so the pieces can be checked against each other before any
# of them is written.

def hypot(x1, y1, x2, y2):
    return 0.0


def my_sqrt(x, epsilon=0.001):
    return 0.0


print(hypot(2, 1, 5, 4))   # 0.0 — the shape is right, the answer is not yet
```

### `triangle.py`
```python
# lecture 4-1 — triangle.py
# The same design, with the bodies filled in. Nothing above the bodies
# changed. mymath.py must sit beside this file.

import mymath


def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return a + b + c


def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return abs(a * a + b * b - c * c) < 0.01


a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```

### `triangle_design.py`
```python
# lecture 4-1 — triangle_design.py
# The design first: names, parameters, promises. Both bodies are stubs, so
# the numbers are wrong on purpose — what is being checked is the fit.
# mymath.py must sit beside this file.

import mymath


def perimeter(a, b, c):
    """Return the sum of the three sides."""
    return 0.0


def is_right(a, b, c):
    """Return True if a*a + b*b is close to c*c."""
    return False


a = mymath.hypot(0, 0, 3, 0)
b = mymath.hypot(0, 0, 0, 4)
c = mymath.hypot(3, 0, 0, 4)
print("perimeter:", round(perimeter(a, b, c), 4))
print("right angle:", is_right(a, b, c))
```

### `two_roots_bad.py`
```python
# lecture 4-1 — two_roots_bad.py
# The same loop, written twice. This is the slide that motivates functions:
# nothing here is wrong, it is just copied.

# Two square roots: the same loop, twice
epsilon = 0.01
a = 16
g = a / 2
while abs(g * g - a) > epsilon:
    g = g - (g * g - a) / (2 * g)
print(f"root of {a}: {round(g, 4)}")

b = 105
g = b / 2
while abs(g * g - b) > epsilon:
    g = g - (g * g - b) / (2 * g)
print(f"root of {b}: {round(g, 4)}")
```

### `type_hints.py`
```python
# lecture 4-1 — type_hints.py
# Type hints say what goes in and what comes out. Python does not enforce
# them: the program runs exactly the same without them.

def my_sqrt(x: float, epsilon: float = 0.001) -> float:
    g = x / 2
    while abs(g * g - x) > epsilon:
        g = g - (g * g - x) / (2 * g)
    return g


print(my_sqrt(2))
print(my_sqrt(2, 1e-9))
```
