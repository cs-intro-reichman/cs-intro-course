# Lecture 1-1: Intro and basics (week 1)

## Slide 1
PYTHON COURSE · WEEK 1 · LECTURE 1
Fundamentals
Introduction to Computer Science in Python

## Slide 2
Lecture overview
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug
1
The course
what it is, and what it expects
2
Computer science
about problems, not computers
3
Problem to program
thinking first, then pseudocode
4
Python
syntax, readability, and running code

## Slide 3
Course objectives
Basic exposure to Computer Science - as a field, not just a tool
Basic programming skills - specifically, in Python
What will this course give you ?
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 4
Sharpen your analytic skills - precise, structured thinking
Appreciate clarity and elegance - in code, not only correctness
Develop a taste for beauty - in science and engineering
Learn how to learn and develop – not only as a programmer, but also as a computer scientist
And along the way you will ...
Course objectives

## Slide 5
Course requirements
Attend:
Two weekly lectures (שיעור)
One weekly recitation (תרגיל)
One weekly workshop (סדנה) 
Submit:
A weekly homework assignments (שיעורי בית)

## Slide 6
Course website (“Moodle”)
Contents:
 Lectures / recitations slides + code
HW documents + code
Course announcements
Important:
The only formal and abiding channel of communications between the course team and the students is the course web site
What is said orally by the course staff about HW, exams, requirements, grading, deadlines – is tentative. What is written in the web site is formal.

## Slide 7
Q&A forum
How to ask questions ?
Find the forum — by week or topic
Read first — check existing posts before asking
Post a question – if needed.
Expect an answer — within a few hours, from a TA or a fellow student
Feel free to answer others — if you think your answer will be useful
Keep it clean — professional tone, in English

## Slide 8
Books and resources
“Python for Everybody” — Severance, free online – py4e.com/book
The official Python tutorial – docs.python.org/3/tutorial
“Think Python” — Downey, 3rd ed., free online – greenteapress.com

## Slide 9
Computer Science is About...
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 10
“Computer science is no more about computers than astronomy is about telescopes, biology is about microscopes or chemistry is about beakers and test tubes. Science is not about tools. It is about how we use them, and what we find out when we do.”
Edsger W. Dijkstra
Computer Science is About...

## Slide 11
Computer Science is About...
Theory
Systems
Applications
Common Themes
Programming
The universal language
 of computation
Efficiency
Doing more with less, 
faster and smarter
Beauty
An acquired taste — elegant solutions to hard problems

## Slide 12
High Level Apps & AI
Data Analysis & Simulation
Medical & Imaging systems
E-commerce & Social platforms
AI, Chatbots & NLP
User Products
Mobile & Web applications
Game Development
Productivity & Business tools
Interactive User Interface
Programming is about…
Systems & Core
Operating systems
Compilers
Networks
Cloud & Network protocols
Cyber Security & Cryptography
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 13
A taste of programming
Simulate the motion of N heavenly bodies,subject to Newton’s laws of motion and gravity

## Slide 14
A taste of programming
`spiral.py`
```python
import turtle
t = turtle.Turtle()
t.speed(0)
colors = ["#A64B00", "#1B3A5C", "#F5B759"]
for i in range(200):
    t.pencolor(colors[i % 3])
    t.forward(i * 2)
    t.right(91)
turtle.done()
```
Live demo – the file is in “week 1 code / spiral.py”.

## Slide 15
Programming is about…
Writing code that is ...
Correct — produces the right answer, every time
Efficient — makes reasonable use of time and memory
Readable — a human can follow it later – including you

## Slide 16
Good code is ...
Easy to understand — for other people and for yourself
Easy to test — you can check that it does what it claims
Easy to maintain and extend — you can change it easily without breaking it
A pleasure to work with — for whoever touches it next
Programming is about…

## Slide 17
The peanut butter sandwich
Write literal instructions – then watch them followed exactly, not as intended.
Write the steps
→
Read them literally
→
Watch it fail
→
Precision is the point

## Slide 18
From a problem to a program
Every program is the end of this chain.
Problem
An algorithm that solves it
Pseudocode describing the algorithm
A program in a high-level language
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 19
What a problem is
In computer science a problem is defined by:
Input — what you are given at the start
Output — the result the process has to produce

## Slide 20
Three problems, as input and output
Only what goes in and what must come out — never how.
A natural number
Is it prime?
Two real numbers
Their average
A list of integers
The same list, sorted

## Slide 21
What makes problem-solving computational
An algorithm is a finite, unambiguous procedure that is correct for every valid input.
Precision — every step is spelled out; nothing is left implied
Finiteness — the procedure has to stop, not run forever
Generality — it works for the whole class of inputs, not just the case you tried by hand

## Slide 22
Computational thinking: four habits of mind
Jeannette Wing, 2006 — a general problem-solving skill
Break it into pieces
Spot the repeating pattern
Keep only what matters
Write the precise step

## Slide 23
Pseudocode: the step before code
Human communication: Uses natural language, intuition, and high-level concepts.
Computer execution: Requires strict, step-by-step instructions with zero ambiguity.
Pseudocode as a bridge: Separates what to do from how to write it - reducing cognitive load.
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 24
Pseudocode: a worked example
The algorithm - in pseudocode
read n from the user
set i to 0
while i is less than or equal to n:
    print i
    increase i by 1
print "Done"
The problem
Input: a whole number n
Output: the numbers from 0 to n

## Slide 25
Which language should you learn?
Java, Python, C, JavaScript… - every serious language has real strengths
There is no single right answer - the “best” language depends on the job
What transfers is the thinking – 
not the syntax of any one language

## Slide 26
Why Python ?
Clean and minimal syntax – A first working program takes a single line: 
High industry demand – Leading language in AI\ML, Data Science, Backend and Automation.
Extensive ecosystem – Built in tools for immediate use (math, random) plus industry-standard libraries (numpy, pandas).
18
```python
print("Hello World")
```
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 27
The intro language at leading CS programs (MIT, Berkeley, Harvard, Stanford).
Interactive and beginner-friendly - Immediate feedback via REPL, with clear readable error messages (Python 3.10+)
Balanced trade-offs – Prioritized readability and expressiveness over raw execution speed – ideal for learning fundamental concepts.
Why Python ?

## Slide 28
Our approach
Teach a meaningful subset of Python - Master essential Python concepts deeply, without getting lost in exhaustive feature lists.
Build problem-solving skills – Develop algorithmic thinking patterns that directly apply to any programming language.
Foundation for future growth - Make learning other languages faster and more intuitive.
Concepts over syntax - Focus on how to think like a computer scientist, not just how to code in Python. 

## Slide 29
Python program example
The algorithm - in pseudocode
set i to 0
while i is less than 6:
    print i
    increase i by 1
print "Done"
2
`count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```
Python implementation
The task: print the numbers 0 to 5

## Slide 30
Python syntax elements - Words
`count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```
Reserved words
Belong to the
language - you cannot
use them as names.
In this example: while
Identifiers
User defined names. 
In this example: i  
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 31
```python
False
```
```python
None
```
```python
True
```
```python
and
```
```python
as
```
```python
assert
```
```python
async
```
```python
await
```
```python
break
```
```python
class
```
```python
continue
```
```python
def
```
```python
del
```
```python
elif
```
```python
else
```
```python
except
```
```python
finally
```
```python
for
```
```python
from
```
```python
global
```
```python
if
```
```python
import
```
```python
in
```
```python
is
```
```python
lambda
```
```python
nonlocal
```
```python
not
```
```python
or
```
```python
pass
```
```python
raise
```
```python
return
```
```python
try
```
```python
while
```
```python
with
```
```python
yield
```
Python syntax elements – Reserved words
`count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```

## Slide 32
Python syntax elements – Literals (constants)
`count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```
Numbers
0, 6, 1, 3.14, -5
Strings
Text wrapped in quotes
("Done“ or 'Done')
Booleans & None 
True, False - logical values None - represents absence of value

## Slide 33
Python syntax elements - Symbols
`count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```

## Slide 34
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```
Python program structure
A statement
A complete instruction that performs an action
A block
A group of statements executed together as a single unit, defined strictly by indentation
A program
A sequence of statements executed in logical order, directed by control flow (like loops and conditions).
`count_to_five.py`

## Slide 35
```python
class Dog:
    def __init__(self, name):
        self.name = name
    def bark(self):
        print(self.name + " says woof")
rex = Dog("Rex")
rex.bark()
```
Python program structure
`dog.py`
A function
A named, reusable block of code that performs a task
A method
A function that belongs to a class, and acts on its object
A class
A blueprint for creating objects, bundling data and methods together.

## Slide 36
Program readability
`count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```
Comments (#)
Notes for developers, completely skipped during execution..
White Spaces  
Blank lines and spaces between operators—used to improve clarity, ignored during execution
Syntax Highlighting
Visual color-coding provided by the editor to make code easier to read
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 37
Program readability
“Any fool can write
code that a computer
understands. Good
programmers write code
that humans understand.”
- Martin Fowler
`count_to_five_bad.py`
```python
i=0;
while i<6:print(i);i=i+1
print("Done")
```
Same output. Same program, as far as Python is concerned.
Same code, written badly
PEP 8 - The community style guide. A set of conventions (not strict rules), to make Python code clean and readable.

## Slide 38
Aspects of any language 
`count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```
Semantics
What you want to say or do.
Meaning / intention
Syntax
How to say it. 
The rules of the language: vocabulary and grammar
Style
How well you say it.

## Slide 39
Natural language vs. programming language
Natural languages
Hebrew, English, and other human languages
Allow breaking syntax rules
Occasionally more than one meaning to a sentence
Programming languages
Syntax is sacred
Only one semantic interpretation - no ambiguity

## Slide 40
Ways to execute Python code
Interactive Mode
```python
>>> python
```
Evaluates one expression at a time directly in the terminal (REPL).
Instant execution & feedback
Ideal for testing code snippets
Script Mode
`python myprog.py`
Runs a whole .py file in one command – no separate build step.
Permanent, reusable code
Standard for production software
Notebooks
```python
Jupyter / Colab
```
Combines code cells, docs, and inline visualizations.
Standard in Data Science & AI
Interactive step-by-step flow
The course
Computer science
Programming
Problem solving
Pseudocode
Why Python
Syntax
Readability
Edit, Run & Debug

## Slide 41
The REPL (Read-Eval-Print Loop)
```python
python (interactive)
```
```python
>>> 2 ** 10
1024
>>> "spam" + "eggs"
'spameggs'
>>> print("hello")
hello
>>> 1 / 0
ZeroDivisionError: division by zero
```
Demo this live – no file needed; transcript: “week 1 code / repl_session.txt”.

## Slide 42
Popular IDEs for Python: 
VS Code — free, lightweight, cross-platform
PyCharm — full-featured, Python-dedicated IDE
Jupyter / Colab — interactive, browser-based notebook environments
Integrated Development Environments (IDEs)
What is an IDE ? An all-in-one workspace featuring a code editor, compiler, build tools, debugger and more...

## Slide 43
Debugging – Finding and fixing bugs in your code
Syntax Errors
```python
missing colon :
```
Code violates grammar rules; caught before execution starts, e.g. an unmatched parenthesis.
Runtime Errors
```python
ZeroDivisionError
```
Occur while running; Python calls these exceptions (try/except in Week 4).
Logical Errors
```python
wrong answer
```
The program runs to completion without crashing, but the answer is wrong due to flawed logic.
Murphy's Law: “Anything that can possibly go wrong, will.”

## Slide 44
Before next lecture
Visit the course website — [TBD]
Install Python – python.org/downloads
Set up VS Code (???) — setup guide [TBD]
Homework 1 — play with an existing python program, break it on purpose, then fix it; then write a few of your own. 
Further instructions: see the course website.

## Slide 45
PYTHON COURSE · WEEK 1 · LECTURE 2
Next: Data Types, Input and Output
Variables, dynamic typing, expressions, I/O


---

# Lecture 1-2: Types and I/O (week 1)

## Slide 1
PYTHON COURSE · WEEK 1 · LECTURE 2
Data Types, Input and Output
Variables, dynamic typing, expressions, input and output

## Slide 2
Lecture overview
Data types
Variables
Expressions
Input / output
int
float
str
bool
Casting
1
Data types
every value has one
2
Variables
a name that refers to a value
3
Expressions
operators, precedence, and traps
4
The four types
int, float, str, bool — and casting

## Slide 3
Data
The same data – different representations
User view
What a person sees on the screen.
Programmer view
Data is manipulated using variables, statements,...
`programmer_view.py`
```python
sales_person = "Jack"
commission = 0.04
kg_sold = 509
```
Computer view
Data is represented as 0’s and 1’s (bits)
Data types
Expressions
Input / output
int
float
str
bool
Casting
Variables

## Slide 4
What is a Data Type?
A Data Type is a set of possible values, together with the operations allowed on them.
```python
The values
… −2  −1  0  1  2  3 …
Everything a value of this type
is allowed to be.
```
```python
The operations
+  −  *  /  //  %  **
Everything you are allowed
to do with them.
```

## Slide 5
Every value has a type
Every value that exists while a program runs has a type of its own
type() — the built-in that answers “what type is this value?”
The type decides — which operations are legal, and what they mean

## Slide 6
`types_demo.py`
```python
type(5)          # <class 'int'>
type(3.14)       # <class 'float'>
type(True)       # <class 'bool'>
type("hello")    # <class 'str'>
```
Every value has a type

## Slide 7
Fundamental Data Types in Python
```python
int
5
Whole numbers.
Exact, and unlimited in size.
```
```python
str
"hello"
Text.
Any characters, in quotes.
```
```python
float
3.14
Real numbers.
Stored with finite precision.
```
```python
bool
True
Logical values.
Only True and False.
```

## Slide 8
What is a Variable ?
You can picture it as a label you stick on a value.
You can peel it off one value and stick onto another.
A Variable is a name that refers to a value in the program.
`variables_demo.py`
```python
x = -13
x = 25.5
x = "hello"
```
Data types
Expressions
Input / output
int
float
bool
str
Casting
Variables

## Slide 9
Variable creation and assignment
Assignment (=) - Binds a name of the variable to a value.
Automatic creation — Creating a variable happens implicitly on its first assignment.
A variable has no type — type(x) reports the type of the value x refers to right now.

## Slide 10
Variable creation and assignment
Memory view during execution
The code (abstraction)
```python
x = -13
x = 25
x = x + 1
y = x - 5
```
The name is a label
state 2
```python
-13
```
```python
25
```
```python
x
```
state 3
```python
-13
```
```python
25
```
```python
26
```
```python
x
```
state 4
```python
-13
```
```python
25
```
```python
26
```
```python
x
```
```python
21
```
```python
y
```
In memory (implementation), after each line
state 1
```python
-13
```
```python
x
```
.                          The value is what is sitting in memory — and re-assigning moves the label.

## Slide 11
…and in memory, it is bits
The code (abstraction)
```python
x = -13
x = 25
x = x + 1
y = x - 5
```
The memory actually holds bits
In memory (actual implementation – in bits), after each line
state 1
```python
11110011
```
```python
x
```
state 2
```python
11110011
```
```python
00011001
```
```python
x
```
state 3
```python
11110011
```
```python
00011001
```
```python
00011010
```
```python
x
```
state 4
```python
11110011
```
```python
00011001
```
```python
00011010
```
```python
x
```
```python
00010101
```
```python
y
```
Actual memory view during execution

## Slide 12
The same name, a different kind of value
`dynamic_typing.py`
```python
x = 5          # type(x) is int
x = "hello"    # type(x) is now str - perfectly legal
```
This is what "dynamically typed" means.

## Slide 13
Static vs. Dynamic Typing
Statically typed
the type of every variable is fixed and checked before the program runs.

Java · C · C++ · C# · Go · Rust · Swift
Dynamically typed
types belong to values and are checked while the program runs.


Python · JavaScript · Ruby · PHP
Determined by when types are checked and bound.

## Slide 14
Strong vs. Weak Typing
Strongly typed
types are strictly enforced, with little or no automatic conversion.

Python · Java · Ruby · Swift
Weakly typed
types are converted automatically when needed.

JavaScript · C · PHP · Perl
Determined by whether implicit type conversions are allowed.

## Slide 15
Dynamic Typing – Pros & Cons
Pros - Quicker to write - Less boilerplate, no declarations, faster prototyping. 
Cons - Errors arrive later - Type errors surface only when the code executes, sometimes under specific inputs.
Middle ground - Type hints - Optional static-like annotations (e.g., x: int = 5).

## Slide 16
Naming - Python requirements
Allowed characters - letters, digits, underscores ( _ ) only.
Must start with a letter or underscore – names cannot start with a digit.
Case-sensitive — age, Age and AGE are three different names.
No reserved words — the 35 keywords (from lecture 1-1) are out of bounds.
Nothing else is enforced — the syntax rules are minimal, which is why the conventions matter.

## Slide 17
Naming: Legal and illegal names
```python
age
```
```python
student_count
```
```python
_temp
```
```python
MAX_SCORE
```
```python
2nd_place
```
starts with a digit
```python
my-name
```
hyphens are not allowed
```python
class
```
a reserved word
```python
my name
```
no spaces

## Slide 18
Naming: Python conventions (readability)
```python
snake_case (PEP 8) – Use lowercase words separated by underscores for variable names (e.g., student_count, total_price, is_leap_year).
Meaningful names - Choose clear, descriptive names (student_count instead of sc). Reserve short names like i or j strictly for loop counters.
ALL_CAPS for constants – Used for values intended never to change during execution (e.g., MAX_SCORE = 100). A convention only (not enforced by python).
```

## Slide 19
What is an expression ?
```python
Operands - the values or variables that an operator acts upon (e.g., x and 4 in the x + 4)
Operator rules – each operator is defined for specific data types.
```
Data types
Expressions
Input / output
int
float
str
bool
Casting
An expression is a combination of values, variables and operators that evaluate to a single value.
Variables

## Slide 20
Operator overloading
`overloading.py`
```python
6 + 5        # 11
"6" + "5"    # '65'
```
How it works
The operand types determine the actual operation executed by the symbol
Not all operators apply to all types
Some operations are invalid for specific types
Same symbol, different operations
`type_error.py`
```python
6 - 5        # 1
"6" - "5"
# TypeError: unsupported operand type(s)
# for -: 'str' and 'str'
```

## Slide 21
Assignment vs. Comparison
Two things that look almost the same, and are not:
=  is a statement: it binds a name to a value
==  is an operator: it compares two values and produces True or False

## Slide 22
Output: print()
`io_demo.py`
```python
print("Hello!")
print("Result:", 42)            # Result: 42
x = 3
print(2, "+", x, "=", 2 + x)    # 2 + 3 = 5
```
Data types
Expressions
Input / output
int
float
str
bool
Casting
print() - Python’s built-in function that outputs values to the screen,
separated by spaces by default. 
Variables

## Slide 23
Input: input()
`input_demo.py`
```python
# Silent input (no prompt)
name = input()
```
input() - Python’s built-in function that reads a line of input from the user as text.
```python
# Input with a prompt message
name = input("What's your name? ")
print("Hello", name, "!")
```
Prompt – an optional string printed to the screen to guide the user on what to enter.

## Slide 24
input() always returns text
`input_is_text.py`
```python
age = input("How old are you? ")
print(type(age))     # <class 'str'>
print(age - 1)
# TypeError: unsupported operant type(s) for -: ‘str’ and ‘int’
```
```python
Return value is always text
Even if the user types digits, input() always returns a string (e.g., "18“ instead of the number 18).
```
Python is strongly typed
Python will not automatically convert text to numbers for arithmetic operations. Mixing types causes a runtime error.
Digits entered via input() are stored as text, not numbers.

## Slide 25
From text to a number
`int_input_preview.py`
```python
age = int(input("How old are you? "))
print(age - 1)      # 19
```
int() converts text to a whole number — the full story in the Casting section.
So what do we do if we want to read a number ?

## Slide 26
Command-line input
A program can also receive input directly from the command line:
sys.argv - captures arguments passed after the program’s name when executed in the terminal.
For now, we will focus on interactive input via input(). You will primarily encounter sys.argv when reading existing codebase or running automated scripts.

## Slide 27
The int data type: Data & Operations 
Data types
Expressions
Input / output
int
float
str
bool
Casting
```python
+
```
```python
-
```
```python
*
```
```python
/
```
```python
//
```
floor division
```python
%
```
```python
**
```
exponentiation
```python
Data: whole numbers (integers) – Positive, negative or zero, with no decimal point (e.g., 42, -7, 0).

Operations: 
```
Variables

## Slide 28
int operations
`int_ops.py`
```python
print(5 + 3)     # 8
print(5 - 3)     # 2
print(5 * 3)     # 15
print(5 / 5)     # 1.0   a float, not an int
print(5 // 5)    # 1     floor division
print(5 % 3)     # 2
print(2 ** 10)   # 1024
print(1 / 0)     # ZeroDivisionError
```

## Slide 29
Precedence
`precedence.py`
```python
print(3 * 5 - 2)     # 13   * binds first
print(3 - 5 - 2)     # -4   - associates left to right
print(3 - (5 - 2))   # 0    parentheses always win
```

## Slide 30
The two divisions 
`division.py`
```python
print(5 / 2)     # 2.5
print(5 // 2)    # 2
print(4 / 2)     # 2.0
```
/ is true division
It always produces a number with a decimal point, even when the answer is whole.
// is floor division
Divide, then throw the remainder away

## Slide 31
Python integers do not overflow
`big_int.py`
```python
print(2 ** 100)
# 1267650600228229401496703205376
```
Arbitrary precision
Python integers automatically allocate more memory as they grow, so there is no fixed upper limit.
No silent wraparound
In languages like C or Java, exceeding maximum integer limits silently rolls values back to negatives (wraparounds). Python completely prevents this bug.

## Slide 32
The float data type: Data & Operations
Data types
Expressions
Input / output
int
float
str
bool
Casting
```python
+
```
```python
-
```
```python
*
```
```python
/
```
```python
//
```
floor division
```python
%
```
```python
**
```
exponentiation
```python
Data: real numbers – Numbers with a fractional part (e.g., 3.14, -0.5, 6.02e23).

Operations: 
```
Variables

## Slide 33
Examples
`float_ops.py`
```python
print(3.141 + 0.03)    # 3.171
print(6.02e23 / 2)     # 3.01e+23
print(5.0 / 2.0)       # 2.5
print(5 // 2)          # 2
print(1 / 3)           # 0.3333333333333333
print(1.0 / 0.0)       # ZeroDivisionError
```

## Slide 34
Math operations & the math module
Python provides built-in functions as well as dedicated modules for mathematical operations.
`builtins_demo.py`
```python
# built in - no import needed
abs(-3)           # 3
round(3.7)        # 4
round(3.14159, 2) # 3.14
```
Built-in math functions
Always available without importing anything.
`math_demo.py`
```python
import math
math.sqrt(16)   # 4.0
math.floor(3.7) # 3
math.ceil(3.2)  # 4
math.pi         # 3.141592653589793
```
```python
The math module
Requires import math to access advanced mathematical functions and constants.
```

## Slide 35
How Python handles invalid operations
`invalid_operations.py`
```python
1.0 / 0.0        # ZeroDivisionError
math.sqrt(-1.0)  # ValueError
1.0 + "3"        # TypeError
```
Same mechanism, different errors
When an operation is mathematically or logically invalid, Python raises an exception.
No silent failures
Instead of returning dangerous default values (like Infinity or NaN), Python stops immediately.
Coming up later
How to catch these errors using try / except.

## Slide 36
Example: the quadratic equation
`quadratic.py`
```python
import math
b = float(input("b: "))
c = float(input("c: "))
d = math.sqrt(b * b - 4.0 * c)
print((-b + d) / 2.0)
print((-b - d) / 2.0)
```
Solves x² + bx + c = 0. Try b = -3, c = 2.

## Slide 37
Textual information
HTML:
DNA:
Text:
Python:
```python
text_segment = "We hold these truths ..."
dna_segment = "ATGTTGCGGCTCGGGGCCAA ..."
html_segment = '<!DOCTYPE html> <html lang="en-US"> ...'
```
`text_segments.py`
Data types
Expressions
Input / output
int
float
str
bool
Casting
Variables

## Slide 38
The str data type: Data & Operations 
```python
+
```
concatenations
```python
Data: Textual information (sequences of characters) – enclosed in single of double quotes (e.g., "Hello ", ‘Python’," 42 ").

Operations: 
```
```python
*
```
repetition
more operations and methods – coming up soon...

## Slide 39
The + operator of str 
`str_ops_concat.py`
```python
s1 = "Tel"
s2 = "Aviv"
print(s1 + s2)          # TelAviv
print(s2 + s1)          # AvivTel
print(s1 + " " + s2)    # Tel Aviv
```
What does the operator do ?
The + operator performs string concatenation. It joins two or more strings end-to-end to form a single continuous string.
```python
   Important Note: Spaces
Python does not insert spaces automatically between joined strings. If a space is needed between words, you must include it explicitly (e.g. " ").
```

## Slide 40
```python
The * operator of str 
```
`str_ops_mult.py`
```python
s = "Ha"
laugh = s * 3
divider = 10 * "-"

print(laugh)    # HaHaHa
print(divider)  # ----------
```
```python
What does the operator do ?
The * operator performs String Repetition. It duplicates a string a specified number of times and concatenates the copies together.
```
   Rule: Types
Repetition requires exactly one string (str) and one whole number (int), and in this exact order. You cannot “multiply” two strings together!

## Slide 41
Class exercise – Predict the output
`str_ops.py`
```python
print(6 + 5)
print("6" + "5")
print("6" + 5)
print(2, "+", 3, "=", 2 + 3)
print(6 * 5)
print("6" * 5)
print(6 * "5")
print("6" * "5")
```

## Slide 42
`str_growth.py`
```python
s = "1"
s = s + " 2 " + s     
s = s + " 3 " + s     
print(s)
```
Class exercise – Predict the output

## Slide 43
f-strings
`fstrings.py`
```python
a = 2
b = 3
print(f"{a} + {b} = {a + b}")       # 2 + 3 = 5

name = input()
age = int(input())
print(f"Hello {name}, next year you will be {age + 1}")
```
An f before the quote
Anything inside { } is evaluated as Python expressions and automatically converted to text.
No more TypeError!
Numbers inside {} are converted automatically. This is the standard way to build formatted text in Python.

## Slide 44
George Boole · 1815–1864
Created Boolean logic - a mathematical system using only True and False. A century later, it became the foundation upon which all modern computer systems and software are built.
Boolean logic
Data types
Expressions
Input / output
int
float
bool
str
Casting
Variables

## Slide 45
The bool type: Data & Operations
```python
not
```
```python
and
```
```python
or
```
```python
Data: True, False. 

Operations (Boolean connectors):
```

## Slide 46
Boolean connectors truth tables
Every combination of inputs, and the value each connector returns.
a | not a
True | False
False | True
a | b | a and b
True | True | True
True | False | False
False | True | False
False | False | False
a | b | a or b
True | True | True
True | False | True
False | True | True
False | False | False
```python
not
```
```python
and
```
```python
or
```

## Slide 47
operator | meaning | true | false
 | equal | 2 == 2 | 2 == 3
 | not equal | 3 != 2 | 2 != 2
 | less than | 2 < 13 | 2 < 2
 | less than or equal | 2 <= 2 | 3 <= 2
 | greater than | 13 > 2 | 2 > 13
 | greater than or equal | 3 >= 2 | 2 >= 3
Comparison operators
```python
==
```
```python
!=
```
```python
<
```
```python
<=
```
```python
>
```
```python
>=
```

## Slide 48
`age_check.py`
```python
city = input("City: ")
age  = int(input("Age: "))

print(city == "Tel Aviv")   # True — already a bool
too_young = age < 18        # the same value, with a name
if too_young:
    print("You are too young for this")
```
Worked examples

## Slide 49
Worked examples
`comparisons.py`
```python
b*b - 4.0*c >= 0   # nonnegative?
year % 100 == 0    # new century?
x != 1             # not 1?
num % 2 == 0	      # num is even ?
```

## Slide 50
Worked example: leap years
Definition: A leap year (שנה מעוברת) is a year which is 
                       (i) divisible by 400, or (ii) divisible by 4 but not by 100.
Task: Write a program that determines if a given year is a leap year.
`leap_year.py`
```python
year = int(input("Enter a year: "))
is_leap = (year % 400 == 0)
is_leap = is_leap or (year % 4 == 0 and year % 100 != 0)
print(is_leap)
```
2020 → True  ·  1900 → False  ·  2028 → True

## Slide 51
The float precision trap
`rounding.py`
```python
print(1.03 - 0.42)  		 # 0.6100000000000001
print(1.00 - 9 * 0.10) 		 # 0.09999999999999998
print((0.7 + 0.1) == (0.9 - 0.1)) # False
```
IEEE 754 representation
Computers stores floats in binary (bits). Some decimal fractions (like 0.1) cannot be represented exactly, leading to small rounding inaccuracies.

## Slide 52
Comparing floats
`comparing_floats.py`
```python
a = 0.7 + 0.1
b = 0.9 - 0.1
print(abs(a - b) < 1e-9)    # True
```
Never use ==
Compare the gap instead, using an epsilon tolerance.
Define required precision
Choose an accuracy threshold suitable for your application domain.
```python
Exact arithmetic alternatives
Use Pythons decimal or fractions modules when exact values are required (e.g., financial calculations).
```

## Slide 53
Casting: Type conversion
Data types
Expressions
Input / output
int
float
str
bool
Casting
int()
Converts text or a float, to a whole number
Truncates the decimal parts (does not round!)
float()
Converts text or int, to a real (decimal) number
str()
Converts any value to a text string.
```python
bool()
Converts any value to True or False.
0, 0.0 and "" becomes False.
```
Variables
Explicitly converting a value from one data type to another using built-in functions.

## Slide 54
Worked examples
`casting.py`
```python
print(str(1234) + str(99))    # 123499
print(int("123"))             # 123
print(int(2.71828))           # 2     truncates
print(float("3.5"))           # 3.5
print(bool(0), bool(""))      # False False
```

## Slide 55
`casting.py`
```python
print(7 / 2)
print(7 // 2)
print(int(7 / 2))
print(7 % 2)
print(int("7") // 2)
print("7" * int(7 / 2))
```
Class exercise – Predict the output

## Slide 56
When a conversion fails
`bad_input.py`
```python
age = int(input("How old are you? "))
print(age + 1)
```
What went wrong ?
Read the last line first: int() received text that cannot be converted to a whole number.
Where did it fail ?
The File line gives the file name and the line number.
The carets point at the exact expression that failed.
Reading error messages
Error messages seem cryptic at first, but reading them carefully is an essential debugging skill.
```python
terminal
```
```python
Traceback (most recent call last):
  File "bad_input.py", line 1, in <module>
    age = int(input("How old are you? "))
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
ValueError: invalid literal for int()
            with base 10: 'hello'
```

## Slide 57
The random module
`random_demo.py`
```python
import random
print(random.random())               # in [0, 1)
print(2.0 * random.random())         # in [0, 2)
print(2.0 * random.random() - 1.0)   # in [-1, +1)
```
Run it twice and get different outputs
The random module provides tools for generating random numbers and values.

## Slide 58
A worked example: a random whole number
`random_int.py`
```python
import random
n = int(input("Enter N: "))
r = random.random()      # in [0, 1)
result = int(r * n)      # in [0, N)
print(f"random integer is {result}")
```

## Slide 59
Lecture summary
```python
int
+ - * / // % **
exact, unlimited size
```
```python
str
+  *
and f-strings
```
```python
float
+ - * / // % **
finite precision
```
```python
bool
not · and · or
and the six comparisons
```
Fundamental Data Types
Data types
Variables
Expressions
Input / output
int
float
str
bool
Casting

## Slide 60
Lecture summary
```python
Every value has a type
type(5)   →   int
A variable is not a box.
It is a name that refers
to a value.
```
```python
Dynamic, and strong
"6" + 5   →   TypeError
The type is checked when
the line runs — and never
converted behind your back.
```
```python
Input arrives as text
input()   →   str
Always. Turning it into a
number is your job.
```
```python
int is exact, float is not
0.1 + 0.2   →   0.30000000000000004
Compare floats with a
tolerance, never with ==.
```
Data types
Variables
Expressions
Input / output
int
float
str
bool
Casting

## Slide 61
PYTHON COURSE · WEEK 2 · LECTURE 1
Next: Conditionals and loops
Making a program choose, and making it repeat


---

# Week 1 code files

The code files shown in the week 1 lectures.

### `age_check.py`
```python
# lecture 1-2, slide 49 — a condition can have a name
city = input("City: ")
age  = int(input("Age: "))

print(city == "Tel Aviv")   # True — already a bool
too_young = age < 18        # the same value, with a name
if too_young:
    print("You are too young for this")
```

### `bad_input.py`
```python
# lecture 1-2, slide 55 — when a conversion fails
age = int(input("How old are you? "))
print(age + 1)

# $ python bad_input.py
# How old are you? hello
# Traceback (most recent call last):
#   File "bad_input.py", line 1, in <module>
#     age = int(input("How old are you? "))
#           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
# ValueError: invalid literal for int() with base 10: 'hello'
```

### `big_int.py`
```python
# lecture 1-2, slide 32 — Python integers do not overflow
print(2 ** 100)
# 1267650600228229401496703205376
```

### `brackets.py`
```python
# lecture 1-2, slide 50 — Where the brackets go
print(11 * 0.3)
# 3.3
print(int(11 * 0.3))    # 3
print(int(11) * 0.3)
# 3.3
```

### `builtins_demo.py`
```python
# lecture 1-2, slide 35 — built in, no import needed
print(abs(-3))             # 3
print(round(3.7))          # 4
print(round(3.14159, 2))   # 3.14

# note: round(2.5) is 2, not 3 — Python rounds halves to the nearest even number
```

### `casting.py`
```python
# lecture 1-2, slide 53 — Worked examples
print(str(1234) + str(99))    # 123499
print(int("123"))             # 123
print(int(2.71828))           # 2     truncates
print(float("3.5"))           # 3.5
print(bool(0), bool(""))      # False False
```

### `comparing_floats.py`
```python
# lecture 1-2, slide 59 — comparing floats
a = 0.7 + 0.1
b = 0.9 - 0.1

print(a == b)               # False
print(abs(a - b) < 1e-9)    # True
```

### `comparisons.py`
```python
# lecture 1-2, slide 50 — Comparison operators
b*b - 4.0*c >= 0   # nonnegative?
year % 100 == 0    # new century?
x != 1             # not 1?
```

### `count_to_five.py`
```python
# lecture 1-1, slides 28–37 — the running example
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```

### `count_to_five_bad.py`
```python
# lecture 1-1, slide 36 — Program readability
i=0;
while i<6:print(i);i=i+1
print("Done")
```

### `division.py`
```python
# lecture 1-2, slide 31 — The two divisions
print(5 / 2)     # 2.5
print(5 // 2)    # 2
print(4 / 2)     # 2.0
```

### `dog.py`
```python
# lecture 1-1, slide 34 — Python program structure
class Dog:
    def __init__(self, name):
        self.name = name
    def bark(self):
        print(self.name + " says woof")
rex = Dog("Rex")
rex.bark()
```

### `dynamic_typing.py`
```python
# lecture 1-2, slide 13 — The same name, a different kind of value
x = 5          # type(x) is int
x = "hello"    # type(x) is now str - perfectly legal
```

### `float_ops.py`
```python
# lecture 1-2, slide 34 — Worked expressions
print(3.141 + 0.03)    # 3.171
print(6.02e23 / 2)     # 3.01e+23
print(5.0 / 2.0)       # 2.5
print(5 // 2)          # 2
print(1 / 3)           # 0.3333333333333333
print(1.0 / 0.0)       # ZeroDivisionError
```

### `fstrings.py`
```python
# lecture 1-2, slide 44 — f-strings
a, b = 2, 3
print(f"{a} + {b} = {a + b}")
# 2 + 3 = 5
```

### `hello.py`
```python
# lecture 1-1, slide 25 — Why Python ?
print("Hello, world!")
```

### `input_demo.py`
```python
# lecture 1-2, slide 24 — Input: input()

# Silent input (no prompt)
name = input()

# Input with a prompt message
name = input("What's your name? ")
print("Hello", name, "!")
```

### `input_is_text.py`
```python
# lecture 1-2, slide 25 — input() always returns text
age = input("How old are you? ")
print(type(age))     # <class 'str'>
print(age + 1)
# TypeError: can only concatenate str
#            (not "int") to str
```

### `int_input.py`
```python
# lecture 1-2, slide 29 — Reading an integer from the user
age = int(input("How old are you? "))
print("Next year you'll be", age + 1)
```

### `int_input_preview.py`
```python
# lecture 1-2, slide 26 — From text to a number
age = int(input("How old are you? "))
print(age + 1)      # 19
```

### `int_ops.py`
```python
# lecture 1-2, slide 29 — int operations
print(5 + 3)     # 8
print(5 - 3)     # 2
print(5 * 3)     # 15
print(5 / 5)     # 1.0   a float, not an int
print(5 // 5)    # 1     floor division
print(5 % 3)     # 2
print(2 ** 10)   # 1024
print(1 / 0)     # ZeroDivisionError
```

### `invalid_operations.py`
```python
# lecture 1-2, slide 36 — Python fails loudly
1.0 / 0.0        # ZeroDivisionError
math.sqrt(-1.0)  # ValueError
1.0 + "3"        # TypeError
```

### `io_demo.py`
```python
# lecture 1-2, slide 23 — Output: print()
print("Hello!")
print("Result:", 42)            # Result: 42
x = 3
print(2, "+", x, "=", 2 + x)    # 2 + 3 = 5
```

### `leap_year.py`
```python
# lecture 1-2, slide 51 — A worked example: leap years
year = int(input("Enter a year: "))
is_leap = (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0)
print(is_leap)
```

### `math_demo.py`
```python
# lecture 1-2, slide 35 — the math module
import math

print(math.sqrt(16))    # 4.0   — always a float, even for a perfect square
print(math.floor(3.7))  # 3
print(math.ceil(3.2))   # 4
print(math.pi)          # 3.141592653589793

# there is no math.abs and no math.round — those are built into the language
```

### `overloading.py`
```python
# lecture 1-2, slide 21 — Operator overloading
6 + 5        # 11
"6" + "5"    # '65'
```

### `precedence.py`
```python
# lecture 1-2, slide 30 — Precedence
print(3 * 5 - 2)     # 13   * binds first
print(3 - 5 - 2)     # -4   - associates left to right
print(3 - (5 - 2))   # 0    parentheses always win
```

### `programmer_view.py`
```python
# lecture 1-2, slide 4 — Data: the programmer's view
sales_person = "Jack"
commission = 0.04
kg_sold = 509
```

### `pseudocode.txt`
```
# lecture 1-1, slides 23 and 28 — Pseudocode: a worked example
set i to 0
while i is less than 6:
    print i
    increase i by 1
print "Done"
```

### `quadratic.py`
```python
# lecture 1-2, slide 37 — A worked example: the quadratic equation
import math
b = float(input("b: "))
c = float(input("c: "))
d = math.sqrt(b * b - 4.0 * c)
print((-b + d) / 2.0)
print((-b - d) / 2.0)
```

### `random_demo.py`
```python
# lecture 1-2, slide 56 — Random numbers
import random
print(random.random())               # in [0, 1)
print(2.0 * random.random())         # in [0, 2)
print(2.0 * random.random() - 1.0)   # in [-1, +1)
```

### `random_int.py`
```python
# lecture 1-2, slide 57 — A worked example: a random whole number
import random
n = int(input("Enter N: "))
r = random.random()      # in [0, 1)
result = int(r * n)      # in [0, N)
print(f"random integer is {result}")
```

### `repl_session.txt`
```
# lecture 1-1, slide 40 — The REPL (Read-Eval-Print Loop)
# Transcript of an interactive session -- not a script to run.
>>> 2 ** 10
1024
>>> "spam" + "eggs"
'spameggs'
>>> print("hello")
hello
>>> 1 / 0
ZeroDivisionError: division by zero
```

### `rounding.py`
```python
# lecture 1-2, slide 58 — Floats still round
print(1.03 - 0.42)                   # 0.6100000000000001
print(1.00 - 9 * 0.10)               # 0.09999999999999998
print((0.7 + 0.1) == (0.9 - 0.1))    # False
```

### `six_and_five.py`
```python
# lecture 1-2, slide 39 — Numbers, or text that looks like numbers
print(6 + 5)                    # 11
print("6" + "5")                # 65
print("6" + str(5))             # 65
print(2, "+", 3, "=", 2 + 3)    # 2 + 3 = 5
```

### `spiral.py`
```python
# lecture 1-1, slide 13 — A taste of programming
# Draws a spiral of squares using turtle graphics.
# Run with: python spiral.py

import turtle
t = turtle.Turtle()
t.speed(0)
colors = ["#A64B00", "#1B3A5C", "#F5B759"]
for i in range(200):
    t.pencolor(colors[i % 3])
    t.forward(i * 2)
    t.right(91)
turtle.done()
```

### `str_growth.py`
```python
# lecture 1-2, slide 43 — Growing a string
s = "1"
s = s + " 2 " + s     # 1 2 1
s = s + " 3 " + s     # 1 2 1 3 1 2 1
print(s)
```

### `str_int.py`
```python
# lecture 1-2, slide 57 — Python will not convert for you
s1 = "Tel"
print(s1 + 3)
# TypeError: can only concatenate str
#            (not "int") to str
print(s1 + str(3))     # Tel3
print(s1 * "3")        # TypeError
print(s1 * int("3"))   # TelTelTel
```

### `str_ops.py`
```python
# lecture 1-2, slide 42 — Text: str
s1 = "Tel"
s2 = "Aviv"
print(s1 + s2)          # TelAviv
print(s2 + s1)          # AvivTel
print(s1 + " " + s2)    # Tel Aviv
```

### `str_ops_concat.py`
```python
# lecture 1-2, slide 40 — the + operator of str
s1 = "Tel"
s2 = "Aviv"
print(s1 + s2)          # TelAviv
print(s2 + s1)          # AvivTel
print(s1 + " " + s2)    # Tel Aviv

# Python never inserts a space for you — put it in yourself.
```

### `str_ops_mult.py`
```python
# lecture 1-2, slide 41 — the * operator of str
s = "Ha"
laugh = s * 3
divider = 10 * "-"

print(laugh)    # HaHaHa
print(divider)  # ----------
```

### `text_segments.py`
```python
# lecture 1-2, slide 38 — Textual information
text_segment = "We hold these truths ..."
dna_segment = "ATGTTGCGGCTCGGGGCCAA ..."
html_segment = '<!DOCTYPE html> <html lang="en-US"> ...'
```

### `type_error.py`
```python
# lecture 1-2, slide 21 — Operator overloading
6 - 5        # 1
"6" - "5"
# TypeError: unsupported operand type(s)
# for -: 'str' and 'str'
```

### `types_demo.py`
```python
# lecture 1-2, slide 7 — Every value has a type
type(5)          # <class 'int'>
type(3.14)       # <class 'float'>
type(True)       # <class 'bool'>
type("hello")    # <class 'str'>
```

### `variables_demo.py`
```python
# lecture 1-2, slide 9 — What is a Variable ?
x = -13
x = 25.5
x = "hello"
```


---

# Lecture 2-1: Conditionals and while loops (week 2)

## Slide 1
PYTHON COURSE · WEEK 2 · LECTURE 1
Conditionals and Loops
Control flow, conditionals (if, else, elif) and while loops

## Slide 2
Lecture overview
Program flow
Conditionals
Loops
Examples
1
Program flow
sequence, then branching
2
Conditionals
if, else, elif
3
Loops
while, and the four classic bugs
4
Examples
programs that use both

## Slide 3
Program control flow structures
Program flow
Conditionals
Loops
Examples
Until now
Sequential execution
Runs once, top-to-bottom, and does the same thing every time.
From today
Conditional branching
Iterative execution
Can choose what to do, and can repeat work as many times as needed.
Conditionals let a program respond to its input. 
Loops let a program repeat operations efficiently without code duplication.

## Slide 4
Fundamental program flow structures
The order statements actually run in (not the order they are written).
Sequential
statement 1
statement 2
statement 3
one after another
Conditional
```python
test
```
```python
True
```
```python
False
```
```python
A
```
```python
B
```
the paths rejoin
Iterative (loops)
```python
test
```
```python
True
```
body
```python
False
```
the path goes back
Conditionals branch forwards. Loops branch backwards. 

## Slide 5
The if statement
Program flow
Conditionals
Loops
Examples
`abs_value.py`
```python
x = int(input("Enter a number: "))
if x < 0:
    x = -x
print("Absolute value:", x)
```
```python
terminal
```
```python
Enter a number: -12
Absolute value: 12
```
read x
```python
x < 0
```
```python
True
```
```python
False
```
```python
x = -x
```
```python
print(x)
```
Two inputs, two different routes, one program.

## Slide 6
The if statement
Core components
Condition - A boolean expression.
Colon (:) - Delimits the header from the conditional block.
Block - One or more indented statements executed if and only if condition evaluates to True.
Syntax rules
Unlike Java or C, Python requires no parentheses ( ) around the condition and no curly braces { } for block scope. Indentation defines the execution scope.
`if_syntax.py`
```python
block # executed if True
```
Syntax:

## Slide 7
Common errors: colon & indentation
Missing indentation after the colon
```python
terminal
```
```python
    print("x is positive")
    ^
IndentationError: expected an indented
block after 'if' statement on line 3
```
     Bad indentation
Every line right after the colon must be indented.
Fix: indent the block consistently, usually 4 spaces.
Missing colon after the condition
```python
terminal
```
```python
    if x < 0
            ^
SyntaxError: expected ':'
```
```python
     Missing colon
The colon marks where the header ends and the block begins.
Fix: add ':' at the end of the if line.
```

## Slide 8
Semantic block scoping
In Python, indentation is not a style choice – it determines program semantics.
`version_a.py`
```python
# Block includes print statement
if x < 0:
    x = -x
    print("negative")
```
Both lines run, or neither does.
`version_b.py`
```python
# Block ends before print statement
if x < 0:
    x = -x
print("done")
```
Only the indented line belongs to the if.
The rule
All statements indented to the same level form the conditional block. Returning to the previous indentation level closes the block.
The conventions
Uset four spaces per indentation level (PEP 8 style guide). Never mix spaces and tabs doing so raises a TabError.

## Slide 9
What counts as a condition ?
Any expression that evaluates to True or False (Boolean expression).
```python
Chained comparisons
Python supports mathematical range checks such as 0 0 <= grade <= 100 (evaluates the middle term only once).
```
`chained.py`
```python
if 0 <= grade <= 100:
    print("Valid grade")
```
```python
0
```
```python
100
```
valid
One comparison, not two.
`condition.py`
```python
if score >= 60 and attendance >= 0.8:
    print("Pass")
```
```python
Compound Conditions
Boolean operators (and, or, not) combine multiple expressions into a single True/False result.
```

## Slide 10
The if-else statement
`if_else.py`
Exactly one block runs
The else block executes if and only if the condition evaluates to False.
```python
condition
```
```python
True
```
```python
False
```
```python
if block
```
```python
else block
```
carry on
The two paths rejoin.
```python
if block 
# executed if True
```
```python
else block
# executed if False
```

## Slide 11
Example: Coin flip
`coin_flip.py`
```python
import random

if random.random() < 0.5:
    print("Heads")
else:
    print("Tails")
```
Dynamic output via randomization
random.random() returns a float in [0, 1) 
(you met it in lecture 1-2).
Heads
Tails
```python
0
```
```python
0.5
```
```python
1
```
Same program - different output each run. 
Run it four or five times.

## Slide 12
Example: The max two values
`max_v1.py`
```python
# 1 — symmetric
if x >= y:
    max_val = x
else:
    max_val = y
```
Version 1: Explicit logic
Evaluates both paths clearly:
if x >= y choose x, otherwise choose y.
`max_v2.py`
```python
# 2 — assume, then correct
max_val = x
if y > max_val:
    max_val = y
```
Version 2: Assume & Correct
Sets a default answer (x), then corrects it only if y turns out to be larger. 

## Slide 13
Example: Guard conditions
Using conditionals to prevent runtime errors.
`quadratic.py`
```python
import math

d = b * b - 4.0 * a * c
if d < 0.0:
    print("No real roots")
else:
    root = math.sqrt(d)
    print("x1 =", (-b + root) / (2*a))
    print("x2 =", (-b - root) / (2*a))
```
Why is the guard needed ?
Passing a negative value to math.sqrt() raises a ValueError 
(as seen in Lecture 1-2).
Preventing runtime crashes
The if statement validates the input first, ensuring math.sqrt() only executes on safe inputs.

## Slide 14
Example: Nested vs. Independent ifs
Both print the same thing. What is the difference?
`nested_if.py`
```python
if a == b:
    print("a equals b")
else:
if a > b:
    print("a is greater")
else:
    print("b is greater")
```
`chained_if.py`
```python
if a == b:
    print("a equals b")
if a > b:
    print("a is greater")
if a < b:
    print("b is greater")
```

## Slide 15
Example: Nested vs. Independent ifs
```python
a == b
```
```python
True
```
"a equals b"
```python
False
```
```python
a > b
```
"a is greater"
"b is greater"
Nested if
The first True exits - remaining tests are skipped.
```python
False
```
```python
True
```
```python
a == b
```
```python
True
```
"a equals b"
```python
a > b
```
"a is greater"
```python
a < b
```
"b is greater"
Independent ifs
Every test runs, every time.
```python
True
```
```python
True
```
```python
False
```
```python
False
```
```python
False
```

## Slide 16
The elif statement
if-elif-else chain
The first True leaves the chain
(Identical to nested if)
`elif.py`
```python
if a == b:
    print("a equals b")
elif a > b:
print("a is greater")
else:
print("b is greater")
```
Same execution flow as nested if, with flat indentation
```python
a == b
```
```python
True
```
"a equals b"
```python
False
```
```python
a > b
```
"a is greater"
"b is greater"
```python
False
```
```python
True
```

## Slide 17
Example: Tax calculation
Task: compute the applicable tax rate, according to income level.
Tax bracket | Income
10% | ₪0 – ₪5,280
14% | ₪5,281 – ₪9,010
21% | ₪9,011 – ₪14,000
31% | ₪14,001 – ₪20,000
34% | ₪20,001 and up
`tax_v1.py`
```python
if income <= 5280:
    rate = 0.10
else:
    if income <= 9010:
        rate = 0.14
    else:
        if income <= 14000:
            rate = 0.21
        else:
            if income <= 20000:
                rate = 0.31
            else:
                rate = 0.34
```
Nested ifs: each level pushes the code further right.

## Slide 18
Example: Tax calculation
Task: compute the applicable tax rate, according to income level.
`tax_v2.py`
```python
if income <= 5280:
    rate = 0.10
elif income <= 9010:
    rate = 0.14
elif income <= 14000:
    rate = 0.21
elif income <= 20000:
    rate = 0.31
else:
    rate = 0.34
```
Chained elif: keeps it flat
Tax bracket | Income
10% | ₪0 – ₪5,280
14% | ₪5,281 – ₪9,010
21% | ₪9,011 – ₪14,000
31% | ₪14,001 – ₪20,000
34% | ₪20,001 and up

## Slide 19
The conditional expression (ternary if)
A one-line if / else that produces a value.
`expression.py`
```python
max_val = a if a >= b else b
```
is exactly the same as
`statement.py`
```python
if a > b:
    max_val = a
else:
    max_val = b
```
Statement vs. Expression
The if statement does something (controls block execution). 
The if expression evaluates to something (a value), so it can appear anywhere a value can.
The word order
Python puts the value first and the condition second. It reads like English: take a, if a >= b, otherwise b.

## Slide 20
The conditional expression (ternary if)
Syntax
```python
Syntax
```
```python
expression_1 if condition else expression_2
```
```python
Semantics
If the condition is True -  the expression evaluates to expression_1
Else - the expression evaluates to expression_2.
```

## Slide 21
When to use the conditional expression
`plural.py`
```python
count = 3
word = "items" if count > 1 else "item"
print(f"You bought {count} {word}")
```
```python
terminal
```
```python
You bought 3 items
```
When to use
Use the conditional expression for short, single-line assignments where both outcomes are simple values.
Keeps code simple when used appropriately, but can reduce readability if overused.
When to avoid
Use standard if-else statement if either branch involves complex logic, multiple operations or requires explanation.

## Slide 22
The while loop
Program flow
Conditionals
Loops
Examples
`count_up.py`
```python
n = int(input())
count = 0
while count < n:
    print(count)
    count = count + 1
```
```python
n = int(input())
```
```python
count = 0
```
```python
count < n
```
```python
True
```
```python
print(count)
```
```python
count = count + 1
```
```python
False
```
Count from 0 to n-1

## Slide 23
The while loop
`while.py`
while
```python
condition
```
```python
loop block
```
```python
Semantics
Evaluate condition (True \ False)
If True – execute the loop block and return to step 1.
If False – exit the loop and continue to the next statement.
```
```python
loop block (body) 
# executed while True
```
Syntax
```python
False
```
```python
True
```

## Slide 24
`count_up.py`
```python
n = int(input())
count = 0
while count < n:
    print(count)
    count = count + 1
```
print | count < n | count | n
0 | True | 0 | 3
1 | True | 1 | 3
2 | True | 2 | 3
loop ends | False | 3 | 3
Tracing a loop
By hand, on paper, with small numbers. Here n = 3.

## Slide 25
Always check the edges
What does the loop print for each of these?
n = 3
```python
0
1
2
```
n = 1
```python
0
```
n = 0
n = -3
n = 1000
```python
0
1
2
...
999
```
Two of them print nothing at all. When you write a loop, ask what it does for zero, for one, and for a negative input.

## Slide 26
`count_up.py`
```python
n = int(input())
count = 0
while count < n:
    print(count)
    count = count + 1
```
```python
Three essential moving parts
Initialization: Set the loop variable (count) before entering the loop.
Condition: Evaluated prior to every iteration. 
Update: Modify the loop variable (count) inside the loop-body to ensure termination.
```
The anatomy of a while counted loop
1
2
3

## Slide 27
Augmented assignment
`augmented.py`
```python
count = count + 1     # what we wrote
count += 1            # the same thing
```
Shortcut syntax for updating variable values.
```python
Underlying mechanism
Python evaluates count + 1 first, then re-binds the variable count to the result.
This is standard variable re-binding (as covered in Lecture 1-2).
```
```python
No increment (++) operator
Python does not support i++ or i-- like other languages (C, Java).             Always use i += 1 or i -= 1.
```
```python
+= works for any type supporting addition, including floats and strings.
```
From here on we write it the short way.
The augmented operators
```python
+=
```
```python
-=
```
```python
*=
```
```python
/=
```
```python
//=
```
```python
%=
```
```python
**=
```

## Slide 28
What happens here?
`infinite.py`
```python
count = 10
while count > 0:
    print(count)
    count += 1
```
The intention is to count down from 10 to 1.
Read it before you run it.

## Slide 29
Loop Bug 1 – Infinite loops
`infinite.py`
```python
count = 10
while count > 0:
    print(count)
    count += 1   # wrong way
```
```python
terminal
```
```python
10  11  12  13  14  ...
KeyboardInterrupt
```
The update moves count the wrong way, so the condition never fails.
How to fix it
Make sure the body updates a variable the condition tests, and that the update moves towards ending the loop.
How to spot it
The program prints forever, and the values run away from the bound instead of towards it. Ctrl-C stops it.

## Slide 30
What will this print?
`bug_updates.py`
```python
i = 0
v = 1
while i <= n:
    print(i, v)
i += 1
v *= 2
```
Take n = 3. What appears on the screen?
Read it before you run it.

## Slide 31
Loop Bug 2 — Out-of-block updates
`bug_updates.py`
```python
i = 0
v = 1
while i <= n:
    print(i, v)
i += 1
v *= 2
```
`fixed.py`
```python
i = 0
v = 1
while i <= n:
    print(i, v)
    i += 1
    v *= 2
```
prints 0 1 forever
it ends
The update sits outside the loop body, so nothing advances.
How to spot it
The same output line repeats forever. The body is shorter than you meant — read the indentation, not the intention.
How to fix it
Indent every line that belongs to the loop to the same level under the while.

## Slide 32
How many times does each loop run?
`a.py`
```python
i = 0
while i < 4:
    i += 1
```
`b.py`
```python
i = 0
while i <= 4:
    i += 1
```
Same body, one character apart. What is i when each loop ends?
Read it before you run it.

## Slide 33
Loop Bug 3 – Off-by-one errors
Neither < nor <= is wrong. Using one when you meant the other is.
```python
while i < 4
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
```python
while i <= 4
```
```python
0
```
```python
1
```
```python
2
```
```python
3
```
```python
4
```
How to spot it
The last item is missing, or one extra is included.
How to fix it
Trace the first and the last pass with small values, and check the boundary.

## Slide 34
What is total at the end?
`bug_reinit.py`
```python
while i < n:
    total = 0
    total += i
    i += 1
```
Take i = 0 and n = 4. What does total hold?
Read it before you run it.

## Slide 35
Loop Bug 4 – Variable re-initialization
`correct.py`
```python
total = 0
while i < n:
    total += i
    i += 1
```
`bug_reinit.py`
```python
while i < n:
    total = 0
    total += i
    i += 1
```
total survives
total resets
How to spot it
The answer is plausible but wrong — usually the value of the last pass alone. Nothing crashes.
The accumulator is initialized inside the loop, so it resets.
How to fix it
Initialize before the loop, not inside it. Ask of every line: should this happen once, or every time?

## Slide 36
Example: Powers of two
Program flow
Conditionals
Loops
Examples
`powers.py`
```python
n = int(input("n: "))
i = 0
v = 1
while i <= n:
    print(i, v)
    i += 1
    v *= 2
```
```python
terminal
```
```python
0 1
1 2
2 4
3 8
4 16
5 32
6 64
```
i counts, v doubles — and these are the column values of binary.
Task: print powers of two 20, 21, 22, ..., 2n

## Slide 37
Example: Digit sum
Task: Add up the digits of a given number. E.g., 4913 outputs 4 + 9 + 1 + 3 = 17.
`digit_sum.py`
```python
n = int(input("Number: "))
total = 0
while n > 0:
    digit = n % 10
    total += digit
    n = n // 10    # or n //= 10
print("Digit sum:", total)
```
n | digit | total
4913 | 3 | 3
491 | 1 | 4
49 | 9 | 13
4 | 4 | 17
```python
Digit extraction in base 10
Extracting digits: n % 10 extracts the last (rightmost) digit.
Removing digits: n // 10 strips the last digit, shrinking n toward 0 to end the loop.
```
What does it do for n = 0? 

## Slide 38
```python
Minimum finding pattern
First input as baseline: smallest must start with an actual value from the stream.
Priming read: Fetching input outside the loop enables direct smallest = x initialization.
Order matters: Updating x at the end of the loop keeps sentinel checks reliable.
```
Example: Minimum value
Processing a sequence of unknown length using a sentinel-controlled loop
`smallest.py`
```python
x = int(input("Number (-1 to finish): "))
smallest = x
while x != -1:
    if x < smallest:
        smallest = x
    x = int(input("Number (-1 to finish): "))
if smallest == -1:
    print("No numbers were entered.")
else:
    print("Smallest:", smallest)
```
```python
Sentinel loop pattern
Stream control: Using while to process data stream of unpredictable length, until a stop value (-1) is met.
Named Constant: Define END = -1 to avoid magic numbers and improve readability.
```
Task: Read non-negative numbers until a sentinel value (-1) is entered. 
Output the minimum value, or report if no input was provided.
```python
END = -1 
```
```python
END: 
```
```python
END: 
```

## Slide 39
The run for 8, 3, 9, 1, 6, -1
```python
The line never rises: smallest can only go down, and no bar ever reaches below it.
Then -1 arrives, the loop ends, and the line is the answer.
```
```python
8
```
```python
8
```
```python
3
```
```python
3
```
```python
9
```
```python
3
```
```python
1
```
```python
1
```
```python
6
```
```python
1
```
smallest
Input numbers
smallest
`smallest.py`
```python
x = int(input("Number (-1 to finish): "))
smallest = x
while x != -1:
    if x < smallest:
        smallest = x
    x = int(input("Number (-1 to finish): "))
if smallest == -1:
    print("No numbers were entered.")
else:
    print("Smallest:", smallest)
```
```python
END: 
```
```python
END: 
```
```python
END = -1 
```
Tracing the minimum value

## Slide 40
Example: Input validation
Repeat until valid input is entered.
`validate.py`
```python
grade = int(input("Grade (0-100): "))
while not (0 <= grade <= 100):
    print("That is not a valid grade.")
    grade = int(input("Grade (0-100): "))
print("Grade recorded:", grade)
```
Unknown number of iterations
The number of iterations is unknown in advance - it depends on runtime user input. A fixed counter cannot handle this pattern.
Code duplication note
Notice the input() line appears twice (before and inside the loop). How can we avoid it ?

## Slide 41
The break statement
Exiting a loop directly from within its body
`validate_break.py`
```python
while True:
    grade = int(input("Grade (0-100): "))
    if 0 <= grade <= 100:
        break
    print("That is not a valid grade.")
print("Grade recorded:", grade)
```
```python
Semantics
break terminates the innermost enclosing loop immediately. Execution jumps directly to the first statement following the loop, skipping any remaining loop tests.
```
```python
The while True pattern
Creates an intentional infinite loop whose exit condition is dynamically evaluated inside the loop body using break.
```
Use while condition when the exit test is known before the pass; 
use while True with break when the exit test occurs mid-iteration.

## Slide 42
Example: a random point inside the circle
Task: Generate a random point that lands inside the unit circle (radius 1, centered at the origin). 
`point.py`
```python
import random

while True:
    # generate random x,y in [-1,1)
    x = 2.0 * random.random() - 1.0
    y = 2.0 * random.random() - 1.0
    if x * x + y * y <= 1.0:
        break
print("Inside:", x, y)
```
Accepted and rejected
Navy dots landed inside the circle and end the loop. 
Orange crosses are thrown away.

## Slide 43
Nested loops
`square.py`
```python
i = 0
while i < 3:
    j = 0
    while j < 3:
        print("*", end="")
        j += 1
    print()
    i += 1
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
three rows of three
j is reset inside the outer loop
The inner loop runs to the end on every pass of the outer one. 
Putting j = 0 in the wrong place is the classic nested-loop bug.
```python
end="" leaves out the newline; print() supplies it.
```

## Slide 44
Tracing the nested loop
Nine passes of the inner loop, three of the outer.
pass
i
j
prints
```python
1
```
```python
0
```
```python
0
```
```python
*
```
```python
2
```
```python
0
```
```python
1
```
```python
*
```
```python
3
```
```python
0
```
```python
2
```
```python
*   then a newline
```
```python
4
```
```python
1
```
```python
0
```
```python
*
```
```python
5
```
```python
1
```
```python
1
```
```python
*
```
```python
6
```
```python
1
```
```python
2
```
```python
*   then a newline
```
```python
7
```
```python
2
```
```python
0
```
```python
*
```
```python
8
```
```python
2
```
```python
1
```
```python
*
```
```python
9
```
```python
2
```
```python
2
```
```python
*   then a newline
```
```python
0
```
```python
1
```
```python
2
```
```python
j
```
```python
0
```
```python
1
```
```python
2
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
*
```
```python
i
```

## Slide 45
Self practice
Write programs that output the following:
square
נ
```python
***
***
***
```
left
```python
*
**
***
```
right
```python
  *
 **
***
```
centered
```python
  *  
 *** 
*****
```
The outer structure never changes. Only the number of stars per row, and where the row starts.
✓

## Slide 46
Lecture summary
Conditional
if
if-else
elif
The conditional expression
Sequential
Execution line-by-line in order.
Fundamental program flow structures
Iterative (loops)
while
for (in next lecture)
statement 1
statement 2
statement 3
```python
test
```
```python
True
```
```python
False
```
```python
A
```
```python
B
```
```python
test
```
```python
True
```
body
```python
False
```
Program flow
Conditionals
Loops
Examples

## Slide 47
PYTHON COURSE · WEEK 2 · LECTURE 2
Next: Loops and numeral systems
for and range(), loop patterns, and numbers in binary


---

# Lecture 2-2: The for loop and numeral systems (week 2)

## Slide 1
PYTHON COURSE · WEEK 2 · LECTURE 2
Loops and Numeral Systems
The for loop, loop patterns, and numbers in binary

## Slide 2
Lecture overview
The for loop
Loop patterns
Numeral systems
Binary
1
The for loop
one pass per item
2
Loop patterns
accumulate, carry forward, nest
3
Numeral systems
positional notation, and why binary
4
Binary
converting both ways

## Slide 3
Recapping while: The cost of manual counting
Explicitly state management forces the programmer to handle loop control manually.
```python
i = 0
while i < 5:
    print(i)
    i += 1
```
Manual loop control is where all four classic loop bugs live. Python’s for loop automates all three parts for you.
`count_up_while.py`
```python
Three essential moving parts
Initialization: Set the loop variable (i) before entering the loop.
Condition: Evaluated prior to every iteration. 
Update: Modify the loop variable (i) inside the loop-body to ensure termination.
```
1
2
3

## Slide 4
The core idea of the for loop
The for loop
Loop patterns
Numeral systems
Binary
`count_up_while.py`
```python
i = 0
while i < 5:
    print(i)
    i += 1
```
`count_up_for.py`
```python
for i in [0,1,2,3,4]:
    print(i)
```
```python
Same behavior, zero manual control
The for loop moves through the sequence [0,1,2,3,4] item by item.
On each iteration, Python automatically rebinds i to the next value.
No explicit initialization, condition, or modification of i are needed in code.
```
Replacing explicit loop mechanics with automated sequence iteration.

## Slide 5
The for loop
```python
syntax
```
```python
for variable in sequence:
    statement_1
    statement_2
```
```python
loop block (body) 
# executed once per item
```
```python
for
```
```python
items left ?
```
```python
True
```
```python
variable = next item
```
```python
loop block
```
```python
False
```
next statement
Semantics
1.  Assign the next item in the sequence to the loop variable.
2.  Execute the loop block.
3.  Return to step 1. When no items are left, exit the loop.
Syntax

## Slide 6
Example: a list of names
The loop takes the items one at a time, in order.
```python
"Messi"
```
```python
"Ronaldo"
```
```python
"Neymar"
```
the sequence, before the loop starts
```python
The variable name
On each pass name is bound to the next item: "Messi", then "Ronaldo", then "Neymar".
```
```python
output
```
```python
Hello, Messi
Hello, Ronaldo
Hello, Neymar
```
`names.py`
```python
for name in ["Messi", "Ronaldo", "Neymar"]:
    print("Hello,", name)
```
The square brackets make a list. Lists are next week; today we only need that a list is something a loop can walk through.

## Slide 7
Generating a sequence with range()
Iterating over [0, 1, 2, 3, 4] is easy. But what if we need 100?
`lines.py`
```python
for count in range(100):
    print("I will not argue ...")
```
```python
output
```
```python
I will not argue ...
I will not argue ...
...
```
```python
Why do we need range() ?
No manual enumeration: Writing explicit lists works for a few elements but becomes impossible for large sequences. 
On-demand generation: range(100) generates 100 values dynamically in memory as needed. 
Dynamic Bounds: Allows iterating over variable ranges like range(n) where n is known only at runtime. 
```

## Slide 8
The range() function
Syntax
```python
the three forms
```
```python
range(stop)
range(start, stop)
range(start, stop, step)
```
The three arguments
start - First value in sequence (default: 0)
stop – Bound where sequence terminates (required).
step – Increment between successive values (default: 1).
```python
How the sequence is built
Inclusive start, exclusive stop: Always includes the start value and excludes the stop value
Guaranteed Count: range(n) always produces exactly n numbers (from 0 to n-1).
Counting down: Use a negative step to count backwards.
Empty Ranges: If bounds cannot be met (like range(5,5)), the loop simply never runs.
```

## Slide 9
Visualizing range() execution
Consistent evaluation across common parameter variations
call
produces
```python
range(5)
```
```python
0 1 2 3 4
```
```python
range(2, 6)
```
```python
2 3 4 5
```
```python
range(0, 10, 2)
```
```python
0 2 4 6 8
```
```python
range(5, 0, -1)
```
```python
5 4 3 2 1
```
```python
Default argument resolution
range(5) is equivalent to range(0, 5, 1) with the defaults filled in.
```

## Slide 10
range() supplies the three moving parts
Mapping arguments directly to the loop control mechanics we wrote by hand.
```python
range
```
```python
range(0, 100, 1)
```
```python
start
```
initialization
```python
i = 0
```
```python
stop
```
condition
```python
i < 100
```
```python
step
```
update
```python
i += 1
```
The control tasks didn't disappear - they moved from explicit code into range() arguments.
```python
What you choose vs.      What Python manages
Your decision: Define which values to iterate over - a logical decision based on your problem.
Python's job: Advancing the counter, testing the boundary, and stopping are handled automatically by range() and for.
```

## Slide 11
Assigning to the loop variable
Predict the output:
`no_effect.py`
```python
for i in range(5):
    print(i, end=" ")
    i = 10
    print(i)
```
```python
output
```
```python
0 10
1 10
2 10
3 10
4 10
```
```python
Why ?
range(5) is evaluated once before the loop starts.
At the beginning of each iteration, the for loop rebinds i to the next item in the sequence, completely overwriting any assignment made inside the loop body.
```

## Slide 12
The accumulator pattern
The for loop
Loop patterns
Numeral systems
Binary
Task: sum all the integers from 1 to n.
`sum.py`
```python
total = 0
```
```python
for i in range(1, n + 1):
```
```python
total += i
```
```python
print(total)
```
```python
1
```
```python
2
```
```python
3
```
n = 4 gives 1 + 2 + 3 + 4 = 10.
This pattern is behind sum, average, minimum, maximum and search.
1 · Initialize
Set up the accumulator before the loop, with a starting value.
2 · Update
Change its value inside the loop, once per item.
3 · Use
Read or print it after the loop has finished.

## Slide 13
Tracing the sum accumulator
n = 4. One row per iteration.
pass
i
total += i
total
```python
1
```
```python
1
```
```python
0 + 1
```
```python
1
```
```python
2
```
```python
2
```
```python
1 + 2
```
```python
3
```
```python
3
```
```python
3
```
```python
3 + 3
```
```python
6
```
```python
4
```
```python
4
```
```python
6 + 4
```
```python
10
```
`sum.py`
```python
total = 0
for i in range(1, 5):
    total += i
print(total)   # 10
```
```python
What makes total an Accumulator
total holds the sum of all the numbers seen so far. 
Once the loop finishes, it holds the total sum of all numbers.
```
```python
-
```
```python
-
```
```python
-
```
```python
0
```

## Slide 14
Example: n factorial
Task: compute n! = 1 × 2 × … × n.
`factorial.py`
```python
factorial = 1
```
```python
for i in range(1, n + 1):
```
```python
factorial *= i
```
```python
print(factorial)
```
```python
1
```
```python
2
```
```python
3
```
n = 5 gives 120.
range(1, n + 1), not range(n).
Starting at 0 would zero the product.
1 · Initialize
factorial = 1, not 0. Zero would annihilate every multiplication.
2 · Update
factorial *= i. The result is a product, so each item multiplies rather than adds.
3 · Use
print(factorial) after the loop. Inside it, you would print partial products.

## Slide 15
Example: The harmonic sum
Task: compute 1 + 1/2 + 1/3 + … + 1/n.
`harmonic.py`
```python
total = 0.0
```
```python
for i in range(1, n + 1):
```
```python
total += 1 / i
```
```python
print(total)
```
```python
1
```
```python
2
```
```python
3
```
n = 4 gives 2.083333333333333.
In Python 3, 1 / i is already a float.
The .0 only states the intent.
1 · Initialize
total = 0.0, not 0. The result is a float, and the first line says so.
2 · Update
total += 1 / i. Addition again, but what is added is the reciprocal of the item.
3 · Use
print(total) after the loop, exactly as before. Only the operation changed.

## Slide 16
The same three parts, three problems
One pattern. Only the starting value and the operation change.
problem
initialize
update
result
```python
sum 1..n
```
```python
total = 0
```
```python
total += i
```
```python
total
```
```python
n factorial
```
```python
factorial = 1
```
```python
factorial *= i
```
```python
factorial
```
```python
harmonic sum
```
```python
total = 0.0
```
```python
total += 1 / i
```
```python
total
```
```python
total = 0
```
```python
0
```
Adding 0 changes nothing.
```python
factorial = 1
```
```python
1
```
Multiplying by 1 changes nothing.
```python
total = 0.0
```
```python
0.0
```
A float zero, for a float result.
The starting value
The value that leaves the accumulator unchanged.
Also the right answer for an empty range: sum 0, product 1.

## Slide 17
Two correct programs, different costs
Both print the powers of two. One does far more work.
`powers_a.py`
```python
for i in range(n + 1):
    print(i, 2 ** i)
```
`powers_b.py`
Version A - Recomputes 2i independently on every iteration.
```python
Version B - The accumulator pattern in action:
1 · Initialize: v = 1
2 · Update: v *= 2
3 · Use: print(i, v) inside the loop.
```
```python
2**0
```
```python
2**1
```
```python
2**2
```
```python
2**3
```
```python
2**4
```
Nothing carries over — the previous value is discarded.
```python
1
```
```python
2
```
```python
4
```
```python
8
```
```python
16
```
```python
× 2
```
```python
× 2
```
```python
× 2
```
```python
× 2
```
One multiplication per iteration, reusing previous values.
```python
v = 1
for i in range(n + 1):
    print(i, v)
    v *= 2
```
`powers_b.py`

## Slide 18
Carrying a value forward
Reusing previous results vs. computing from scratch
```python
The core habit 
Recognize repeated work. Reusing intermediate results is a fundamental optimization technique.
Operations have different costs
Exponentiation (**) performs significantly more low-level work than a single multiplication (*=).
Flexible pattern use
The accumulator pattern isn’t just for calculating a single sum at the end – it’s equally useful for managing running state during iteration.
```

## Slide 19
Iterating over a string
for loops process sequences – and a string is simply a sequence of characters.
`letters.py`
```python
for ch in "binary":
    print(ch)
```
```python
b
```
```python
i
```
```python
n
```
```python
a
```
```python
r
```
```python
y
```
The same diagram as before, carrying characters instead of names.
```python
Direct iteration vs. Indexing
Automatic rebinding: On each iteration, Python automatically rebinds ch to the next character in sequence.
Focus for today: We iterate directly over the characters themselves.
Coming next week: Accessing characters by index, slicing and string methods.
```

## Slide 20
Example: counting one letter
Task: Given a word and a letter, count the number of times the letter appears in the word.
`count_letter.py`
```python
word = input("Enter a word: ")
target = input("Enter a letter to count: ")

count = 0
for ch in word:
    if ch == target:
        count += 1

print(target, "appears", count, "times in", word)
```
```python
output
```
```python
Enter a word: banana
Enter a letter to count: a
a appears 3 times in banana
```
Another variation of the accumulator pattern
Initialize before, update inside, use after.
The sequence is a string now, and the update is conditional.

## Slide 21
Nested for loops
The inner loop completes on every pass of the outer one.
`times_table.py`
```python
n = int(input("n: "))
for i in range(1, n + 1):
    for j in range(1, n + 1):
        print(i * j, end="\t")
    print()
```
```python
n =
```
```python
3
```
```python
i =
```
```python
j =
```
```python
1
```
```python
2
```
```python
3
```
```python
1
```
```python
2
```
```python
3
```
```python
1
```
```python
2
```
```python
3
```
```python
1
```
```python
2
```
```python
3
```
```python
output
```
```python
1
```
```python
2
```
```python
3
```
```python
2
```
```python
4
```
```python
6
```
```python
3
```
```python
6
```
```python
9
```
Three things to point at
The inner loop completes on every pass of the outer loop.
end="\t" suppresses the newline and separates cells with a tab.
The bare print() after the inner loop ends the row.

## Slide 22
In a for loop, inner counter resets itself
Eliminating the most common bug in nested while loops
`nested_while.py`
```python
i = 0
while i < 3:
    j = 0   # forget this
    while j < 3:
        print("*", end="")
        j += 1
    print()
    i += 1
```
Forgetting j = 0 caused inner loop to run only once.
`nested_for.py`
```python
for i in range(3):
    for j in range(3):
        print("*", end="")
    print()
```
There is no j = 0 to forget – Python manages the reset..
```python
How Python handles inner loops
range(3) is evaluated afresh every time the inner loop starts.
j is automatically reassigned to 0 at the start of every outer iteration.
```

## Slide 23
The star patterns, written with for
Last lecture's self-practice, re-solved.
`left.py`
```python
for row in range(1, n + 1):
    for star in range(row):
        print("*", end="")
    print()
```
The line that says it
range(row) means "this row has row stars". The inner loop's range depends on the outer loop's variable, and that dependency is the whole pattern.
row
stars printed
```python
1
```
```python
    *
```
```python
2
```
```python
    **
```
```python
3
```
```python
    ***
```
```python
4
```
```python
    ****
```
Worth setting again
Go back to your own while solutions from last week and rewrite them with for. Comparing two of your own versions of the same program is one of the most useful exercises available this early.

## Slide 24
Counting in Unary: A non-positional numeral system
The for loop
Loop patterns
Numeral systems
Binary
27 goats - one mark per goat.
```python
|||||||||||||||||||||||||||
```
27, in tally marks
A non-positional system
Value = Count: Total value is simply the number of marks.
Position independent: A mark means 1 regardless of where it sits.
Simple & Intuitive: Works perfectly for small, manageable quantities.

## Slide 25
```python
|||||||||||||||||||||||||||||||||||||||
|||||||||||||||||||||||||||||||||||||||
|||||||||||||||||||||||||||||||||||||||
|||||||||||||||||||||||||||||||||||||||
|||||||||||||||||||||||||||||||||||||||
||||||||||||| ...
```
7,053, in tally marks (the first 208)
The limits of Unary
Hard to read & write: Drawing or counting thousands of individual marks is slow and leads to mistakes.
Takes up massive space: Representing large numbers requires an overwhelming number of marks.
Counting in Unary: What happens when quantities grow ?
7,053 goats - one mark per goat.

## Slide 26
Positional numeral system
How base 10 (decimal system) handles 7,053 goats
```python
103
```
```python
7
```
```python
7×103
```
```python
102
```
```python
0
```
```python
0×102
```
```python
101
```
```python
5
```
```python
5×101
```
```python
100
```
```python
3
```
```python
3×100
```
```python
= 7053
```
Base b notation rules (b  2)
The digits: Uses b distinct digits (0 to b-1).
Place values: Position i (from right) determines the value by multiplying the digit by bi.
Decimal system (b=10): Uses digits 0 to 9 and powers of 10.
Why base 10? Driven by human anatomy (10 fingers), not a mathematical requirement.
```python
+
```
```python
+
```
```python
+
```

## Slide 27
The same scheme in base 2 (Binary)
Two digits {0,1}, and positional values that double (powers of 2).
base 10
```python
103
```
```python
7
```
```python
7×103
```
```python
102
```
```python
0
```
```python
0×102
```
```python
101
```
```python
5
```
```python
5×101
```
```python
100
```
```python
3
```
```python
3×100
```
```python
= 7053
```
base 2
```python
23
```
```python
1
```
```python
1×23
```
```python
22
```
```python
1
```
```python
1×22
```
```python
21
```
```python
0
```
```python
0×21
```
```python
20
```
```python
1
```
```python
1×20
```
```python
= 13
```
```python
+
```
```python
+
```
```python
+
```
```python
+
```
```python
+
```
```python
+
```

## Slide 28
Counting in Binary
Zero to fifteen, in both notations.
decimal
binary
```python
0
```
```python
0000
```
```python
1
```
```python
0001
```
```python
2
```
```python
0010
```
```python
3
```
```python
0011
```
```python
4
```
```python
0100
```
```python
5
```
```python
0101
```
```python
6
```
```python
0110
```
```python
7
```
```python
0111
```
decimal
binary
```python
8
```
```python
1000
```
```python
9
```
```python
1001
```
```python
10
```
```python
1010
```
```python
11
```
```python
1011
```
```python
12
```
```python
1100
```
```python
13
```
```python
1101
```
```python
14
```
```python
1110
```
```python
15
```
```python
1111
```
Column patterns & capacity
How bits flip: From right to left, bits alternate every 1, 2, 4 and 8 rows (like an odometer).
Range formula: n bits cover 2n unique values (4 bits cover 24 = 16 values, 0 to 15)

## Slide 29
Why computers use Binary
Minimal
A positional system needs at least two digits. Binary uses exactly two, making it the simplest possible positional system.
Physical
A wire is carrying current or it is not (ON/OFF). That is the only distinction the hardware has to make reliably.
The consequence
People prefer decimal and machines are built on binary, so computers constantly translate between the two representation formats.
Decimal to Binary when inputting a number from the user 
Binary to Decimal when outputting it to the user

## Slide 30
Converting Decimal to Binary
The for loop
Loop patterns
Numeral systems
Binary
Reusing our base-10 digit extraction loop, replacing 10 with 2
`to_binary.py`
```python
x = int(input("n (>= 0): "))
s = ""
while x > 0:
    s = str(x % 2) + s
    x = x // 2
print(s)
```
% 2 gives the next binary digit, // 2 removes it.
```python
Digit extraction in base 2
Extracting digits: n % 2 extracts the last (rightmost) digit.
Removing digits: n // 2 strips the last digit, shrinking n toward 0 to end the loop.
```
```python
Why build a string?
Easier manipulation: string concatenation (+) simply joins digits, avoiding complex positional arithmetic.
Text vs. Number: Storing as a string prevents Python from interpreting 1010 as the decimal number “one thousand and ten”.
```

## Slide 31
Tracing the conversion
x = 26.
pass
x
x % 2
s
x // 2
```python
1
```
```python
26
```
```python
0
```
```python
"0"
```
```python
13
```
```python
2
```
```python
13
```
```python
1
```
```python
"10"
```
```python
6
```
```python
3
```
```python
6
```
```python
0
```
```python
"010"
```
```python
3
```
```python
4
```
```python
3
```
```python
1
```
```python
"1010"
```
```python
1
```
```python
5
```
```python
1
```
```python
1
```
```python
"11010"
```
```python
0
```
```python
16
```
```python
1
```
```python
8
```
```python
1
```
```python
4
```
```python
0
```
```python
2
```
```python
1
```
```python
1
```
```python
0
```
the grid, filled in from the right
```python
26 = 11010
```
the s column, read off the last row
Why the digits are prepended
The loop finds the last digit first: 0, then 1, then 0, then 1, then 1.
Written in that order they would come out backwards, so each new digit joins the front of the string.
26 = 11010.

## Slide 32
What does this print for x = 0?
Read it before you run it.
`to_binary.py`
```python
x = int(input("n (>= 0): "))
s = ""
while x > 0:
    s = str(x % 2) + s
    x = x // 2
print(s)
```
And what does it print for a negative number?

## Slide 33
The zero case
The condition is false immediately, so nothing is printed.
`fixed.py`
```python
x = int(input("n (>= 0): "))
s = ""
if x == 0:
    s = "0"
else:
    while x > 0:
        s = str(x % 2) + s
        x = x // 2
print(s)
```
```python
       How to spot it
The loop body never runs, s keeps its empty value, and the program prints a blank line. The right answer is 0.
Nothing crashes — the output is simply missing.
```
      How to fix it
Handle zero before the loop, and let the loop handle everything else.
A negative number prints nothing too, which is correct only because the prompt asks for a non-negative integer.

## Slide 34
Converting Binary to Decimal
The other direction, and the one that needs a string.
`to_decimal.py`
```python
s = input("Binary number: ")
value = 0
for ch in s:
    value = value * 2 + int(ch)
print(value)
```
1011 gives 11.
```python
8
```
```python
4
```
```python
2
```
```python
1
```
```python
1
```
```python
0
```
```python
1
```
```python
1
```
```python
1
```
```python
2
```
```python
5
```
```python
11
```
value, doubling at each step
Why it works
Each new digit means everything so far is worth twice as much, plus this digit.
The method has a name: Horner's method, and it comes back in later courses.

## Slide 35
When the input is not binary
Checking input validity
`to_decimal_safe.py`
```python
valid = True
for ch in s:
    if ch != "0" and ch != "1":
        valid = False
        break
    value = value * 2 + int(ch)
if valid:
    print(value)
else:
    print("Not a binary number.")
```
What went wrong without it
"hello" raised ValueError on int(ch).
"1021" was accepted in silence and produced nonsense.
The valid flag
A bool that records something learned inside the loop and is read after it.
The loop’s job is to discover. The code after it acts.

## Slide 36
The built-in conversions
`to_binary.py`
```python
x = 26
s = ""
while x > 0:
    s = str(x % 2) + s
    x = x // 2
print(s)
```
`builtin.py`
```python
x = 26
print(bin(x))    # 0b11010
```
`builtin.py`
```python
s = "11010"
print(int(s, 2)) # 26
```
`to_decimal.py`
```python
s = "11010"
value = 0
for ch in s:
    value = value * 2 + int(ch)
print(value)
```
Decimal to Binary
Binary to Decimal
Built-in functions
Our implementations

## Slide 37
Where binary goes from here
Today was one corner of a large subject.
Non-negative integers in binary
today
✓
Binary to decimal
today
✓
Negative integers: two's complement
later
Real numbers: floating point
later
Images, sound, compression, transmission
other courses
Arithmetic implemented in binary
other courses

## Slide 38
Lecture summary
```python
The for loop
Sequence iteration
Runs once per item in a sequence (not just a counter loop). 
The range() function
Generates numbers using range(start, stop, step)- includes start, excludes stop. 
for vs. while
Use for when iterating over a known sequence. 
Use while when waiting for a condition to become true. 
```
Patterns and numbers
The Accumulator Pattern
Initialize before the loop, update inside, use after. 
Efficiency 
Carrying a running value forward beats recalculating it from scratch. 
Positional Systems 
The positional principle works in any base  2; binary is simply base 2. 
Converting between bases
% 2 and // 2 peel the digits off; value = value * 2 + digit reads them back in.
The for loop
Loop patterns
Numeral systems
Binary

## Slide 39
Self practice
Write a program for each of these.
Rewrite with for
Take your while solutions to last week's star patterns and write them with for.
Powers of a base
Read a base b and a count n, and print b⁰ to bⁿ without recomputing a power from scratch.
Count the digits
Read a non-negative integer and print how many digits it has, using % 10 and // 10.
Binary, both directions
Print the binary form of every number from 0 to 15, then read a binary string back and print its decimal value.

## Slide 40
PYTHON COURSE · WEEK 3 · LECTURE 1
Next: Strings, Lists and Tuples
Where for comes into its own, and binary back to decimal


---

# Lecture 2-x: Gambler's ruin (simulation) (week 2)

## Slide 1
Gambler's ruin
Program flow
Conditionals
Loops
Examples
Gambler's ruin
Every flip wins $1 or loses $1. Start at $50, aim for $250.
Same rules, completely different histories. The game ends at $0 or at $250.

## Slide 2
Monte Carlo simulation
The strategy
Flip a coin and see what happens. Repeat many times. Compute statistics.
Why it matters
Used across science, engineering, finance and game design — and often the only tool available when a problem has no formula.
We are not computing an answer. We are estimating one, and the estimate differs every run. That is not a bug.
Seventy games at once — about one in five reaches the goal.

## Slide 3
The simulation in Python
`one_game.py`
```python
cash = start
while 0 < cash < goal:
    if random.random() < 0.5:
        cash += 1
    else:
        cash -= 1
    n_flips += 1
```
`many_games.py`
```python
t = 0
while t < T:
    cash = start
    # ... one game ...
    if cash == goal:
        n_wins += 1
    t += 1
```
We cannot know how many flips — an indefinite loop.
We know exactly how many games — a counted loop.

## Slide 4
Running it
```python
terminal
```
```python
Percentage of winning games: 21.1 %
Average flips per game: 9808.0
```
parameters | coin flips | how long it takes
$50 / $250 / 1000 games | 10 million | under a second
$500 / $2500 / 1000 games | 1 billion | about two minutes
The numbers change every run
That is what estimating looks like. Run it three times and watch the percentage move by a point or two.
Knowing roughly how many operations you are asking for is part of the job — week 8 makes that idea formal.

## Slide 5
Theory and experiment
What the mathematics says
Probability of reaching the goal = start / goal = 50 / 250 = 20%. Expected number of flips = start × (goal − start) = 50 × 200 = 10,000.
What the simulation found
21.1% of games reached the goal, over 9,808 flips per game on average.
The program knew none of that mathematics. It arrived at the same place by flipping coins.
So why simulate, if the formula already answers it?
To validate a theory, or to help reach one. To generate events from a model, for research, training, investing or games. And because in many cases there is no formula at all, and simulation is the only way to get data.
Change 0.5 to 0.49 — a slightly unfair coin — and the mathematics gets much harder. The simulation needs a two-character edit.
