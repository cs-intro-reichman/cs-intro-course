# HW1: Errors, input and arithmetic

Given after week 1.

**Material for this assignment: week 1 only** (lectures 1-1, 1-2; recitation 1, and the code files of that week). Solve it, hint toward it and point to slides using only this material and the Python listed for week 1 in `python-taught.md`, even if the student is already in a later week. Don't suggest or point to anything from week 2 on.

**This is graded work: guide with the hint ladder, never give solution code.**

# Assignment statement

## From `Introduction to CS - Homework 1.docx`

## Introduction to CS: Homework 1
### Getting started
This assignment has two parts. Part I is a self-study exercise about errors; you don't submit it, and you can do it after lecture 1-1. Part II has five programs that you write, test and submit. You can do Part II after lecture 1-2.
Get the code for this assignment from the course's Moodle page (the file HW1.zip), unzip it, and open the HW1 folder in VS Code. It contains:
- count_to_five.py: the program for Part I
- bill3.py, fv_calc.py, num_words.py, ascend.py, time_format.py: the five programs of Part II, to complete
- test_hw1.py: a tester that checks your programs (see Testing your programs)
If you haven't yet, go over the From Zero to Code tutorial on the course website first. It shows how to open a folder in VS Code, edit a file, and run it in the terminal.
### Part I: Experimenting with errors
You will meet many error messages in this course, and some are hard to read at first. A good way to learn them is to cause common errors on purpose and read what Python says. In this part you change a working program, one change at a time, and see what happens.
The program is count_to_five.py, the running example from lecture 1-1:
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```
Run it in the VS Code terminal. You should see this:
```python
% python count_to_five.py
0
1
2
3
4
5
Done
```
Now make the changes below, one at a time. For each change:
- Make the change in the editor and save the file.
- Run the program with python count_to_five.py.
- If there is an error message, read its last line first: it names the kind of error. The lines above it show where.
- Decide what kind of problem it is: an error Python finds before running anything (a syntax error), an error while running (a runtime error), or a program that runs but does the wrong thing (a logical error). Write one sentence that describes what went wrong.
- Undo the change before you make the next one. Or keep a copy of the original file and always start from it.
The changes:
- Change print("Done") to Print("Done")
- Change "Done" to "done"
- Change "Done" to "Done (remove the closing quotation mark)
- Change "Done" to Done (remove both quotation marks)
- Remove the colon at the end of while i < 6:
- Remove the four spaces before print(i)
- Change print(i) to print i
- Change print(i) to print(j)
- Change i = 0 to i = "0"
- Change i = i + 1 to i = i * 1
- Try other changes, as you like.
This part is for your own learning: write down what each error means, and make sure you understand it. Don't submit anything.
Stopping a program. A program with a logical error may never stop (an infinite loop). To stop it, click in the terminal and press Ctrl+C (hold Ctrl and press C).
### Part II: Programs
In this part you write five short programs. They practise reading input, computing with numbers and building output text. They use only what lectures 1-1 and 1-2 cover, so there is no if and no loops yet. Programs 4 and 5 are small riddles because of that.
Rules for all five programs:
- Input. Read each input with input(), one value per line, in the order the program description gives. Use input() with no prompt message, so that your output looks exactly like the examples. Remember that input() always returns a string; convert it with int() or float() when you need a number.
- Output. Print exactly the text shown in the examples: the same words, spaces and punctuation. f-strings (lecture 1-2) are the easiest way to build it.
- No input checks. Unless we say otherwise, in this course you can assume that the inputs are valid, as the program description says. You don't need to write code that checks them.
In the examples below, the lines after the command are what you type, one value per line, followed by what the program prints. To learn more about a function such as math.ceil, search for "python math.ceil": the first result is usually the official Python documentation.
### 1. Bill3 (10 points)
The program bill3.py splits a restaurant bill equally among three diners. It reads four inputs: the names of the three diners, then the bill, a whole number of shekels. It divides the bill by 3 and prints a message:
```python
% python bill3.py
Ron
Lisa
Dan
100
Dear Dan, Lisa, and Ron: pay 34 Shekels each.
```
Implementation notes:
- Each diner's share is rounded up to a whole number, so together the three may pay a little more than the bill. That's fine. To round up, use math.ceil, whose name comes from "ceiling": math.ceil(25.19) is 26. Put import math at the top of the program (lecture 1-2).
- The names are printed in reverse order: Dan, the last name typed, comes first, then Lisa, then Ron.
- The output is a bit wordy on purpose, to practise building text. Start with a simpler version that prints only Pay 34 Shekels each. When that works, write the full message.
### 2. FVCalc (10 points)
A savings account earns interest (⁧ריבית⁩) every year. The program fv_calc.py computes the future value of a sum of money saved in such an account. The formula is:
futureValue = currentValue · (1 + rate)n
The program reads three inputs, in this order:
- the current value, a whole number of dollars, 0 or more
- the yearly interest rate in percent, a whole number from 0 to 100
- the number of years n, a whole number, 0 or more
Two example runs:
```python
% python fv_calc.py
100
10
2
After 2 years, $100 saved at 10.0% will yield $121
```

```python
% python fv_calc.py
25000
6
25
After 25 years, $25000 saved at 6.0% will yield $107296
```
Implementation notes:
- Read the interest rate with float(), so that it prints as 10.0. Divide it by 100 to get the rate in the formula.
- Use the ** operator for "raise to the power".
- The future value is a float, but it is printed as a whole number: int(x) drops the part after the decimal point (it does not round).
A note on money: it can be surprising how interest adds up over time. Look at the second run, and try a few values of your own.
### 3. NumWords (20 points)
The program num_words.py reads a whole number, 0 or more, and prints it in terms of hundreds, tens and ones:
```python
% python num_words.py
517
5 hundreds, 1 tens, and 7 ones.
```

```python
% python num_words.py
35
0 hundreds, 3 tens, and 5 ones.
```

```python
% python num_words.py
8
0 hundreds, 0 tens, and 8 ones.
```
Implementation notes:
- The operators // and % from lecture 1-2 do most of the work.
- Outputs like "1 tens" and "0 hundreds" could be nicer, but leave them as they are for now.
- What happens with a number that has more than 3 digits? Your program will most likely still give a correct answer. Try it.
### 4. Ascend (30 points)
The program ascend.py reads a whole number lim, greater than 0. It generates three random whole numbers from 0 to lim - 1, prints them, and then prints the same three numbers in ascending order. Three example runs (your numbers will be different, since they are random):
```python
% python ascend.py
100
91 3 38
3 38 91
```

```python
% python ascend.py
100
12 71 44
12 44 71
```

```python
% python ascend.py
100
82 38 8
8 38 82
```
Rule: use only what lectures 1-1 and 1-2 teach. In particular, don't use if (lecture 2-1), and don't use Python's min, max or sorted.
Implementation notes:
- For a random whole number from 0 to lim - 1, see the worked example in lecture 1-2 (slide 58), which uses random.random().
- To keep the code short, call the three random numbers a, b and c.
- The built-in function abs (lecture 1-2) helps here: abs(a - b) is the distance between a and b. For two numbers, the larger one is (a + b + abs(a - b)) // 2. Check this on paper with a = 3, b = 8, and then with a = 8, b = 3. Then work out a similar expression for the smaller one.
- Use these two-number expressions to find the smallest and the largest of a, b and c. Then work out how to find the middle one. This is a small riddle, best solved on paper, away from the computer.
### 5. TimeFormat (30 points)
The program time_format.py reads a time in the 24-hour format and prints it in the 12-hour AM/PM format. It reads two inputs: the hours, then the minutes. Each is typed as two digits, with a leading 0 when needed. Example runs:
```python
% python time_format.py
10
15
10:15 AM
```

```python
% python time_format.py
12
05
12:05 PM
```

```python
% python time_format.py
17
08
5:08 PM
```

```python
% python time_format.py
23
50
11:50 PM
```

```python
% python time_format.py
00
00
0:00 AM
```
Input rules. The hours are from 00 to 23 and the minutes from 00 to 59, always two digits: 5 hours and 8 minutes is typed as 05, then 08. Midnight is 00, 00.
Output rules. The hours are printed as a number from 0 to 12, without a leading 0 (8, not 08). Hours 13 to 23 become 1 to 11; hours 0 to 12 stay as they are. The minutes are printed exactly as they were typed, two digits. Then a space and AM (hours 0 to 11) or PM (hours 12 to 23).
Rule: don't use if; we learn it in lecture 2-1. Use arithmetic and string operations from lecture 1-2 instead.
Implementation notes:
- Read the minutes as a string, so that a leading 0 is kept. Convert only the hours to an int.
- For hours from 0 to 23, hours // 12 is 0 before noon and 1 from noon on. What is hours // 13?
- A string times a number repeats it (lecture 1-2), and a string times 0 is the empty string: "AM" * 0 is "".
### Testing your programs
First test each program yourself, with the examples above and with inputs of your own. Then run the tester, from the HW1 folder:
```python
% python test_hw1.py
```
It runs each program on several inputs and prints PASS or FAIL for each test; for a FAIL it shows the expected output and yours. For Ascend and TimeFormat it also checks the rules (no if, min, max or sorted). Passing all the tests doesn't guarantee full points: the graders run other inputs too, and they read your code.
### Submission
Please upload these files only (don’t use zip or compression, just direct upload) into the submission box on Moodle:
```python
bill3.py
fv_calc.py
num_words.py
ascend.py
time_format.py
```

## From `count_to_five.py`

### `count_to_five.py`
```python
# Declares a variable and sets it to 0
i = 0
while i < 6:
    # Prints i, and increments it
    print(i)
    i = i + 1
print("Done")
```

## From `bill3.py`

### `bill3.py`
```python
# Homework 1, program 1: Bill3
# Splits a restaurant bill equally among three diners.
# Input: three names and the bill (a whole number), each on its own line.

# Write your code here.
```

## From `fv_calc.py`

### `fv_calc.py`
```python
# Homework 1, program 2: FVCalc
# Computes the future value of a sum saved in a savings account.
# Input: the sum, the yearly interest rate (in percent) and the number of
# years, each on its own line.

# Write your code here.
```

## From `num_words.py`

### `num_words.py`
```python
# Homework 1, program 3: NumWords
# Prints a number in terms of hundreds, tens and ones.
# Input: a whole number.

# Write your code here.
```

## From `ascend.py`

### `ascend.py`
```python
# Homework 1, program 4: Ascend
# Prints three random numbers, then the same numbers in ascending order.
# Input: lim, a whole number greater than 0.
# Don't use if, min, max or sorted.
import random

# Write your code here.
```

## From `time_format.py`

### `time_format.py`
```python
# Homework 1, program 5: TimeFormat
# Prints a 24-hour time in the 12-hour AM/PM format.
# Input: the hours and the minutes, each on its own line, as two digits (17, then 08).
# Don't use if.

# Write your code here.
```


# Instructor's notes for the tutor (guidance only: do not quote these to the student as an answer)

# HW1 notes for the tutor

Given after week 1 (Part I after lecture 1-1, Part II after lecture 1-2). Everything uses only lectures
1-1 and 1-2: no `if`, no loops in Part II, no slicing, no `min`/`max`/`sorted`, no `random.randint`.
Students read input with `input()` (one value per line, no prompt) and print with `print` and f-strings.
The tester (`test_hw1.py`, which students have) compares the end of the last output line.

## Part I (not submitted)
Ten deliberate changes to `count_to_five.py` (lecture 1-1). The point is to tell apart the three kinds
of error (syntax, runtime, logical; lecture 1-1 slide 43) and to read a traceback (last line first).
Part I isn't graded, so you can explain each result fully once the student has tried it. Expected results:
1. `Print("Done")`: NameError, but only after 0 to 5 are printed (a runtime error: Python ran the
   lines before it).
2. `"done"`: no error; the output is different (it is not a Python error at all).
3. `"Done)`: SyntaxError, unterminated string literal. Nothing is printed: syntax errors are found
   before the program runs.
4. `Done` without quotes: NameError after the loop, `Done` is read as a variable name.
5. `while i < 6` without the colon: SyntaxError, expected ':'.
6. `print(i)` not indented: IndentationError, expected an indented block.
7. `print i`: SyntaxError, missing parentheses in call to print.
8. `print(j)`: NameError on the first pass of the loop.
9. `i = "0"`: TypeError, `<` between str and int.
10. `i = i * 1`: no error message, the program never stops (a logical error). Ctrl-C stops it.

## Program 1: Bill3 (10 points)
Concepts: `input()` returns a string, `int()`, `/` gives a float, `math.ceil` (with `import math`), f-strings.
Usual mistakes: names printed in input order instead of reversed; using `//` (rounds down, not up)
or `round` (rounds to nearest); forgetting `import math`; adding 1 after truncating (wrong when the
amount divides by 3).

## Program 2: FVCalc (10 points)
Concepts: `float(input())`, `**`, `int()` truncation, f-strings, precedence.
Usual mistakes: using the percent as the rate (forgetting to divide by 100); reading the rate with
`int` so it prints `6` instead of `6.0`; `round` instead of `int`; missing brackets around `1 + rate`
before raising to the power.

## Program 3: NumWords (20 points)
Concepts: `//` and `%`.
Usual mistakes: `n / 100` (a float); getting the tens digit with `// 10` alone (gives 51 for 517,
so ask what else is needed to keep only one digit). For more than three digits the hundreds part
keeps the extra digits (51422 gives 514 hundreds); that is expected by the spec.

## Program 4: Ascend (30 points)
Concepts: random numbers from `random.random()` (lecture 1-2 slide 58), `abs`, `//`, arithmetic.
Rules: no `if`, `min`, `max` or `sorted` (the tester checks the code for them).
The statement gives a formula for the larger of two numbers. The student has to work out the
smaller of two, then extend both to three numbers, then find the middle one. This is the riddle of
the assignment, so don't give these formulas or the way to combine them.
Hint ladder: first have them check the given formula by hand on two pairs of numbers and explain why
it works; then ask what they would change to get the smaller one; then ask how they could use the
two-number result together with the third number; for the middle, ask what they know about the three
numbers once they have the smallest and the largest.
Usual mistakes: `/ 2` instead of `// 2` (prints 38.0); a random-number expression that can produce
`lim` itself (ask them for the largest value `random.random()` can return); using `round`; printing
only the sorted line; output not matching the example line format.

## Program 5: TimeFormat (30 points)
Concepts: `int(input())`, keeping the minutes as a string, `//`, string times int.
No `if` (lecture 2-1 comes later), so it is an arithmetic riddle. The statement gives three hints:
what `hours // 12` gives, the question "what is `hours // 13`?", and that a string times 0 is "".
The student has to turn these into the 12-hour value and the AM/PM suffix. Don't give the final
expressions; work through the hints with them, for example with a table of hours 0, 11, 12, 13, 23
and what each hint expression gives.
Edge cases students miss: 12:xx is PM and stays 12; 00:xx prints as 0:xx AM (by the spec, not
12:xx); minutes keep their leading zero (so don't convert them with `int`).
Usual mistakes: an expression that turns 12 into 0 (ask them to test 12:30); using `% 12` (same problem).


---

# HW2: Conditionals and loops

Given after week 2.

**Material for this assignment: weeks 1 to 2 only** (lectures 1-1, 1-2, 2-1, 2-2; recitations 1, 2, and the code files of those weeks). Solve it, hint toward it and point to slides using only this material and the Python listed for weeks 1 to 2 in `python-taught.md`, even if the student is already in a later week. Don't suggest or point to anything from week 3 on.

**This is graded work: guide with the hint ladder, never give solution code.**

# Assignment statement

## From `Introduction to CS - Homework 2.docx`

## Introduction to CS: Homework 2
### Getting started
In this assignment you write, test and submit five programs. They practise conditions and loops: if, while and for (lectures 2-1 and 2-2).
Rule: use only what lectures 1-1 to 2-2 teach. In particular, don't use string indexing or slicing (s[0], s[0:2]), string methods such as upper or find, or the in operator as a test (ch in s). These come in lecture 3-1. Looping over a string with for ch in s is fine (lecture 2-2).
Get the code for this assignment from the course's Moodle page (the file HW2.zip), unzip it, and open the HW2 folder in VS Code. It contains:
- time_calc.py, test_random.py, cheers.py, calc_pi.py, collatz.py: the five programs, to complete
- test_hw2.py: a tester that checks your programs (see Testing your programs)
Rules for all five programs:
- Input. Read each input with input(), one value per line, in the order the program description gives. Use input() with no prompt message, so that your output looks exactly like the examples.
- Output. Print exactly the text shown in the examples: the same words, spaces and punctuation.
- No input checks. Unless we say otherwise, you can assume that the inputs are valid, as the program description says. You don't need to write code that checks them.
In the examples below, the lines after the command are what you type, one value per line, followed by what the program prints.
### 1. TimeCalc (20 points)
The program time_calc.py reads a time in the 24-hour hh:mm format and a number of minutes to add. It computes the time plus the minutes, and prints the result in the same hh:mm format. For example, 10:30 plus 4055 minutes is 06:05. Here is one way to calculate it:
- Total minutes: 10 × 60 + 30 + 4055 = 4685
- Total hours: 4685 // 60 = 78
- New hours: 78 % 24 = 6 (the hours go round the clock every 24 hours)
- New minutes: 4685 − 78 × 60 = 5, which is also 4685 % 60
- So the answer is 06:05.
Some example runs:
```python
% python time_calc.py
10:20
30
10:50
```

```python
% python time_calc.py
10:20
40
11:00
```

```python
% python time_calc.py
09:25
700
21:05
```

```python
% python time_calc.py
10:30
4055
06:05
```

```python
% python time_calc.py
22:07
12345
11:52
```

```python
% python time_calc.py
23:59
10
00:09
```
Input rules. The time is typed on one line: two digits, a :, and two digits. Both parts have a leading 0 when needed: 5 hours and 8 minutes is 05:08, and midnight is 00:00. The hours are from 00 to 23 and the minutes from 00 to 59. The minutes to add are a whole number, 0 or more, on the next line.
Output rules. The same as the input rules: two digits, a :, two digits. This is different from the output of the TimeFormat program in Homework 1.
Implementation notes:
Reading the time. input() gives the time as one string, such as "09:25". In lecture 2-2, to_decimal.py read a binary number one character at a time: value = value * 2 + int(ch). Do the same in base 10, with two values: the digits before the : build the hours, and the digits after it build the minutes. A flag (lecture 2-2) can record whether the : has been seen yet.
Work in stages. Start with a program that reads the inputs and prints them, and nothing else:
```python
% python time_calc.py
09:30
1475
Hours: 9
Minutes: 30
Minutes to add: 1475
```
Next, compute the new hours and minutes, and print them too, as whole numbers:
```python
New hours: 10
New minutes: 5
```
Once the calculation is right, turn these lines into comments (put # in front of them), and write the final version, which prints the time by the output rules: 10:05.
The leading 0. str(5) is "5". Use if to add a "0" in front when it is needed.






### 2. How random is random.random()? (15 points)

(Dilbert, by Scott Adams, © 2001 United Feature Syndicate)
How good is Python's random number generator, random.random()? Here is one possible test. Call random.random() n times, and count how many of the numbers are greater than 0.5 and how many are less than or equal to 0.5. If the numbers are spread evenly between 0 and 1, the ratio between the two counts should get closer to 1 as n grows.
The program test_random.py reads n, a whole number 0 or more, and performs this test. Example runs (your numbers will be different):
```python
% python test_random.py
100
> 0.5:  47 times
<= 0.5: 53 times
Ratio:  0.8867924528301887
```

```python
% python test_random.py
10000
> 0.5:  4986 times
<= 0.5: 5014 times
Ratio:  0.994415636218588
```

```python
% python test_random.py
3
> 0.5:  3 times
<= 0.5: 0 times
```
The last example shows an important edge case. It can happen that every number is greater than 0.5, as in the cartoon. Then the program must not compute the ratio: the calculation would stop the program with a runtime error (do you see why?). In that case it prints only the first two lines. The program must handle this case.
Implementation notes:
- Call random.random() exactly once for each of the n numbers. The tester relies on this.
- The ratio is the first count divided by the second. Print it as it is, without rounding.
### 3. Cheers (15 points)
The program cheers.py reads a word and a whole number, 0 or more, and prints a crowd cheer. For example:
```python
% python cheers.py
RUNI
5
Give me an R: R!
Give me a  U: U!
Give me an N: N!
Give me an I: I!
What does that spell?
RUNI!!!
RUNI!!!
RUNI!!!
RUNI!!!
RUNI!!!
```
The word has capital letters only, and no spaces. For each letter, the program prints "an" if the letter is one of A, E, F, H, I, L, M, N, O, R, S, X (their names start with a vowel sound: "an R"), and "a" otherwise. After "a" there are two spaces, so that the letters line up. The number says how many times to print the word at the end.
Implementation notes:
- Work in stages. First write a loop that prints only the "Give me" lines, all with "a". Then add the a / an rule. Finally, add the last lines with a second loop.
- To find out whether a letter is one of the twelve, loop over the string "AEFHILMNORSX" and compare. A flag remembers what the loop found, like the valid flag in lecture 2-2.
- What should the program print when the number is 0? Try it.
### 4. CalcPi (20 points)
Consider this sum:
1 − 1/3 + 1/5 − 1/7 + 1/9 − 1/11 + …
The mathematicians Gregory and Leibniz discovered that as the number of terms grows, the sum gets closer and closer to π / 4. The program calc_pi.py uses this sum to approximate π. It reads one input, the number of terms to add, a whole number 0 or more. Two example runs:
```python
% python calc_pi.py
10
pi according to Python: 3.141592653589793
pi, approximated:       3.0418396189294032
```

```python
% python calc_pi.py
1000
pi according to Python: 3.141592653589793
pi, approximated:       3.140592653839794
```
The first line is Python's own value of π, the constant math.pi (after import math), for comparison.
Implementation notes:
- With 10 terms, the sum is 1 − 1/3 + … − 1/19, and the program prints 4 times the sum.
- The signs alternate: +, −, +, −, … Keep the sign in a variable and flip it on each pass (carrying a value forward, lecture 2-2), instead of computing a power of −1 each time.
- Try a few values. How many terms does it take to get the first 4 digits of π right?
### 5. Collatz Conjecture (30 points)
A hailstone sequence is made like this. Start with a whole number greater than 0, called the seed. Then: (1) if the current number is even, divide it by 2; otherwise, multiply it by 3 and add 1. (2) Repeat. Here are the first 7 hailstone sequences (the first number in each is the seed):
```python
1, 4, 2, 1, 4, 2, 1, ...
2, 1, 4, 2, 1, 4, 2, 1, ...
3, 10, 5, 16, 8, 4, 2, 1, 4, 2, 1, ...
4, 2, 1, 4, 2, 1, ...
5, 16, 8, 4, 2, 1, 4, 2, 1, ...
6, 3, 10, 5, 16, 8, 4, 2, 1, 4, 2, 1, ...
7, 22, 11, 34, 17, 52, 26, 13, 40, 20, 10, 5, 16, 8, 4, 2, 1, 4, 2, 1, ...
```
These examples suggest that hailstone sequences tend to reach the number 1. In 1937 the mathematician Lothar Collatz suggested that for every seed, the hailstone sequence eventually reaches 1. This seems to be true, but to this day nobody has proved it (which is why it is called a conjecture, not a theorem). It is one of the best-known unsolved problems in mathematics.
The program collatz.py tests the Collatz conjecture for all the seeds from 1 to n. It reads two inputs: n, a whole number 1 or more, and a mode, which is v (verbose) or c (concise). In verbose mode, the program prints every sequence, from seed 1 to seed n. For each sequence, it prints the numbers until the sequence reaches 1, and then, in brackets, how many numbers it printed. Finally it prints a summary line. In concise mode, the program prints only the summary line.
If the program ends and prints the summary line, it has checked the conjecture up to n. Two example runs:
```python
% python collatz.py
7
v
1 4 2 1 (4)
2 1 (2)
3 10 5 16 8 4 2 1 (8)
4 2 1 (3)
5 16 8 4 2 1 (6)
6 3 10 5 16 8 4 2 1 (9)
7 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 (17)
Every one of the first 7 hailstone sequences reached 1.
```

```python
% python collatz.py
100
c
Every one of the first 100 hailstone sequences reached 1.
```
Implementation notes:
- Work in stages. Start with a loop that prints one hailstone sequence only, for one seed, and test it on several seeds. Then put this loop inside an outer loop that goes over the seeds from 1 to n. Finally, add the verbose / concise modes.
- Look at seed 1: its sequence is 1 4 2 1, not just 1. The loop must make at least one step before it checks whether it reached 1. The while True loop with break (lecture 2-1) fits this.
- To print several numbers on one line, use print(x, end=" ") (lecture 2-1). The count in brackets includes the seed and the final 1.
- Compare strings with ==: mode == "v".
- Try concise mode with large values of n, such as 100000.
### Testing your programs
First test each program yourself, with the examples above and with inputs of your own. Then run the tester, from the HW2 folder:
```python
% python test_hw2.py
```
It runs each program on several inputs and prints PASS or FAIL for each test; for a FAIL it shows the expected output and yours. For TestRandom it controls what random.random() returns, so it can check exact output, including the edge case. Passing all the tests doesn't guarantee full points: the graders run other inputs too, and they read your code.
### Submission
Upload only the following files to the Moodle submission bix:
```python
time_calc.py
test_random.py
cheers.py
calc_pi.py
collatz.py
```

## From `time_calc.py`

### `time_calc.py`
```python
# Homework 2, program 1: TimeCalc
# Adds minutes to a 24-hour time and prints the new time.
# Input: a time as hh:mm (for example 09:25), then the number of minutes to add,
# each on its own line.

# Write your code here.
```

## From `test_random.py`

### `test_random.py`
```python
# Homework 2, program 2: TestRandom
# Tests how evenly random.random() splits its values around 0.5.
# Input: n, the number of calls, a whole number 0 or more.
import random

# Write your code here.
```

## From `cheers.py`

### `cheers.py`
```python
# Homework 2, program 3: Cheers
# Prints a crowd cheer for a word.
# Input: a word (capital letters only), then a whole number 0 or more,
# each on its own line.

# Write your code here.
```

## From `calc_pi.py`

### `calc_pi.py`
```python
# Homework 2, program 4: CalcPi
# Approximates pi with the series 1 - 1/3 + 1/5 - 1/7 + ...
# Input: the number of terms, a whole number 0 or more.
import math

# Write your code here.
```

## From `collatz.py`

### `collatz.py`
```python
# Homework 2, program 5: Collatz
# Checks the Collatz conjecture for every seed from 1 to n.
# Input: n (a whole number, 1 or more), then the mode, v or c,
# each on its own line.

# Write your code here.
```


# Instructor's notes for the tutor (guidance only: do not quote these to the student as an answer)

# HW2 notes for the tutor

Given after week 2 (lectures 2-1 and 2-2). Students may use only lectures 1-1 to 2-2: `if`/`elif`/`else`,
the conditional expression, `while`, `while True` with `break`, `for` over `range` or over a string,
flags, `end=` in `print`, f-strings, `str()`, `int()`. Not allowed yet: string indexing or slicing,
string methods (`upper`, `find`, `split`), and `in` as a test (`ch in s`); these come in lecture 3-1.
Input is read with `input()`, one value per line, no prompt. The tester (`test_hw2.py`) compares whole
outputs, so spaces and punctuation matter. Give hints, not code.

## 1. TimeCalc
Concepts: a loop over a string, building a number digit by digit (like `to_decimal.py` in lecture 2-2,
but in base 10), a flag, `//` and `%`, `if` for the leading 0.
Hint ladder: do the example 10:30 + 4055 by hand with the steps in the statement; write the stage that
only prints the parsed hours and minutes; ask how `to_decimal.py` read "1011" and what should change when
the loop meets the colon; then ask what the hours should be after going round the clock.
Usual problems: hours over 23 (missing round-the-clock step); missing leading 0; `int(":")` errors.

## 2. TestRandom
Concepts: a counted loop, a counter, `random.random()`, a guard against division by zero.
Hint ladder: what are the two counts when n is 3 and every number is above 0.5? What does the ratio
need then? Is n = 0 also a problem?
Usual problems: crashing with ZeroDivisionError; calling `random.random()` more than once per number
(the counts then don't add up, and the tester fails); output spacing.

## 3. Cheers
Concepts: `for ch in word`, a nested loop over a string of letters, a flag, a second loop that repeats.
Hint ladder: the statement's stages; for a / an, recall the `valid` flag in lecture 2-2: what does
the loop need to discover, and where must the flag start for each letter?
Usual problems: one space after "a" (there are two); the flag not reset for each letter.

## 4. CalcPi
Concepts: the accumulator pattern, carrying a value forward (the sign), float division.
Hint ladder: write the first three terms by hand; which part changes from term to term? How can the
sign be kept from one pass to the next instead of being recomputed?
Usual problems: one term too many or too few; forgetting to multiply by 4.

## 5. Collatz
Concepts: nested loops, `while True` with `break`, `print(..., end=" ")`, comparing strings with `==`.
Hint ladder: one sequence for one seed; what should seed 1 print, and what does that say about when the
loop tests for 1; then the outer loop over the seeds; then the two modes.
Usual problems: seed 1 printed as `1 (1)`; the count off by one; `/` instead of `//`.


---

# HW3: Loans and anagrams

Given after week 3.

**Material for this assignment: weeks 1 to 3 only** (lectures 1-1, 1-2, 2-1, 2-2, 3-1, 3-2; recitations 1, 2, 3, and the code files of those weeks). Solve it, hint toward it and point to slides using only this material and the Python listed for weeks 1 to 3 in `python-taught.md`, even if the student is already in a later week. Don't suggest or point to anything from week 4 on.

**This is graded work: guide with the hint ladder, never give solution code.**

# Assignment statement

## From `Introduction to CS - Homework 3.docx`

## Introduction to CS: Homework 3
### Getting started
In this assignment you write, test and submit four programs. Programs 1 and 2 use the approximation algorithms of lecture 3-2 on a real problem: paying back a loan. Programs 3 and 4 practise the strings of lecture 3-1.
Rule: use only what lectures 1-1 to 3-2 teach. In particular, don't define functions (def, lecture 4-1), don't use lists, and don't use sorted, split, join, min, max or random.randint. The tester checks this.
Get the code for this assignment from the course's Moodle page (the file HW3.zip), unzip it, and open the HW3 folder in VS Code. It contains:
- end_balance.py, loan_calc.py, anagram.py, random_anagram.py: the four programs, to complete
- loan calc.xlsx: a spreadsheet for Part A
- test_hw3.py: a tester that checks your programs (see Testing your programs)
Rules for all four programs:
- Input. Read each input with input(), one value per line, in the order the program description gives. Use input() with no prompt message.
- Output. Print exactly the text shown in the examples, the same words, spaces and punctuation.
- No input checks. You can assume that the inputs are valid, as the program description says.
### Part A: Loan calculations (50 points)
Suppose you take a loan of 100,000 shekels at a yearly interest rate of 5%, for 10 years, with equal yearly payments. How much should you pay each year, so that at the end of the 10th year the loan is fully paid?
Say you pay 10,000 shekels a year. At the end of the first year you still owe (100,000 − 10,000) × 1.05 = 94,500. At the end of the second year you owe (94,500 − 10,000) × 1.05 = 88,725. With n equal payments, we repeat this calculation n times and look at the balance at the end. The spreadsheet loan calc.xlsx does exactly this:

If the ending balance is positive, you still owe money so the payment is too low. If it is negative, you paid too much.
Start by playing with the spreadsheet, open it in Excel or Google Sheets and try different payments until the ending balance is close to zero, say a few shekels. That payment is the answer.
Isn't there a formula for this? There is. But building a model and searching for the answer gives a good understanding of the problem, and many financial and scientific problems have no formula at all. They are solved this way, with a model and a search.
### 1. EndBalance (15 points)
The program end_balance.py does what the spreadsheet does. It reads four inputs: the loan, the yearly interest rate in percent, the number of payments n, and the yearly payment. It prints the balance at the end of the n-th year, rounded to 2 decimal places:
```python
% python end_balance.py
100000
5
10
10000
Ending balance: 30821.59
```

```python
% python end_balance.py
100000
5
2
10000
Ending balance: 88725.0
```
Implementation notes:
- Use a loop that repeats the spreadsheet's calculation n times. A rate of 5 percent means multiplying by 1 + 5 / 100.
- Round with round(balance, 2) (lecture 1-2).
- Compare your results with the spreadsheet for a few payments.
### 2. LoanCalc (35 points)
Now the real question: which payment brings the ending balance close to zero? Call the ending balance for a payment x f(x); the loan, the rate and n stay fixed. We want an x for which f(x) is close to 0. Note that f is decreasing: the more you pay each year, the less you owe at the end. Lecture 3-2 showed two ways to solve such a problem: sequential search and bisection search.
The program loan_calc.py reads three inputs (the loan, the interest rate in percent, and n) and finds the payment both ways, to the nearest agora (0.01 shekels). It prints the payment as a whole number, with int(), and the number of steps each search took:
```python
% python loan_calc.py
100000
5
10
Loan = 100000.0, interest rate = 5.0%, periods = 10
Payment by sequential search: 12333, in 233377 steps
Payment by bisection search: 12333, in 24 steps
```
Sequential search. Start with a payment g for which you know that f(g) > 0. Then add a small increment, 0.01 shekels, to g, again and again, until f(g) is no longer positive. That g is the answer: the true solution lies less than one increment below it. In the picture, the guesses are x0, x1, x2, …:

Bisection search. Keep a low value and a high value with the answer between them, and a guess g halfway between. In each step, compute f(g): if it is positive, g is too low, so the answer is between g and high; otherwise it is between low and g. Move low or high to g, and set g to the new middle. Stop when high − low is at most ε = 0.01 shekels.
Implementation notes:
- Where to start. Paying loan / n a year pays back the loan without any interest, so the ending balance is surely positive: a good first guess for sequential search, and a good low value for bisection. Paying the whole loan in each year is surely too much: a good high value.
- Computing f. Each search needs the ending balance for many different payments. Put the loop from program 1 inside each search loop: a loop inside a loop. (In lecture 4-1 we will learn to write it once, as a function.)
- Counting steps. In sequential search, count each time g grows by the increment. In bisection search, count each time the interval is halved. The tester allows a difference of 1.
- The first line prints the inputs. Read the loan and the rate with float(), so that they print as 100000.0 and 5.0.
- Try a bigger loan or more years, and compare the time the two searches take.
### Part B: Anagrams (50 points)
Two programs about anagrams. Program 3 checks whether two phrases are anagrams, and program 4 makes a random one.
### 3. Anagram (30 points)
Two words or phrases are anagrams of each other if they use exactly the same letters, each one the same number of times, only in a different order. For example, "listen" and "silent" are anagrams: both use the letters l, i, s, t, e and n, once each. So are "evil" and "vile".
"aab" and "abb" are not anagrams: both use the letters a and b, but "aab" has two a's and "abb" has only one.
For phrases, we ignore spaces, punctuation and upper or lower case, as we did for palindromes in lecture 3-1. So "William Shakespeare" and "I am a weakish speller" are anagrams: write down the letters of each, and you get the same letters, the same number of times.
The program anagram.py reads two phrases. It prints each phrase with only its letters kept, all in lower case, and then True if the two are anagrams and False if not:
```python
% python anagram.py
William Shakespeare
I am a weakish speller
williamshakespeare
iamaweakishspeller
True
```

```python
% python anagram.py
hello
world
hello
world
False
```
Implementation notes:
- Clean each phrase first. Build a new string with a loop over the characters, keeping only letters (isalpha) and converting them with lower (lecture 3-1).
- Then compare the two cleaned strings. One way: for each letter of the first, find it in the second (you can use the find method of str) and remove it from there with slicing, so it cannot be used twice. If a letter is not found, they are not anagrams. Another way uses count. Either way, think about what happens when the lengths differ.
- Test with "Madam Curie" and "Radium came", with "Tom Marvolo Riddle" and "I am Lord Voldemort", and with pairs that are almost anagrams, like "aab" and "abb".
### 4. RandomAnagram (20 points)
The program random_anagram.py reads a word and prints its letters in a random order. The result is usually not an English word; it only has to use every letter of the input exactly once. Three runs:
```python
% python random_anagram.py
silent
ltnsei
```

```python
% python random_anagram.py
silent
enltsi
```

```python
% python random_anagram.py
silent
silten
```
Implementation notes:
- One way: repeatedly pick a random position in the word, add the letter there to the result, and remove it from the word, until the word is empty.
- A random position from 0 to len(word) - 1 is int(random.random() * len(word)) (lecture 1-2). Removing the letter at position i is a job for slicing.
- Check your results with your Anagram program.
### Testing your programs
First test each program yourself, with the examples above and with inputs of your own. Then run the tester, from the HW3 folder:
```python
% python test_hw3.py
```
It checks the rules, runs each program on several inputs and prints PASS or FAIL for each test; for a FAIL it shows the expected output and yours. Passing all the tests doesn't guarantee full points: the graders run other inputs too, and they read your code.
### Submission
Before you submit, make sure your code follows the course's coding style guidelines. Submit on the course's Moodle page, in the Homework 3 assignment. Upload these files only:
```python
end_balance.py
loan_calc.py
anagram.py
random_anagram.py
```

## From `end_balance.py`

### `end_balance.py`
```python
# Homework 3, program 1: EndBalance
# Prints the balance of a loan at the end of its last period.
# Input: the loan, the interest rate in percent, the number of periods n,
# and the periodical payment, each on its own line.

# Write your code here.
```

## From `loan_calc.py`

### `loan_calc.py`
```python
# Homework 3, program 2: LoanCalc
# Finds the periodical payment that pays off a loan, by sequential search
# and by bisection search.
# Input: the loan, the interest rate in percent, and the number of periods n,
# each on its own line.

increment = 0.01         # sequential search: the step, one agora
epsilon = 0.01           # bisection search: the accuracy, one agora

# Write your code here.
```

## From `anagram.py`

### `anagram.py`
```python
# Homework 3, program 3: Anagram
# Checks whether two phrases are anagrams of each other.
# Input: two phrases, each on its own line.

# Write your code here.
```

## From `random_anagram.py`

### `random_anagram.py`
```python
# Homework 3, program 4: RandomAnagram
# Prints the letters of a word in a random order.
# Input: a word.
import random

# Write your code here.
```


# Instructor's notes for the tutor (guidance only: do not quote these to the student as an answer)

# HW3 notes for the tutor

Given after week 3 (lectures 3-1 Strings and 3-2 Approximation). Students may use everything up to
lecture 3-2: loops, if, strings (indexing, slicing, `in`, `len`, methods such as lower, upper, isalpha,
find, count, replace), and sequential and bisection search. Not allowed yet (the tester checks):
defining functions, lists, `sorted`, `split`, `join`, `min`, `max`, `sum`, `random.randint`.
Input is read with `input()`, one value per line, no prompt. Give hints, not code.

## 1. EndBalance
Concepts: a counted loop that repeats the spreadsheet's calculation, percent as a fraction, round.
Hint ladder: compute the first two years by hand (94,500 and 88,725); compare with the spreadsheet row
by row; check the order of subtracting the payment and adding the interest.

## 2. LoanCalc
Concepts: sequential search and bisection search from lecture 3-2, applied to "ending balance = 0";
a loop inside a loop.
Hint ladder: get program 1 right first; ask which payment is surely too low and which surely too high;
ask what the balance loop must start from each time a new payment is tried; for bisection, ask what a
positive ending balance says about the guess.
Usual problems: the balance is not reset before each try; the wrong end of the interval moves; using
round instead of int for the printed payment.

## 3. Anagram
Concepts: building a string with the accumulator pattern, isalpha and lower, find and slicing (or count).
Hint ladder: first make the cleaned strings print correctly; then ask how to make sure each letter is
used only once; test with "aab" and "abb", and with strings of different lengths.
Usual problems: a check that accepts "aab"/"abb"; no length check.

## 4. RandomAnagram
Concepts: a random position with int(random.random() * n) (lecture 1-2), slicing to remove a character,
a while loop until the string is empty.
Hint ladder: what must happen to the word after a letter is picked? what range of positions is possible?
Usual problems: letters repeat or go missing; the last letter is never picked.
